# 同野观幂 · Quiet Intelligence Shader

这是给同野观幂小程序首页准备的一套 **neuro + noise 质感** 的滚动驱动 shader。它不是具象土星，而是把“轨道 / 粒子 / 复杂系统 / 神经噪声”抽象成一个可跨屏变化的主视觉。

设计目标：

- 保留你喜欢的 **neuro + noise** 细腻质感
- 借一点 Saturn 的“跨屏可追踪结构”，但不出现明确星球
- 9 屏滚动，每一屏有明显但克制的视觉变化
- 适合“沉浸式品牌展厅 + 服务转化”的首页结构
- H5 可直接预览，uni-app / 微信小程序可按示例接入

---

## 目录

```txt
demo/
  index.html      # 本地预览页面
  style.css       # demo 样式
  main.js         # 完整 vanilla WebGL shader demo

src/
  TongyeQuietIntelligenceShader.ts
                  # 可复用 TypeScript 封装

uni-app-example/
  TongyeShaderBackdrop.vue
                  # uni-app / 微信小程序接入示例

README.md
```

---

## 本地预览

不要直接双击 HTML，推荐启动静态服务。

```bash
cd demo
python3 -m http.server 5173
```

然后打开：

```txt
http://localhost:5173
```

---

## 9 屏对应关系

| 屏 | 业务叙事 | shader 状态 |
|---|---|---|
| S01 | AI 不应停留在黑箱里 | 暗场、低频神经噪声、少量微粒 |
| S02 | 同野 / 观幂 | 纤维增强，出现抽象轨道 |
| S03 | 四个现场 | 四向分支展开 |
| S04 | 组织现场 | 结构更稳定，轻网格 |
| S05 | 产品现场 / 无限画布 + Agent | 节点和画布感增强 |
| S06 | AIGC 视频管线 | 出现方向性管线与分镜框 |
| S07 | 个人能力建设 | 收束、温润、略带陶土暖感 |
| S08 | 方法论 | 轨道、分支、结构并置 |
| S09 | 预约共创 | 汇聚到下方 CTA 区域 |

---

## H5 接入

```ts
import { createTongyeQuietIntelligenceShader } from './src/TongyeQuietIntelligenceShader'

const canvas = document.querySelector('canvas') as HTMLCanvasElement
const shader = createTongyeQuietIntelligenceShader(canvas, { intensity: 1 })

function resize() {
  shader.resize(
    window.innerWidth,
    window.innerHeight,
    Math.min(window.devicePixelRatio || 1, 2)
  )
}

function updateScroll() {
  const maxScroll = document.documentElement.scrollHeight - window.innerHeight
  const progress = Math.min(window.scrollY / Math.max(maxScroll, 1), 0.9999)
  shader.setScroll(progress)
}

window.addEventListener('resize', resize)
window.addEventListener('scroll', updateScroll, { passive: true })

resize()
updateScroll()
```

---

## uni-app / 微信小程序接入建议

核心逻辑只有一件事：

```ts
shader.setScroll(progress)
```

也就是把页面滚动进度映射成 `0 ~ 1`。

```ts
function onScroll(e) {
  const scrollTop = e.detail.scrollTop
  const maxScroll = totalHeight - windowHeight
  const progress = Math.min(Math.max(scrollTop / maxScroll, 0), 0.9999)
  shader.setScroll(progress)
}
```

建议结构：

```txt
固定 WebGL canvas 背景
  ↓
上层 scroll-view / 页面滚动
  ↓
每屏正常排版文案和服务卡片
  ↓
滚动时只给 shader 更新一个 progress
```

微信小程序注意：

- canvas 建议 `type="webgl"`
- DPR 控制在 `1.5 ~ 2`
- 如果低端机压力大，把 `shader.resize(width, height, 1.25)` 即可
- 不要再叠很多实时粒子，粒子已经在 shader 内部
- 预约 / 服务转化区域要保持可读，不要让背景太抢
- 真机测试优先于浏览器模拟器

---

## 如何调得更像你们截图

想更暗：

```glsl
color *= 0.78;
```

或降低这些项：

```glsl
color += neuro * ... * 0.52;
color += orbit * ... * 0.65;
color += particle * ... * 0.38;
```

想更细、更像纤维：

在 `neuroField()` 里提高 `lineBand` 的第二个参数：

```glsl
lineBand(..., 14.0) -> lineBand(..., 20.0)
lineBand(..., 34.0) -> lineBand(..., 48.0)
```

想更少“宇宙感”：

降低轨道：

```glsl
color += orbit * warmGold * 0.65;
```

改成：

```glsl
color += orbit * warmGold * 0.38;
```

想更像无限画布：

提高 `sceneB()` 里 S05 的 grid 权重：

```glsl
if(idx < 4.5) return vec4(0.08, 0.48, 0.00, 0.10);
```

把 `0.48` 改到 `0.62` 左右。

---

## 改成 11 屏

目前 shader 中：

```glsl
#define SECTION_COUNT 9.0
```

如果要改成 11 屏，需要同步修改：

- `SECTION_COUNT`
- `sceneA(float idx)`
- `sceneB(float idx)`
- `sceneTint(float idx)`
- demo 里的 section 数量

如果你们计划里的 11 屏全部保留，建议这样扩展：

```txt
S09 项目展廊：增强 grid + card frame
S10 服务转化：降低动效，背景更暗
S11 预约共创：convergence 权重最高
```

---

## 文件选择

- 只想看效果：打开 `demo/`
- 只想接入：用 `src/TongyeQuietIntelligenceShader.ts`
- 做 uni-app：参考 `uni-app-example/TongyeShaderBackdrop.vue`
- 要改 shader：搜索 `neuroField`, `orbitalField`, `sceneA`, `sceneB`

---

## 视觉结论

这版不是“土星”，也不是常见蓝紫 AI 背景。

它更像：

> 一个复杂系统在 9 个真实现场之间缓慢变形：  
> 从黑箱，到现场；从噪声，到结构；从工具，到能力。
