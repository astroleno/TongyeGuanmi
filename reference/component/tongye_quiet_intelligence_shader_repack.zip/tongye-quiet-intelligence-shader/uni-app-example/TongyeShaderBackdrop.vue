<template>
  <view class="tongye-page">
    <!--
      微信小程序端建议用 type="webgl" canvas。
      这份组件是接入思路示例；不同 uni-app 版本对 WebGL canvas node 的获取略有差异。
    -->
    <canvas
      id="tongyeShader"
      type="webgl"
      class="tongye-shader"
      @touchmove.stop.prevent="noop"
    />

    <scroll-view
      class="tongye-scroll"
      scroll-y
      enhanced
      :show-scrollbar="false"
      @scroll="onScroll"
    >
      <view v-for="section in sections" :key="section.id" class="scene">
        <text class="eyebrow">{{ section.id }}</text>
        <text class="title">{{ section.title }}</text>
        <text class="desc">{{ section.desc }}</text>
      </view>
    </scroll-view>
  </view>
</template>

<script setup lang="ts">
import { onMounted, onBeforeUnmount } from 'vue';
// 推荐把 src/TongyeQuietIntelligenceShader.ts 放进项目后再引入：
// import { createTongyeQuietIntelligenceShader } from '@/shaders/TongyeQuietIntelligenceShader';

const sections = [
  { id: 'S01', title: 'AI 不应停留在黑箱里', desc: '它应该进入真实的工作、学习与创造现场。' },
  { id: 'S02', title: '同野 / 观幂', desc: '在开放真实的场域中共同协作，看见复杂系统背后的结构与方法。' },
  { id: 'S03', title: '四个现场', desc: '组织、产品、内容、个人。' },
  { id: 'S04', title: '组织现场', desc: 'AI 转型咨询、培训与落地陪跑。' },
  { id: 'S05', title: '产品现场', desc: '企业级无限画布 + Agent。' },
  { id: 'S06', title: '内容现场', desc: '生产级 AIGC 视频管线。' },
  { id: 'S07', title: '个人现场', desc: '学习、研究、表达与能力建设。' },
  { id: 'S08', title: '方法论', desc: '看见现场 → 共创场景 → 建立工具 → 训练能力 → 陪跑落地。' },
  { id: 'S09', title: '预约共创', desc: '从一个真实现场开始。' },
];

let shader: null | {
  setScroll: (progress: number) => void;
  resize: (width: number, height: number, pixelRatio?: number) => void;
  dispose?: () => void;
} = null;

const noop = () => {};

onMounted(() => {
  // H5 可以直接 document.querySelector。
  // MP-WEIXIN 需要通过 createSelectorQuery 获取 canvas node。
  //
  // #ifdef H5
  // const canvas = document.querySelector('#tongyeShader') as HTMLCanvasElement;
  // shader = createTongyeQuietIntelligenceShader(canvas, { intensity: 1 });
  // const info = uni.getSystemInfoSync();
  // shader.resize(info.windowWidth, info.windowHeight, Math.min(info.pixelRatio || 1, 2));
  // #endif
  //
  // #ifdef MP-WEIXIN
  // const query = uni.createSelectorQuery();
  // query.select('#tongyeShader').node((res: any) => {
  //   const canvas = res.node;
  //   shader = createTongyeQuietIntelligenceShader(canvas as HTMLCanvasElement, { intensity: 1 });
  //   const info = uni.getSystemInfoSync();
  //   shader.resize(info.windowWidth, info.windowHeight, Math.min(info.pixelRatio || 1, 2));
  // }).exec();
  // #endif
});

onBeforeUnmount(() => {
  shader?.dispose?.();
});

function onScroll(e: any) {
  const scrollTop = e?.detail?.scrollTop || 0;
  const info = uni.getSystemInfoSync();

  // 每屏约等于一个屏幕高度；如果你们后续每屏高度不同，改成真实 contentHeight 即可。
  const totalHeight = info.windowHeight * sections.length;
  const maxScroll = Math.max(1, totalHeight - info.windowHeight);
  const progress = Math.max(0, Math.min(0.9999, scrollTop / maxScroll));

  shader?.setScroll(progress);
}
</script>

<style scoped>
.tongye-page {
  position: relative;
  width: 100%;
  height: 100vh;
  background: #080807;
  overflow: hidden;
}

.tongye-shader {
  position: fixed;
  inset: 0;
  width: 100%;
  height: 100%;
}

.tongye-scroll {
  position: relative;
  z-index: 2;
  width: 100%;
  height: 100vh;
}

.scene {
  min-height: 100vh;
  padding: 120rpx 52rpx 96rpx;
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: #E9E2D2;
}

.eyebrow {
  margin-bottom: 28rpx;
  font-size: 22rpx;
  letter-spacing: 3rpx;
  opacity: .58;
}

.title {
  font-size: 72rpx;
  line-height: 1.12;
  font-weight: 300;
}

.desc {
  margin-top: 32rpx;
  max-width: 620rpx;
  font-size: 28rpx;
  line-height: 1.7;
  opacity: .72;
}
</style>
