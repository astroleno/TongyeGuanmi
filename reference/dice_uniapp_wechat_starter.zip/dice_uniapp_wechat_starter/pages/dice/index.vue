<template>
  <view class="page">
    <DicePoster
      ref="posterRef"
      canvas-id="dicePosterCanvasHome"
      :word="word"
      :lines="lines"
      :caption="caption"
      :meta="meta"
      :tone="tone"
      :animate="true"
    />

    <view class="panel">
      <input class="input" v-model="word" maxlength="6" placeholder="DICE" />
      <input class="input" v-model="caption" maxlength="18" placeholder="标题" />
      <input class="input" v-model="meta" maxlength="12" placeholder="编号" />

      <view class="tone-row">
        <button
          v-for="item in tones"
          :key="item"
          class="tone-btn"
          :class="{ 'tone-btn--active': tone === item }"
          @tap="tone = item"
        >
          {{ item }}
        </button>
      </view>

      <view class="actions">
        <button class="action-btn" @tap="shuffle">换一版</button>
        <button class="action-btn action-btn--primary" @tap="exportAndSave">保存海报</button>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import DicePoster from '@/components/DicePoster/DicePoster.vue'

const posterRef = ref(null)
const word = ref('DICE')
const caption = ref('DICE POSTER')
const meta = ref('NO. 01')
const tone = ref('mint')
const tones = ['mint', 'gold', 'silver', 'acid']
const lines = ref([
  'TYPE AND RANDOMNESS',
  'MOTION POSTER SYSTEM',
  'CREATE SHARE UNLOCK'
])

function shuffle() {
  posterRef.value && posterRef.value.nextFrame()
}

async function exportAndSave() {
  if (!posterRef.value) return
  uni.showLoading({ title: '生成中' })
  try {
    const filePath = await posterRef.value.exportPoster()
    await saveImage(filePath)
    uni.hideLoading()
    uni.showToast({ title: '已保存', icon: 'success' })
  } catch (err) {
    uni.hideLoading()
    uni.showModal({
      title: '保存失败',
      content: '请检查相册权限；也可以先预览图片后长按保存。',
      confirmText: '预览',
      success: async (res) => {
        if (res.confirm && posterRef.value) {
          const filePath = await posterRef.value.exportPoster()
          uni.previewImage({ urls: [filePath], current: filePath })
        }
      }
    })
  }
}

function saveImage(filePath) {
  return new Promise((resolve, reject) => {
    uni.saveImageToPhotosAlbum({
      filePath,
      success: resolve,
      fail: reject
    })
  })
}
</script>

<style scoped>
.page {
  min-height: 100vh;
  padding: 28rpx 30rpx 60rpx;
  box-sizing: border-box;
  background: #050706;
}

.panel {
  margin-top: 28rpx;
}

.input {
  box-sizing: border-box;
  width: 100%;
  height: 78rpx;
  margin-bottom: 18rpx;
  padding: 0 24rpx;
  border-radius: 16rpx;
  background: rgba(255, 255, 255, 0.08);
  color: #fff;
  font-size: 28rpx;
}

.tone-row,
.actions {
  display: flex;
  align-items: center;
  margin-top: 18rpx;
}

.tone-btn,
.action-btn {
  flex: 1;
  height: 72rpx;
  margin-right: 14rpx;
  border-radius: 16rpx;
  background: rgba(255, 255, 255, 0.10);
  color: rgba(255, 255, 255, 0.74);
  font-size: 24rpx;
  line-height: 72rpx;
}

.tone-btn:last-child,
.action-btn:last-child {
  margin-right: 0;
}

.tone-btn--active,
.action-btn--primary {
  background: #d8ff37;
  color: #101306;
}
</style>
