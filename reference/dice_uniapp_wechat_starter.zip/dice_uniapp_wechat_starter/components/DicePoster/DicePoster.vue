<template>
  <view
    class="dice-poster"
    :class="[`dice-poster--${tone}`, { 'dice-poster--still': !animate }]"
    @tap="nextFrame"
  >
    <view class="dice-poster__grain" />

    <!-- 后层文字：被 DICE 主体遮住，制造“穿插在后面”的感觉 -->
    <view class="dice-poster__text dice-poster__text--back">
      <text
        v-for="(line, index) in linesForRender"
        :key="`back-${index}`"
        class="dice-poster__line"
        :style="lineStyle(index, 'back')"
      >
        {{ line }}
      </text>
    </view>

    <!-- 中间主视觉：纯 DICE 字形层 -->
    <view class="dice-poster__word" :style="wordStyle">
      <view
        v-for="(letter, index) in letters"
        :key="`letter-${index}`"
        class="dice-poster__letter"
        :style="letterStyle(index)"
      >
        {{ letter }}
      </view>
    </view>

    <!-- 前层文字：低透明度复制一份，模拟文字从 DICE 前面擦过 -->
    <view class="dice-poster__text dice-poster__text--front">
      <text
        v-for="(line, index) in linesForRender"
        :key="`front-${index}`"
        class="dice-poster__line"
        :style="lineStyle(index, 'front')"
      >
        {{ line }}
      </text>
    </view>

    <view class="dice-poster__caption">
      <text class="dice-poster__caption-main">{{ caption }}</text>
      <text class="dice-poster__caption-meta">{{ meta }}</text>
    </view>

    <!-- 不要 display:none；小程序端 canvas 隐藏后可能无法导出 -->
    <canvas
      class="dice-poster__canvas"
      :canvas-id="canvasId"
      :id="canvasId"
    />
  </view>
</template>

<script setup>
import { computed, getCurrentInstance, onMounted, onUnmounted, ref, watch } from 'vue'

const props = defineProps({
  word: { type: String, default: 'DICE' },
  lines: {
    type: Array,
    default: () => [
      'TYPE AND RANDOMNESS',
      'MOTION POSTER SYSTEM',
      'CREATE SHARE UNLOCK'
    ]
  },
  caption: { type: String, default: 'DICE POSTER' },
  meta: { type: String, default: 'NO. 01' },
  tone: { type: String, default: 'mint' },
  animate: { type: Boolean, default: true },
  canvasId: { type: String, default: 'dicePosterCanvas' }
})

const emit = defineEmits(['exported', 'export-fail'])
const instance = getCurrentInstance()
const frame = ref(0)
let timer = null

const palettes = {
  mint: {
    exportBg: '#08110f',
    back: '#54e5a4',
    front: '#d7ffe9',
    word: '#f2fff7',
    shadow: '#086546',
    accent: '#74f0b6'
  },
  gold: {
    exportBg: '#141006',
    back: '#e8c86d',
    front: '#fff1b6',
    word: '#fff8dc',
    shadow: '#79501c',
    accent: '#f2d784'
  },
  silver: {
    exportBg: '#0f1110',
    back: '#d9ddd6',
    front: '#ffffff',
    word: '#f7f8ef',
    shadow: '#68716e',
    accent: '#dfe4dd'
  },
  acid: {
    exportBg: '#0e1203',
    back: '#d8ff37',
    front: '#f5ffd0',
    word: '#fbffe4',
    shadow: '#6e800a',
    accent: '#c8f21c'
  }
}

const palette = computed(() => palettes[props.tone] || palettes.mint)
const letters = computed(() => (props.word || 'DICE').toUpperCase().slice(0, 6).split(''))
const linesForRender = computed(() => {
  const list = (props.lines || []).filter(Boolean).slice(0, 4)
  return list.length ? list : ['TYPE AND RANDOMNESS']
})

const wordStyle = computed(() => {
  const p = phase(0)
  const x = (p - 0.5) * 34
  const y = Math.sin(p * Math.PI * 2) * 18
  const r = -2 + p * 4
  return {
    transform: `translate3d(${x}rpx, ${y}rpx, 0) rotate(${r}deg)`
  }
})

function phase(seed) {
  return (frame.value * 0.173 + seed * 0.271) % 1
}

function lineStyle(index, layer) {
  const p = phase(index + (layer === 'front' ? 3 : 0))
  const direction = index % 2 === 0 ? 1 : -1
  const baseTop = 120 + index * 142
  const x = (p - 0.5) * 90 * direction
  const y = Math.sin(p * Math.PI * 2) * 14
  const rotate = (p - 0.5) * 4
  const opacity = layer === 'front' ? 0.16 : 0.82

  return {
    top: `${baseTop}rpx`,
    transform: `translate3d(${x}rpx, ${y}rpx, 0) rotate(${rotate}deg)`,
    opacity
  }
}

function letterStyle(index) {
  const p = phase(index + 1)
  const y = Math.sin(p * Math.PI * 2) * 18
  const r = (p - 0.5) * 7
  const scale = 1 + Math.cos(p * Math.PI * 2) * 0.018
  return {
    transform: `translate3d(0, ${y}rpx, 0) rotate(${r}deg) scale(${scale})`
  }
}

function nextFrame() {
  frame.value = (frame.value + 1) % 1000
}

function startTimer() {
  stopTimer()
  if (!props.animate) return
  timer = setInterval(nextFrame, 1100)
}

function stopTimer() {
  if (timer) {
    clearInterval(timer)
    timer = null
  }
}

watch(() => props.animate, startTimer)
onMounted(startTimer)
onUnmounted(stopTimer)

function setAlpha(ctx, alpha) {
  if (ctx.setGlobalAlpha) ctx.setGlobalAlpha(alpha)
}

function drawText(ctx, text, x, y, size, color, alpha = 1) {
  setAlpha(ctx, alpha)
  if ('font' in ctx) ctx.font = `normal 800 ${size}px sans-serif`
  ctx.setFontSize(size)
  ctx.setFillStyle(color)
  ctx.fillText(text, x, y)
}

function drawPoster() {
  return new Promise((resolve, reject) => {
    try {
      const ctx = uni.createCanvasContext(props.canvasId, instance && instance.proxy)
      const W = 750
      const H = 1000
      const p = palette.value
      const currentLines = linesForRender.value
      const currentLetters = letters.value

      ctx.setFillStyle(p.exportBg)
      ctx.fillRect(0, 0, W, H)

      // 背景微光块，不依赖 CSS 渐变，保证导出端稳定
      setAlpha(ctx, 0.13)
      ctx.setFillStyle(p.accent)
      ctx.fillRect(46, 70, 180, 180)
      ctx.fillRect(520, 610, 170, 260)

      // 背景网格线
      setAlpha(ctx, 0.10)
      ctx.setStrokeStyle(p.back)
      for (let y = 84; y < H; y += 96) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(W, y)
        ctx.stroke()
      }

      // 后层文字
      currentLines.forEach((line, index) => {
        drawText(ctx, String(line).toUpperCase(), 38, 172 + index * 142, 54, p.back, 0.72)
      })

      // 中间 DICE 主体阴影与承载块
      setAlpha(ctx, 0.18)
      ctx.setFillStyle(p.shadow)
      ctx.fillRect(52, 328, 642, 262)
      setAlpha(ctx, 0.12)
      ctx.setFillStyle(p.accent)
      ctx.fillRect(70, 304, 608, 250)

      // DICE 字形。Canvas 字体与页面字体可能略不同；上线前可换成字形图片保证一致。
      currentLetters.forEach((letter, index) => {
        const x = 46 + index * 164
        drawText(ctx, letter, x + 10, 535 + 10, 188, p.shadow, 0.46)
        drawText(ctx, letter, x, 535, 188, p.word, 1)
      })

      // 前层文字
      currentLines.forEach((line, index) => {
        drawText(ctx, String(line).toUpperCase(), 36, 188 + index * 142, 54, p.front, 0.18)
      })

      // 顶部与底部信息
      drawText(ctx, props.caption || 'DICE POSTER', 42, 56, 24, p.front, 0.86)
      drawText(ctx, props.meta || 'NO. 01', 610, 56, 22, p.front, 0.68)
      drawText(ctx, 'TAP TO RANDOMIZE · EXPORT TO POSTER', 42, 928, 22, p.back, 0.58)

      setAlpha(ctx, 1)
      ctx.draw(false, () => {
        // 给小程序端一次绘制落盘时间
        setTimeout(() => {
          uni.canvasToTempFilePath(
            {
              canvasId: props.canvasId,
              x: 0,
              y: 0,
              width: W,
              height: H,
              destWidth: W * 2,
              destHeight: H * 2,
              fileType: 'png',
              success: (res) => {
                emit('exported', res.tempFilePath)
                resolve(res.tempFilePath)
              },
              fail: (err) => {
                emit('export-fail', err)
                reject(err)
              }
            },
            instance && instance.proxy
          )
        }, 120)
      })
    } catch (err) {
      emit('export-fail', err)
      reject(err)
    }
  })
}

defineExpose({
  nextFrame,
  exportPoster: drawPoster
})
</script>

<style scoped>
.dice-poster {
  position: relative;
  width: 100%;
  max-width: 690rpx;
  height: 920rpx;
  overflow: hidden;
  border-radius: 20rpx;
  box-shadow: inset 0 0 0 1rpx rgba(255, 255, 255, 0.08);
  background: #08110f;
}

.dice-poster--mint {
  background:
    radial-gradient(circle at 18% 14%, rgba(84, 229, 164, 0.22), transparent 32%),
    linear-gradient(150deg, #08110f 0%, #0e1714 54%, #050807 100%);
}

.dice-poster--gold {
  background:
    radial-gradient(circle at 18% 14%, rgba(232, 200, 109, 0.22), transparent 32%),
    linear-gradient(150deg, #141006 0%, #1c1609 54%, #070502 100%);
}

.dice-poster--silver {
  background:
    radial-gradient(circle at 18% 14%, rgba(223, 228, 221, 0.20), transparent 32%),
    linear-gradient(150deg, #0f1110 0%, #171a18 54%, #060706 100%);
}

.dice-poster--acid {
  background:
    radial-gradient(circle at 18% 14%, rgba(216, 255, 55, 0.20), transparent 32%),
    linear-gradient(150deg, #0e1203 0%, #141908 54%, #050700 100%);
}

.dice-poster__grain {
  position: absolute;
  inset: 0;
  z-index: 0;
  opacity: 0.18;
  background-image:
    linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1rpx, transparent 1rpx),
    linear-gradient(0deg, rgba(255, 255, 255, 0.04) 1rpx, transparent 1rpx);
  background-size: 54rpx 54rpx;
}

.dice-poster__text {
  position: absolute;
  top: 0;
  left: 30rpx;
  right: 0;
  bottom: 0;
  z-index: 1;
  pointer-events: none;
}

.dice-poster__text--front {
  z-index: 4;
}

.dice-poster__line {
  position: absolute;
  left: 0;
  display: block;
  width: 1100rpx;
  font-family: DiceDisplay, 'DIN Condensed', 'Arial Narrow', Arial, sans-serif;
  font-size: 54rpx;
  font-weight: 800;
  line-height: 0.9;
  letter-spacing: -1rpx;
  white-space: nowrap;
  transition: transform 0.86s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.42s ease;
}

.dice-poster--mint .dice-poster__text--back .dice-poster__line { color: #54e5a4; }
.dice-poster--mint .dice-poster__text--front .dice-poster__line { color: #d7ffe9; }
.dice-poster--gold .dice-poster__text--back .dice-poster__line { color: #e8c86d; }
.dice-poster--gold .dice-poster__text--front .dice-poster__line { color: #fff1b6; }
.dice-poster--silver .dice-poster__text--back .dice-poster__line { color: #d9ddd6; }
.dice-poster--silver .dice-poster__text--front .dice-poster__line { color: #ffffff; }
.dice-poster--acid .dice-poster__text--back .dice-poster__line { color: #d8ff37; }
.dice-poster--acid .dice-poster__text--front .dice-poster__line { color: #f5ffd0; }

.dice-poster__word {
  position: absolute;
  left: 34rpx;
  right: 0;
  top: 330rpx;
  z-index: 3;
  display: flex;
  align-items: center;
  height: 210rpx;
  transform-origin: center;
  transition: transform 0.86s cubic-bezier(0.22, 1, 0.36, 1);
  pointer-events: none;
}

.dice-poster__letter {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 154rpx;
  height: 220rpx;
  margin-right: -2rpx;
  font-family: DiceDisplay, 'DIN Condensed', 'Arial Narrow', Arial, sans-serif;
  font-size: 176rpx;
  font-weight: 900;
  line-height: 0.86;
  letter-spacing: -10rpx;
  transition: transform 0.86s cubic-bezier(0.22, 1, 0.36, 1);
}

.dice-poster--mint .dice-poster__letter {
  color: #f2fff7;
  text-shadow: 9rpx 12rpx 0 #086546, 0 0 34rpx rgba(116, 240, 182, 0.20);
}
.dice-poster--gold .dice-poster__letter {
  color: #fff8dc;
  text-shadow: 9rpx 12rpx 0 #79501c, 0 0 34rpx rgba(242, 215, 132, 0.18);
}
.dice-poster--silver .dice-poster__letter {
  color: #f7f8ef;
  text-shadow: 9rpx 12rpx 0 #68716e, 0 0 34rpx rgba(223, 228, 221, 0.18);
}
.dice-poster--acid .dice-poster__letter {
  color: #fbffe4;
  text-shadow: 9rpx 12rpx 0 #6e800a, 0 0 34rpx rgba(200, 242, 28, 0.18);
}

.dice-poster__caption {
  position: absolute;
  top: 34rpx;
  left: 34rpx;
  right: 34rpx;
  z-index: 5;
  display: flex;
  justify-content: space-between;
  color: rgba(255, 255, 255, 0.74);
  font-size: 22rpx;
  line-height: 1;
  letter-spacing: 1rpx;
  pointer-events: none;
}

.dice-poster__caption-main,
.dice-poster__caption-meta {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dice-poster__caption-meta {
  opacity: 0.62;
}

.dice-poster__canvas {
  position: fixed;
  left: -9999px;
  top: 0;
  width: 750px;
  height: 1000px;
  opacity: 0;
  pointer-events: none;
}

.dice-poster--still .dice-poster__line,
.dice-poster--still .dice-poster__word,
.dice-poster--still .dice-poster__letter {
  transition: none;
}
</style>
