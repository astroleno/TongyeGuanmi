# DICE uni-app 微信小程序落地包

## 文件

- `components/DicePoster/DicePoster.vue`：实时动效组件 + Canvas 导出方法
- `pages/dice/index.vue`：页面示例，包含换版、配色、保存海报
- `App.vue.snippet`：可选字体加载示例
- `pages.json.snippet`：页面路由示例

## 接入步骤

1. 复制 `components/DicePoster` 到你的 uni-app 项目。
2. 复制 `pages/dice/index.vue` 到项目页面目录。
3. 将 `pages.json.snippet` 里的页面配置合并进你的 `pages.json`。
4. 如需自定义字体，把字体放到你自己的 HTTPS CDN/OSS，并在 `App.vue` 里调用 `uni.loadFontFace`。
5. 在微信开发者工具里真机预览，重点测试：iOS/Android、保存相册权限、Canvas 导出清晰度。

## 设计建议

- 页面实时预览使用 view/text + CSS transform，不要用 WebGL。
- 导出海报使用 Canvas 重新绘制，不要截图 DOM。
- 不要直接使用原站名称、文案、完整排版和视觉资产，做成原创风格。
