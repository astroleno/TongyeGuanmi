// Author: tomxor. Translated and extended from https://www.dwitter.net/d/10534
// Original one-liner x.fillRect(0,0,i=2e3,i);for(t+=160;p=i&1,m=t/C(t/i)+p*(t/2+i%t),i--;);x.clearRect(960+m*S(n=t/9+i*i)*C(!p*i/t),540+m*C(n+p*2),s=3-C(n)*3,s)

let counter = 100;
let parity_flag = 0;

function setup() {
	createCanvas(windowWidth, windowHeight);
	stroke(255);
	describe("An animated rendering of Saturn-like planet, viewed from space with a tilted ring system, " +
		"created using densely plotted points that vary in size to simulate 3D shading and rotation over time.")
}

function draw() {
	background(0);
	counter += 0.01;

	for (let i = 2000; i >= 0; i -= 2) { // Only when i is even, draw planet.
		parity_flag = 0; // parity_flag false
		drawPoints(i);
	}
	for (let i = 1999; i > 0; i -= 2) { // Only when i is odd, draw ring.
		parity_flag = 1;
		drawPoints(i);
	}

	function drawPoints(i) {
		let radial_offset = counter / cos(counter / i) + parity_flag * (counter / 2 + i % counter); // calculation distance or magnitude from center
		let angular_phase = counter / 9 + i * i; // time-based angle or rotation factor, scaled by iteration
		let x_position = (windowWidth / 2 - 100) + radial_offset * sin(angular_phase) * cos(!parity_flag * i / counter);
		let y_position = 400 + radial_offset * cos(angular_phase + parity_flag * 2);

		let point_size = 1 - cos(angular_phase); // varies between 0 (dim/invisible) and 2 (bright/large dots).

		// The brightness direction effect (simulating lighting) is achieved by correlating point_size (strokeWeight) with y_position:

		// For the planet (parity_flag = 0):
		// When cos(angular_phase) ≈ -1, point_size ≈ 2 (brightest), y_position ≈ 300 - radial_offset (top of planet, simulating light from above).
		// When cos(angular_phase) ≈ 1, point_size ≈ 0 (dimmest), y_position ≈ 300 + radial_offset (bottom of planet).

		// For the ring (parity_flag = 1):
		// y_position = 300 + radial_offset * cos(angular_phase + 2)  // Phase shift of +2 radians (~114.6 degrees) moves the bright area.
		// When cos(angular_phase) ≈ -1, point_size ≈ 2 (brightest), cos(angular_phase + 2) ≈ cos(1) ≈ 0.54, so y_position ≈ 300 + 0.54 * radial_offset (shifted toward bottom/near side, simulating perspective brightness toward viewer).
		// When cos(angular_phase) ≈ 1, point_size ≈ 0 (dimmest), cos(angular_phase + 2) ≈ cos(3) ≈ -0.99, so y_position ≈ 300 - 0.99 * radial_offset (top/far side dimmer).

		strokeWeight(point_size);
		point(x_position, y_position);
	}
}