/*
  Tiny runtime fallback used only when the CDN copy of GSAP is unavailable.
  The main demo still calls the familiar gsap.set / gsap.to API, so the same app.js
  runs online with real GSAP and offline with this lightweight substitute.
*/
(function () {
  if (window.gsap) return;

  const easeOut = t => 1 - Math.pow(1 - t, 3);

  function resolve(targets) {
    if (!targets) return [];
    if (typeof targets === 'string') return Array.from(document.querySelectorAll(targets));
    if (targets instanceof Element || targets === window || targets === document) return [targets];
    if (targets.length !== undefined) return Array.from(targets);
    return [targets];
  }

  function apply(el, vars) {
    if (!el || !vars) return;
    if (vars.attr && el.setAttribute) {
      Object.entries(vars.attr).forEach(([key, value]) => el.setAttribute(key, value));
    }
    const transformParts = [];
    if ('x' in vars || 'y' in vars || 'z' in vars) {
      const x = typeof vars.x === 'number' ? vars.x + 'px' : (vars.x || '0');
      const y = typeof vars.y === 'number' ? vars.y + 'px' : (vars.y || '0');
      const z = typeof vars.z === 'number' ? vars.z + 'px' : (vars.z || '0');
      transformParts.push(`translate3d(${x}, ${y}, ${z})`);
    }
    if ('rotation' in vars || 'rotate' in vars) transformParts.push(`rotate(${vars.rotation ?? vars.rotate}deg)`);
    if ('scale' in vars) transformParts.push(`scale(${vars.scale})`);
    if ('scaleX' in vars || 'scaleY' in vars) transformParts.push(`scale(${vars.scaleX ?? 1}, ${vars.scaleY ?? 1})`);
    if (transformParts.length) el.style.transform = transformParts.join(' ');

    Object.entries(vars).forEach(([key, value]) => {
      if (['attr', 'duration', 'ease', 'stagger', 'onComplete', 'delay', 'x', 'y', 'z', 'rotation', 'rotate', 'scale', 'scaleX', 'scaleY'].includes(key)) return;
      if (key.startsWith('--')) el.style.setProperty(key, value);
      else if (key in el.style) el.style[key] = typeof value === 'number' && key !== 'opacity' ? value + 'px' : value;
    });
  }

  window.gsap = {
    set(targets, vars) {
      resolve(targets).forEach(el => apply(el, vars));
    },
    to(targets, vars) {
      const elements = resolve(targets);
      const duration = Math.max(0, (vars.duration || 0) * 1000);
      const delay = Math.max(0, (vars.delay || 0) * 1000);
      const stagger = Math.max(0, (vars.stagger || 0) * 1000);
      elements.forEach((el, index) => {
        window.setTimeout(() => {
          if (!duration) {
            apply(el, vars);
            if (typeof vars.onComplete === 'function') vars.onComplete();
            return;
          }
          const start = performance.now();
          const from = { opacity: parseFloat(getComputedStyle(el).opacity) || 0 };
          function tick(now) {
            const p = Math.min(1, (now - start) / duration);
            const eased = easeOut(p);
            const next = { ...vars };
            if ('opacity' in vars) next.opacity = from.opacity + (vars.opacity - from.opacity) * eased;
            apply(el, next);
            if (p < 1) requestAnimationFrame(tick);
            else if (typeof vars.onComplete === 'function') vars.onComplete();
          }
          requestAnimationFrame(tick);
        }, delay + index * stagger);
      });
    },
    registerPlugin() {},
    utils: {
      clamp(min, max, value) { return Math.min(max, Math.max(min, value)); },
      interpolate(a, b, t) { return a + (b - a) * t; }
    }
  };

  window.ScrollTrigger = window.ScrollTrigger || { create() {}, refresh() {} };
})();
