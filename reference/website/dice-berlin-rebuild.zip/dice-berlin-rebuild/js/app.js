(function () {
  'use strict';

  const root = document.documentElement;
  const body = document.body;
  const track = document.querySelector('.scroll-track');
  const stage = document.querySelector('.pin-stage');
  const backLayer = document.querySelector('.copy-layer--back');
  const frontLayer = document.querySelector('.copy-layer--front');
  const meter = document.querySelector('.scroll-meter span');
  const menuPanel = document.querySelector('.menu-panel');
  const menuToggle = document.querySelector('.menu-toggle');
  const menuItems = Array.from(document.querySelectorAll('.menu-item'));
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const svg = {
    wrap: document.querySelector('.blob-svg'),
    rotate: document.querySelector('.blob-rotate'),
    main: document.querySelector('#blobMain'),
    shadow: document.querySelector('#blobShadow'),
    texture: document.querySelector('#blobTexture'),
    fold: document.querySelector('#blobFold'),
    sheen: document.querySelector('#blobSheen'),
    clip: document.querySelector('#blobClipPath'),
    glint: document.querySelector('#blobGlint'),
    gradA: document.querySelector('#gradStopA'),
    gradB: document.querySelector('#gradStopB'),
    gradC: document.querySelector('#gradStopC'),
    foldA: document.querySelector('#foldStopA'),
    foldB: document.querySelector('#foldStopB'),
    foldC: document.querySelector('#foldStopC'),
    turbulence: document.querySelector('#turbulence')
  };

  const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = t => t * t * (3 - 2 * t);
  const smoothstep = (edge0, edge1, x) => {
    if (edge0 === edge1) return x < edge0 ? 0 : 1;
    return smooth(clamp((x - edge0) / (edge1 - edge0)));
  };

  function hexToRgb(hex) {
    const value = hex.replace('#', '').trim();
    const full = value.length === 3 ? value.split('').map(ch => ch + ch).join('') : value;
    return {
      r: parseInt(full.slice(0, 2), 16),
      g: parseInt(full.slice(2, 4), 16),
      b: parseInt(full.slice(4, 6), 16)
    };
  }

  function rgbToHex({ r, g, b }) {
    const toHex = n => Math.round(clamp(n, 0, 255)).toString(16).padStart(2, '0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  }

  function mixColor(a, b, t) {
    const ca = hexToRgb(a);
    const cb = hexToRgb(b);
    return rgbToHex({
      r: lerp(ca.r, cb.r, t),
      g: lerp(ca.g, cb.g, t),
      b: lerp(ca.b, cb.b, t)
    });
  }

  function interpolatePoints(a, b, t) {
    return a.map((point, index) => [lerp(point[0], b[index][0], t), lerp(point[1], b[index][1], t)]);
  }

  function catmullRomPath(points, tension = 1) {
    if (!points.length) return '';
    const size = points.length;
    let d = `M ${points[0][0].toFixed(2)} ${points[0][1].toFixed(2)}`;
    for (let i = 0; i < size; i += 1) {
      const p0 = points[(i - 1 + size) % size];
      const p1 = points[i];
      const p2 = points[(i + 1) % size];
      const p3 = points[(i + 2) % size];
      const c1x = p1[0] + (p2[0] - p0[0]) / 6 * tension;
      const c1y = p1[1] + (p2[1] - p0[1]) / 6 * tension;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6 * tension;
      const c2y = p2[1] - (p3[1] - p1[1]) / 6 * tension;
      d += ` C ${c1x.toFixed(2)} ${c1y.toFixed(2)} ${c2x.toFixed(2)} ${c2y.toFixed(2)} ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
    }
    return `${d} Z`;
  }

  const SHAPES = [
    // Orbital green seed, close to the opening blob wrapped around the DICE letters.
    [[310,112],[468,124],[500,234],[472,314],[594,356],[552,464],[424,492],[358,594],[246,528],[252,410],[164,348],[224,238]],
    // Compressed spinning saucer used during the date / title reveal.
    [[248,190],[428,126],[578,182],[532,300],[606,364],[510,438],[392,494],[294,560],[226,464],[158,382],[208,306],[186,240]],
    // Wide soft body used over the featuring list.
    [[232,220],[406,130],[574,206],[634,312],[598,434],[462,492],[330,562],[222,510],[172,414],[114,350],[196,304],[176,258]],
    // Orange archive puck, more curled and compact.
    [[298,142],[460,158],[556,250],[520,352],[598,420],[470,492],[350,474],[256,554],[190,456],[144,352],[224,298],[202,210]],
    // 2018 fabric-like surface.
    [[214,196],[372,112],[560,170],[604,304],[550,430],[418,506],[310,528],[202,482],[142,384],[178,286],[116,226],[184,178]],
    // Final star fold.
    [[250,166],[398,142],[492,246],[636,292],[504,376],[502,528],[374,448],[246,560],[256,412],[112,360],[248,304],[176,222]]
  ];

  const FOLDS = [
    [[224,276],[326,178],[482,176],[574,256],[466,286],[366,330],[284,414],[214,374]],
    [[182,302],[316,194],[548,204],[612,292],[478,318],[350,356],[234,398],[150,360]],
    [[160,344],[300,208],[510,204],[636,310],[506,342],[360,374],[242,446],[130,392]],
    [[220,286],[344,186],[520,202],[592,294],[478,330],[358,330],[272,384],[180,354]],
    [[190,252],[332,154],[552,180],[632,318],[492,344],[354,314],[238,366],[126,314]],
    [[198,302],[324,188],[504,208],[614,306],[496,362],[372,326],[270,432],[160,384]]
  ];

  const STATES = [
    {
      p: 0,
      shape: 0,
      bg: '#e8ecd8',
      nav: '#101010',
      x: 0,
      y: 0,
      scale: 0.92,
      rotate: -10,
      spin: 0,
      maskW: 22,
      maskH: 19,
      hazeWarm: 0,
      hazeCool: 0,
      texture: 0,
      turbulence: 4,
      colors: ['#b5ffd7', '#51d89b', '#087850'],
      folds: ['#e9ffd7', '#46c68f', '#004e3c']
    },
    {
      p: 0.22,
      shape: 1,
      bg: '#e8ecd8',
      nav: '#101010',
      x: -4,
      y: 3,
      scale: 0.83,
      rotate: 22,
      spin: -22,
      maskW: 25,
      maskH: 16,
      hazeWarm: 0,
      hazeCool: 0,
      texture: 0,
      turbulence: 5,
      colors: ['#bdffd9', '#4ad79a', '#07583d'],
      folds: ['#ddffe0', '#2fba87', '#003f33']
    },
    {
      p: 0.43,
      shape: 2,
      bg: '#e8ecd8',
      nav: '#101010',
      x: 6,
      y: -4,
      scale: 1.03,
      rotate: 88,
      spin: -72,
      maskW: 32,
      maskH: 19,
      hazeWarm: 0,
      hazeCool: 0,
      texture: 0,
      turbulence: 7,
      colors: ['#d7ffd8', '#5edfa8', '#116d50'],
      folds: ['#f2ffe2', '#42c998', '#0a4c3f']
    },
    {
      p: 0.62,
      shape: 3,
      bg: '#e9c9be',
      nav: '#ffffff',
      x: 1,
      y: 0,
      scale: 0.88,
      rotate: 174,
      spin: -160,
      maskW: 28,
      maskH: 19,
      hazeWarm: 1,
      hazeCool: 0,
      texture: 0,
      turbulence: 6,
      colors: ['#ffdc8a', '#dba11f', '#643328'],
      folds: ['#fff2bd', '#d8891a', '#4c1b29']
    },
    {
      p: 0.80,
      shape: 4,
      bg: '#eef0f4',
      nav: '#101010',
      x: -2,
      y: 2,
      scale: 0.9,
      rotate: 274,
      spin: -245,
      maskW: 29,
      maskH: 22,
      hazeWarm: 0,
      hazeCool: 1,
      texture: 0.68,
      turbulence: 3,
      colors: ['#e8ffe3', '#8365e7', '#ff6b7e'],
      folds: ['#eaffde', '#6a5cdb', '#d96878']
    },
    {
      p: 1,
      shape: 5,
      bg: '#eef0f4',
      nav: '#101010',
      x: 7,
      y: -6,
      scale: 0.78,
      rotate: 360,
      spin: -330,
      maskW: 25,
      maskH: 20,
      hazeWarm: 0,
      hazeCool: 0.78,
      texture: 0.5,
      turbulence: 4,
      colors: ['#dffff2', '#725dde', '#ef6477'],
      folds: ['#fff4e6', '#6650ce', '#d4647a']
    }
  ];

  const SCENES = [
    {
      id: 'hero',
      start: 0,
      end: 0.22,
      color: '#55d99d',
      fade: 0.075,
      lines: [
        { text: 'D', x: '29%', y: '4%', fs: 'clamp(168px, 24vw, 430px)', lh: '.78', ls: '-.085em', speed: 0.34 },
        { text: 'I', x: '52%', y: '12%', fs: 'clamp(168px, 24vw, 430px)', lh: '.78', ls: '-.09em', speed: 0.46 },
        { text: 'C', x: '29%', y: '43%', fs: 'clamp(168px, 24vw, 430px)', lh: '.78', ls: '-.09em', speed: 0.58 },
        { text: 'E', x: '52%', y: '52%', fs: 'clamp(168px, 24vw, 430px)', lh: '.78', ls: '-.09em', speed: 0.50 }
      ]
    },
    {
      id: 'date',
      start: 0.15,
      end: 0.40,
      color: '#55d99d',
      fade: 0.075,
      lines: [
        { text: 'October\nMarch', x: '7.1%', y: '28%', w: '42vw', ws: 'normal', fs: 'clamp(56px, 7.6vw, 138px)', lh: '.9', ls: '-.075em', speed: 0.72 },
        { text: '2021—\n2022', x: '40.3%', y: '31%', w: '34vw', ws: 'normal', fs: 'clamp(38px, 5.8vw, 98px)', lh: '.92', ls: '-.07em', speed: 0.48, cls: 'type-line--soft' },
        { text: 'Orbital Entities', x: '29.3%', y: '77%', fs: 'clamp(58px, 7.6vw, 140px)', lh: '.82', ls: '-.08em', speed: 0.36 }
      ]
    },
    {
      id: 'feature',
      start: 0.34,
      end: 0.59,
      color: '#55d99d',
      fade: 0.08,
      lines: [
        { text: 'Featuring', x: '40.5%', y: '23%', fs: 'clamp(28px, 3.7vw, 68px)', lh: '.86', ls: '-.08em', speed: 0.62 },
        { text: 'Ami Dang', x: '58%', y: '46%', fs: 'clamp(62px, 8.5vw, 160px)', lh: '.8', ls: '-.08em', speed: 0.34 },
        { text: 'Marie Davidson &', x: '4.5%', y: '91%', fs: 'clamp(72px, 10vw, 190px)', lh: '.78', ls: '-.085em', speed: 0.82 },
        { text: 'Born in Flamez', x: '50%', y: '104%', fs: 'clamp(54px, 7.4vw, 132px)', lh: '.8', ls: '-.085em', speed: 1.0 },
        { text: 'Mhysa', x: '9%', y: '116%', fs: 'clamp(54px, 8vw, 140px)', lh: '.8', ls: '-.085em', speed: 1.14 }
      ]
    },
    {
      id: 'archive19',
      start: 0.55,
      end: 0.77,
      color: '#ffffff',
      fade: 0.075,
      lines: [
        { text: 'DICE 2019 — A Look Back', x: '49.5%', y: '3.2%', fs: 'clamp(13px, 1.35vw, 20px)', lh: '1', ls: '-.035em', speed: 0.22, cls: 'type-line--tiny' },
        { text: 'Gallery     2019 Programme     Press', x: '70%', y: '3.2%', fs: 'clamp(13px, 1.35vw, 20px)', lh: '1', ls: '-.035em', speed: 0.24, cls: 'type-line--tiny' },
        { text: 'Lafawndah', x: '7%', y: '-8%', fs: 'clamp(74px, 10vw, 180px)', lh: '.8', ls: '-.08em', speed: 0.42 },
        { text: 'Almess', x: '66%', y: '32%', fs: 'clamp(62px, 8.6vw, 156px)', lh: '.78', ls: '-.08em', speed: 0.34 },
        { text: 'Ale Hop', x: '34%', y: '71%', fs: 'clamp(70px, 9.2vw, 165px)', lh: '.78', ls: '-.08em', speed: 0.58 },
        { text: 'Marcelle', x: '64%', y: '84%', fs: 'clamp(42px, 6.2vw, 110px)', lh: '.82', ls: '-.08em', speed: 0.72 },
        { text: 'Black Cracker', x: '5%', y: '95%', fs: 'clamp(48px, 6.8vw, 120px)', lh: '.8', ls: '-.08em', speed: 1.0 }
      ]
    },
    {
      id: 'archive18',
      start: 0.72,
      end: 0.95,
      color: '#050505',
      fade: 0.08,
      lines: [
        { text: 'DICE 2018 — A Look Back', x: '49.5%', y: '3.2%', fs: 'clamp(13px, 1.35vw, 20px)', lh: '1', ls: '-.035em', speed: 0.22, cls: 'type-line--tiny' },
        { text: 'Gallery     2018 Programme     Press', x: '70%', y: '3.2%', fs: 'clamp(13px, 1.35vw, 20px)', lh: '1', ls: '-.035em', speed: 0.24, cls: 'type-line--tiny' },
        { text: 'Platonos', x: '7%', y: '-7%', fs: 'clamp(78px, 10.4vw, 188px)', lh: '.78', ls: '-.085em', speed: 0.42 },
        { text: 'Plo Man', x: '25.5%', y: '35%', fs: 'clamp(64px, 8.8vw, 160px)', lh: '.78', ls: '-.085em', speed: 0.52 },
        { text: 'Faka', x: '40.3%', y: '73%', fs: 'clamp(68px, 8.7vw, 158px)', lh: '.78', ls: '-.085em', speed: 0.7 },
        { text: 'Born in Flamez', x: '34%', y: '82%', fs: 'clamp(44px, 6.4vw, 116px)', lh: '.84', ls: '-.08em', speed: 0.86 },
        { text: 'MS Boogie', x: '56%', y: '21%', fs: 'clamp(39px, 5.4vw, 104px)', lh: '.84', ls: '-.075em', speed: 0.46 },
        { text: 'Moor Mother (DJ)', x: '56%', y: '54%', fs: 'clamp(38px, 5.1vw, 96px)', lh: '.84', ls: '-.075em', speed: 0.66 },
        { text: 'Kiki\nHitomi', x: '12%', y: '88%', fs: 'clamp(38px, 5.2vw, 96px)', lh: '.84', ls: '-.075em', speed: 0.9 }
      ]
    },
    {
      id: 'past',
      start: 0.88,
      end: 1,
      color: '#050505',
      fade: 0.08,
      lines: [
        { text: 'Past DICE Artists', x: '8%', y: '26%', fs: 'clamp(68px, 10vw, 188px)', lh: '.78', ls: '-.085em', speed: 0.38 },
        { text: 'About     Press     Videos     Contact', x: '9%', y: '63%', fs: 'clamp(26px, 4vw, 76px)', lh: '.84', ls: '-.07em', speed: 0.65 },
        { text: '+ More to Follow', x: '61%', y: '76%', fs: 'clamp(30px, 4.4vw, 80px)', lh: '.84', ls: '-.07em', speed: 0.86 }
      ]
    }
  ];

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));
  }

  function renderTypeLayers() {
    [backLayer, frontLayer].forEach(layer => {
      const isFront = layer.classList.contains('copy-layer--front');
      SCENES.forEach(scene => {
        const sceneEl = document.createElement('div');
        sceneEl.className = `scene-copy scene-copy--${scene.id}`;
        sceneEl.dataset.scene = scene.id;
        sceneEl.dataset.start = scene.start;
        sceneEl.dataset.end = scene.end;
        sceneEl.dataset.fade = scene.fade;
        sceneEl.style.color = scene.color;

        scene.lines.forEach((line, index) => {
          const p = document.createElement('p');
          p.className = `type-line ${line.cls || ''}`.trim();
          p.dataset.speed = line.speed || 0.5;
          p.dataset.index = index;
          p.style.setProperty('--x', line.x);
          p.style.setProperty('--y', line.y);
          p.style.setProperty('--fs', line.fs);
          p.style.setProperty('--lh', line.lh || '.82');
          p.style.setProperty('--ls', line.ls || '-.075em');
          p.style.setProperty('--w', line.w || 'auto');
          p.style.setProperty('--ws', line.ws || 'nowrap');
          p.style.setProperty('--rot', line.rot || '0deg');
          p.style.setProperty('--weight', line.weight || '700');
          if (line.color) p.style.setProperty('--c', line.color);
          p.innerHTML = escapeHtml(line.text).replace(/\n/g, '<br>');
          if (isFront) p.setAttribute('aria-hidden', 'true');
          sceneEl.appendChild(p);
        });
        layer.appendChild(sceneEl);
      });
    });
  }

  renderTypeLayers();
  const renderedScenes = Array.from(document.querySelectorAll('.scene-copy'));

  function getState(progress) {
    const p = clamp(progress);
    let a = STATES[0];
    let b = STATES[STATES.length - 1];
    for (let i = 0; i < STATES.length - 1; i += 1) {
      if (p >= STATES[i].p && p <= STATES[i + 1].p) {
        a = STATES[i];
        b = STATES[i + 1];
        break;
      }
    }
    const local = smoothstep(a.p, b.p, p);
    const shape = interpolatePoints(SHAPES[a.shape], SHAPES[b.shape], local);
    const fold = interpolatePoints(FOLDS[a.shape], FOLDS[b.shape], local);
    return {
      p,
      local,
      bg: mixColor(a.bg, b.bg, local),
      nav: mixColor(a.nav, b.nav, local),
      x: lerp(a.x, b.x, local),
      y: lerp(a.y, b.y, local),
      scale: lerp(a.scale, b.scale, local),
      rotate: lerp(a.rotate, b.rotate, local),
      spin: lerp(a.spin, b.spin, local),
      maskW: lerp(a.maskW, b.maskW, local),
      maskH: lerp(a.maskH, b.maskH, local),
      hazeWarm: lerp(a.hazeWarm, b.hazeWarm, local),
      hazeCool: lerp(a.hazeCool, b.hazeCool, local),
      texture: lerp(a.texture, b.texture, local),
      turbulence: lerp(a.turbulence, b.turbulence, local),
      colors: [0, 1, 2].map(index => mixColor(a.colors[index], b.colors[index], local)),
      folds: [0, 1, 2].map(index => mixColor(a.folds[index], b.folds[index], local)),
      shape,
      fold
    };
  }

  function alphaWindow(p, start, end, fade) {
    const intro = start <= 0 ? 1 : smoothstep(start, start + fade, p);
    const outro = end >= 1 ? 1 : 1 - smoothstep(end - fade, end, p);
    return clamp(intro * outro);
  }

  function setSceneTransforms(progress) {
    renderedScenes.forEach(sceneEl => {
      const start = Number(sceneEl.dataset.start);
      const end = Number(sceneEl.dataset.end);
      const fade = Number(sceneEl.dataset.fade);
      const alpha = alphaWindow(progress, start, end, fade);
      const center = (start + end) / 2;
      const y = (center - progress) * 66;
      const slightScale = 1 + Math.abs(progress - center) * 0.04;
      const layerBias = sceneEl.parentElement.classList.contains('copy-layer--front') ? -0.8 : 0;
      sceneEl.style.opacity = alpha.toFixed(4);
      sceneEl.style.transform = `translate3d(0, ${(y + layerBias).toFixed(3)}vh, 0) scale(${slightScale.toFixed(4)})`;

      sceneEl.querySelectorAll('.type-line').forEach(line => {
        const speed = Number(line.dataset.speed || 0.5);
        const index = Number(line.dataset.index || 0);
        const drift = (progress - center) * -120 * speed;
        const micro = Math.sin((progress * 10 + index) * Math.PI) * speed * 2.8;
        line.style.transform = `translate3d(0, ${(drift + micro).toFixed(2)}px, 0) rotate(var(--rot, 0deg))`;
      });
    });
  }

  function applyState(state) {
    const blobPath = catmullRomPath(state.shape, 1.05);
    const foldPath = catmullRomPath(state.fold, 1.08);
    const sheenPoints = state.shape.map(([x, y]) => [lerp(360, x, 0.62) - 18, lerp(300, y, 0.62) - 22]);
    const sheenPath = catmullRomPath(sheenPoints, 1.1);

    root.style.setProperty('--bg', state.bg);
    root.style.setProperty('--nav-color', state.nav);
    root.style.setProperty('--haze-warm', state.hazeWarm.toFixed(3));
    root.style.setProperty('--haze-cool', state.hazeCool.toFixed(3));
    root.style.setProperty('--front-mask-x', `calc(50% + ${state.x.toFixed(2)}vw)`);
    root.style.setProperty('--front-mask-y', `calc(50% + ${state.y.toFixed(2)}vh)`);
    root.style.setProperty('--front-mask-w', `${state.maskW.toFixed(2)}vw`);
    root.style.setProperty('--front-mask-h', `${state.maskH.toFixed(2)}vw`);

    svg.gradA.setAttribute('stop-color', state.colors[0]);
    svg.gradB.setAttribute('stop-color', state.colors[1]);
    svg.gradC.setAttribute('stop-color', state.colors[2]);
    svg.foldA.setAttribute('stop-color', state.folds[0]);
    svg.foldB.setAttribute('stop-color', state.folds[1]);
    svg.foldC.setAttribute('stop-color', state.folds[2]);
    svg.turbulence.setAttribute('baseFrequency', `${(0.011 + state.p * 0.012).toFixed(4)} ${(0.018 + state.p * 0.009).toFixed(4)}`);

    gsap.set([svg.main, svg.shadow, svg.texture, svg.clip], { attr: { d: blobPath } });
    gsap.set(svg.fold, { attr: { d: foldPath }, opacity: lerp(0.74, 0.9, Math.sin(state.p * Math.PI)) });
    gsap.set(svg.sheen, { attr: { d: sheenPath }, opacity: lerp(0.40, 0.62, Math.sin(state.p * Math.PI)) });
    gsap.set(svg.texture, { opacity: state.texture.toFixed(3) });
    gsap.set(svg.wrap, {
      x: `${state.x.toFixed(3)}vw`,
      y: `${state.y.toFixed(3)}vh`,
      scale: state.scale.toFixed(4),
      rotation: state.rotate.toFixed(3)
    });
    gsap.set(svg.rotate, { rotation: state.spin.toFixed(3) });
    gsap.set(svg.glint, {
      opacity: lerp(0.10, 0.22, 1 - state.texture).toFixed(3),
      rotation: -16 + state.spin * 0.08
    });

    meter.style.width = `${(state.p * 100).toFixed(2)}%`;
  }

  function calcProgress() {
    if (!track) return 0;
    const max = Math.max(1, track.offsetHeight - window.innerHeight);
    const top = track.getBoundingClientRect().top * -1;
    return clamp(top / max);
  }

  let targetProgress = calcProgress();
  let currentProgress = targetProgress;

  function render(progress) {
    const state = getState(progress);
    applyState(state);
    setSceneTransforms(progress);
  }

  function tick() {
    targetProgress = calcProgress();
    if (prefersReducedMotion) currentProgress = targetProgress;
    else currentProgress += (targetProgress - currentProgress) * 0.12;
    if (Math.abs(targetProgress - currentProgress) < 0.00005) currentProgress = targetProgress;
    render(currentProgress);
    requestAnimationFrame(tick);
  }

  function scrollToProgress(value) {
    const max = Math.max(1, track.offsetHeight - window.innerHeight);
    const top = track.offsetTop + max * clamp(value);
    window.scrollTo({ top, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
  }

  function setMenu(open) {
    body.classList.toggle('menu-is-open', open);
    menuToggle.setAttribute('aria-expanded', String(open));
    menuPanel.setAttribute('aria-hidden', String(!open));

    if (open) {
      gsap.set(menuPanel, { visibility: 'visible' });
      gsap.set(menuItems, { opacity: 0, y: 26 });
      gsap.to(menuPanel, { y: '0%', duration: 0.65, ease: 'power3.out' });
      gsap.to(menuItems, { opacity: 1, y: 0, duration: 0.72, ease: 'power3.out', stagger: 0.045, delay: 0.1 });
    } else {
      gsap.to(menuItems, { opacity: 0, y: -18, duration: 0.24, stagger: 0.018 });
      gsap.to(menuPanel, {
        y: '-101%',
        duration: 0.52,
        ease: 'power3.inOut',
        onComplete: () => gsap.set(menuPanel, { visibility: 'hidden' })
      });
    }
  }

  menuToggle.addEventListener('click', () => setMenu(!body.classList.contains('menu-is-open')));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && body.classList.contains('menu-is-open')) setMenu(false);
  });

  document.querySelectorAll('[data-jump]').forEach(link => {
    link.addEventListener('click', event => {
      const value = parseFloat(link.getAttribute('data-jump'));
      if (Number.isFinite(value)) {
        event.preventDefault();
        if (body.classList.contains('menu-is-open')) setMenu(false);
        scrollToProgress(value);
      }
    });
  });

  window.addEventListener('resize', () => {
    targetProgress = calcProgress();
    currentProgress = targetProgress;
    render(currentProgress);
  }, { passive: true });

  if (window.gsap && window.ScrollTrigger && window.gsap.registerPlugin) {
    try {
      window.gsap.registerPlugin(window.ScrollTrigger);
    } catch (error) {
      // The fallback ScrollTrigger exposes the same method but does not need registration.
    }
  }

  gsap.set(menuPanel, { y: '-101%', visibility: 'hidden' });
  gsap.set('.brand-jump', { opacity: 0 });
  render(currentProgress);
  tick();
})();
