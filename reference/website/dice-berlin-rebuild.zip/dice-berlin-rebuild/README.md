# DICE Berlin scroll morph rebuild

这是一个前端复刻/动效重建包，重点还原 `dice.berlin` 视觉语言中的三件事：

1. sticky 全屏舞台 + 滚动 scrub；
2. 中央抽象 blob 随滚动变形、旋转、换色；
3. 文字被复制成 back/front 两层，blob 夹在中间，前层用动态 ellipse clip-path 跟随 blob，从而做出文字在物体前后穿插出现的效果。

## 打开方式

最简单：直接双击 `index.html`。

推荐本地服务方式：

```bash
cd dice-berlin-rebuild
python3 -m http.server 8080
```

然后打开：

```text
http://localhost:8080
```

## 文件结构

```text
index.html              主动效页面
about.html              静态辅助页
press.html              静态辅助页
videos.html             静态辅助页
contact.html            静态辅助页
css/styles.css          全部布局、字体、层叠、响应式样式
js/app.js               滚动进度、路径 morph、文字层、菜单动效
js/gsap-fallback.js     CDN 失败时的轻量 fallback
assets/favicon.svg      原创 SVG favicon
```

## 动效核心位置

- `js/app.js` 里的 `SHAPES` / `FOLDS`：控制 blob 的 SVG path 形态。
- `js/app.js` 里的 `STATES`：控制每个滚动节点的背景、blob 颜色、位置、缩放、旋转、纹理和前景遮罩大小。
- `js/app.js` 里的 `SCENES`：控制所有大字排版和每段文字的出现区间。
- `css/styles.css` 里的 `.copy-layer--back`、`.blob-stage`、`.copy-layer--front`：完成「文字后层 / blob / 文字前层」的叠放。
- `css/styles.css` 里的 `.copy-layer--front`：使用 `clip-path: ellipse(...)`，变量由 JS 实时更新。

## GSAP 说明

页面默认通过 CDN 加载 GSAP 3.12.5 和 ScrollTrigger。为了让 zip 在离线预览时也能看到效果，项目附带了一个很小的 `gsap-fallback.js`。联网环境下会优先使用真正的 GSAP；离线环境下 fallback 会提供 `gsap.set()` / `gsap.to()` 的最小兼容实现。

## 版权说明

该包没有复制原站源码、图片或 3D 文件。中央 blob、favicon、辅助页面内容和实现代码均为重新制作；文字和整体动效结构用于还原你提供的视频中的视觉效果。上线商用前，请替换为你自己的品牌、图片、文案和授权素材。
