import { create } from 'zustand';

interface AppState {
  characters: string;
  morphProgress: number;
  scrollProgress: number;
  setForeground: boolean;
  setCharacters: (chars: string) => void;
  setMorphProgress: (progress: number) => void;
  setScrollProgress: (progress: number) => void;
  setSetForeground: (active: boolean) => void;
}

const DEFAULT_CHARS = " .,:;+=*#%@";

export const useAppStore = create<AppState>((set) => ({
  characters: DEFAULT_CHARS,
  morphProgress: 0,
  scrollProgress: 0,
  setForeground: false,
  setCharacters: (chars) => set({ characters: chars }),
  setMorphProgress: (progress) => set({ morphProgress: progress }),
  setScrollProgress: (progress) => set({ scrollProgress: progress }),
  setSetForeground: (active) => set({ setForeground: active }),
}));
