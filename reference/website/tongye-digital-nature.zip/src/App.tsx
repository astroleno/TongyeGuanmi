import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import SceneCanvas from './components/webgl/SceneCanvas';
import ScatteredText from './components/text/ScatteredText';
import { useAppStore } from './store';
import { cn } from './lib/utils';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const setScrollProgress = useAppStore((state) => state.setScrollProgress);
  const setMorphProgress = useAppStore((state) => state.setMorphProgress);
  const setCharacters = useAppStore((state) => state.setCharacters);
  
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Intro animation
    const tl = gsap.timeline({
      onComplete: () => setIsLoaded(true)
    });
    
    tl.to('.intro-overlay', {
      opacity: 0,
      duration: 1.5,
      delay: 0.5,
      ease: 'power2.inOut'
    })
    .fromTo('.hero-title', { opacity: 0, y: 50 }, { opacity: 1, y: 0, duration: 1.5, ease: 'expo.out' }, '-=0.5')
    .fromTo('.hero-subtitle', { opacity: 0 }, { opacity: 1, duration: 1, stagger: 0.2 }, '-=1');

    // Scroll trigger for globals
    const scrollTl = gsap.timeline({
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1,
        onUpdate: (self) => {
          setScrollProgress(self.progress);
          // Update morph progress organically along the page
          setMorphProgress(Math.sin(self.progress * Math.PI)); 
        }
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach(t => t.kill());
    };
  }, [setScrollProgress, setMorphProgress]);

  return (
    <main ref={containerRef} className="relative w-full h-[500vh] bg-[#000000] text-[#F2F0E8] overflow-hidden select-none font-sans flex flex-col">
      {/* ASCII / Grid Texture Overlay */}
      <div className="fixed inset-0 opacity-[0.05] pointer-events-none overflow-hidden text-[8px] leading-[8px] font-mono break-all z-0">
        {Array.from({ length: 40 }).map((_, i) => (
          <div key={i} className="whitespace-nowrap">
            {Array.from({ length: 20 }).map(() => '同野TONGYE1010101010101010').join('')}
          </div>
        ))}
      </div>
      
      {/* Large background letter '野' for composition */}
      <div className="fixed bottom-[-100px] left-[-40px] text-[400px] md:text-[600px] font-bold text-[#F2F0E8] opacity-[0.03] leading-none pointer-events-none z-0">
        野
      </div>

      {/* Intro Overlay */}
      <div className="intro-overlay fixed inset-0 z-50 bg-[#000000] pointer-events-none flex items-center justify-center">
        <div className="font-mono text-xs text-[#8B8B82] tracking-widest uppercase">Initializing Site Instance...</div>
      </div>

      <SceneCanvas />
      
      <div className="pointer-events-none fixed inset-0 z-10">
        <div className="pointer-events-auto h-[100vh] overflow-y-auto">
          
          {/* Section 1: Hero */}
          <section className="relative w-full h-[100vh] flex flex-col justify-center px-8 md:px-24">
            
            {/* Nav Rail / Metadata styling injected here to respect existing layout container */}
            <nav className="absolute top-0 left-0 right-0 flex justify-between items-start p-8 z-20 border-b border-[#F2F0E8]/10 pointer-events-auto mix-blend-difference">
              <div className="flex flex-col">
                <span className="text-[10px] font-mono tracking-widest text-[#F2F0E8]/40 mb-1">SYSTEM: ON-SITE</span>
                <div className="text-xl md:text-2xl font-bold tracking-tight text-[#F2F0E8]">同野 TONGYE</div>
              </div>
              <div className="hidden md:flex space-x-12 font-mono text-[10px] tracking-widest uppercase">
                {['Archive / 001', 'Projects / Index', 'Manifesto / Vol', 'Enter / 现场'].map((item, i) => (
                  <a key={i} href="#" className="text-[#F2F0E8]/60 hover:text-[#F2F0E8] transition-colors pb-1 border-b border-transparent hover:border-[#F2F0E8]">
                    {item}
                  </a>
                ))}
              </div>
            </nav>

            {/* Left metadata branding */}
            <div className="absolute left-8 top-1/2 -translate-y-1/2 rotate-[-90deg] origin-left whitespace-nowrap z-10 mix-blend-difference hidden md:block">
              <span className="font-mono text-[9px] tracking-[0.5em] text-[#F2F0E8]/30 italic">LAT: 52.5200° N / LONG: 13.4050° E</span>
            </div>

            <div className="hero-title mix-blend-difference relative z-10">
              <ScatteredText 
                text="同野 TONGYE" 
                className="text-6xl md:text-[110px] font-bold font-sans tracking-tighter leading-[0.85] mb-6" 
                scatterIntensity={50}
              />
            </div>
            <div className="hero-subtitle max-w-xl text-lg md:text-2xl text-[#8B8B82] font-sans font-light mb-12 mix-blend-difference relative z-10 opacity-80">
              <ScatteredText text="在城市与荒野之间，" />
              <div className="h-2" />
              <ScatteredText text="生成新的感知现场。" />
            </div>
            
            <div className="hero-subtitle flex gap-6 mix-blend-difference relative z-10">
              <button className="px-8 py-3 bg-transparent border border-[#F2F0E8] text-[#F2F0E8] font-mono text-[10px] tracking-widest uppercase hover:bg-[#F2F0E8] hover:text-[#050505] transition-colors duration-300">
                进入现场
              </button>
              <button className="px-8 py-3 bg-transparent border border-[#F2F0E8]/10 text-[#F2F0E8]/60 font-mono text-[10px] tracking-widest uppercase hover:text-[#F2F0E8] hover:border-[#F2F0E8]/30 transition-colors duration-300">
                查看项目
              </button>
            </div>
          </section>

          {/* Section 2: Manifesto */}
          <section className="relative w-full h-[100vh] flex items-center justify-end px-8 md:px-24">
            <div className="absolute top-1/3 right-8 md:right-24 text-[10px] font-mono tracking-widest text-[#F2F0E8]/30 mb-4 mix-blend-difference hidden md:block">01 / MANIFESTO</div>
            <div className="max-w-2xl text-xl md:text-[28px] text-[#F2F0E8] font-sans leading-relaxed text-right mix-blend-difference opacity-90 pr-0 md:pr-16">
              <ScatteredText 
                text="同野不是一个地点，而是一种共同进入未知的方式。" 
                className="mb-8"
              />
              <ScatteredText 
                text="我们把自然、身体、声音、影像和代码放在同一片场域中，" 
                className="mb-8"
              />
              <ScatteredText 
                text="让它们互相生长、互相误读、互相变形。" 
              />
            </div>
          </section>

          {/* Section 3: Projects */}
          <section className="relative w-full h-[100vh] flex items-center px-8 md:px-24">
            <div className="absolute top-1/4 left-8 md:left-24 text-[10px] font-mono tracking-widest text-[#F2F0E8]/30 mb-8 mix-blend-difference hidden md:block">02 / PROJECTS INDEX</div>
            <div className="flex flex-col w-full max-w-4xl space-y-2 mix-blend-difference relative z-10 mx-auto md:ml-32 mt-16 md:mt-0">
              {[
                { id: '001', name: 'Field Recording', chars: ' .,:;+=*#%@' },
                { id: '002', name: 'Wild Interface', chars: '01/\\|_-+=<>' },
                { id: '003', name: 'Synthetic Terrain', chars: '同野山风土水木火石' },
                { id: '004', name: 'Night Walk', chars: '░▒▓███████' }
              ].map((project) => (
                <div 
                  key={project.id}
                  className="group flex flex-col md:flex-row md:items-end justify-between py-6 border-b border-[#F2F0E8]/10 hover:border-[#F2F0E8]/40 cursor-pointer transition-colors"
                  onMouseEnter={() => {
                    setCharacters(project.chars);
                    // trigger a small pulse to the morph
                    setMorphProgress(useAppStore.getState().morphProgress + 0.5);
                  }}
                  onMouseLeave={() => {
                    setCharacters(" .,:;+=*#%@");
                  }}
                >
                  <div className="font-mono text-[#F2F0E8]/40 text-xs md:text-sm tracking-widest group-hover:text-[#F2F0E8]/80 transition-colors duration-500 mb-2 md:mb-0">
                    {project.id} /
                  </div>
                  <div className="font-sans text-3xl md:text-5xl font-light text-[#F2F0E8] group-hover:scale-105 origin-left md:origin-right transition-transform duration-500 tracking-tight">
                    <ScatteredText text={project.name} scatterIntensity={15} />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Section 4: Archive */}
          <section className="relative w-full h-[100vh] flex flex-col items-center justify-center px-8 md:px-24">
            <h2 className="text-[10px] font-mono text-[#F2F0E8]/30 mb-8 uppercase tracking-widest w-full max-w-6xl mix-blend-difference">03 / ARCHIVE RECORDS</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 max-w-6xl w-full relative z-10">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="flex flex-col gap-3 group cursor-crosshair border border-[#F2F0E8]/5 bg-[#000000]/40 backdrop-blur-sm p-4 hover:border-[#F2F0E8]/20 transition-colors">
                  <div className="w-full aspect-square bg-[#000000] overflow-hidden relative">
                    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1518531933037-91b2f5f229bd?auto=format&fit=crop&w=500&q=80')] bg-cover bg-center mix-blend-luminosity opacity-40 group-hover:opacity-70 group-hover:scale-105 transition-all duration-700"></div>
                    {/* ASCII noise overlay simulation */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 font-mono text-[6px] md:text-[8px] text-[#F2F0E8] p-4 break-all leading-none bg-[#000000]/80 transition-opacity duration-300 pointer-events-none">
                      {Array.from({length: 400}).map(()=> Math.random() > 0.5 ? '1' : '0').join('')}
                    </div>
                  </div>
                  <div className="font-mono text-[9px] md:text-[10px] text-[#F2F0E8]/40 flex justify-between tracking-widest uppercase items-center">
                    <span>DOC_{100 + item}</span>
                    <span className="w-1.5 h-1.5 bg-[#FF4E00] rounded-full opacity-0 group-hover:opacity-100 group-hover:animate-pulse transition-opacity"></span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Section 5: Contact */}
          <section className="relative w-full h-[100vh] flex flex-col items-center justify-center text-center">
             <div className="mb-12 relative z-10 mix-blend-difference">
              <ScatteredText 
                text="加入同野" 
                className="text-4xl md:text-6xl font-bold font-sans tracking-widest mb-6 text-[#F2F0E8]" 
              />
              <div className="text-[10px] md:text-xs text-[#F2F0E8]/50 font-mono uppercase tracking-widest">
                <ScatteredText text="进入一次共同生成的现场" />
              </div>
            </div>

            <div className="flex gap-12 font-mono text-[#F2F0E8]/80 text-[10px] tracking-widest uppercase relative z-10 mix-blend-difference">
              <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-1">Email</a>
              <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-1">Instagram</a>
              <a href="#" className="hover:text-white transition-colors border-b border-transparent hover:border-white pb-1">Newsletter</a>
            </div>
            
            {/* Bottom Utility Bar styling replacing simple text */}
            <footer className="absolute bottom-0 w-full h-16 border-t border-[#F2F0E8]/10 px-8 flex items-center justify-between z-20 bg-transparent mix-blend-difference backdrop-blur-sm">
              <div className="flex gap-4 md:space-x-8">
                <div className="hidden md:block text-[10px] font-mono">
                  <span className="text-[#F2F0E8]/40">CLOCK:</span> {new Date().toLocaleTimeString()}
                </div>
                <div className="text-[9px] md:text-[10px] font-mono">
                  <span className="text-[#F2F0E8]/40">LOC:</span> BERLIN / TOKYO / WILD
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-[9px] font-mono tracking-widest text-[#F2F0E8]/60">SCROLL TO PERCEIVE</div>
                <div className="w-12 h-[1px] bg-[#F2F0E8]/40 hidden md:block"></div>
              </div>
            </footer>
          </section>

        </div>
      </div>
    </main>
  );
}