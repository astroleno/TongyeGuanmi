import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { cn } from '../../lib/utils';

export default function ScatteredText({ 
  text, 
  className,
  scatterIntensity = 30
}: { 
  text: string;
  className?: string;
  scatterIntensity?: number;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const charsRef = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      charsRef.current.forEach((char, i) => {
        if (!char) return;
        const charRect = char.getBoundingClientRect();
        // local char center relative to container
        const charX = (charRect.left - rect.left) + charRect.width / 2;
        const charY = (charRect.top - rect.top) + charRect.height / 2;

        const distance = Math.hypot(mouseX - charX, mouseY - charY);
        const radius = 100; // impact radius

        if (distance < radius) {
          const angle = Math.atan2(charY - mouseY, charX - mouseX);
          const force = (radius - distance) / radius;
          const pushX = Math.cos(angle) * force * scatterIntensity;
          const pushY = Math.sin(angle) * force * scatterIntensity;
          const rotation = force * (Math.random() * 60 - 30);

          gsap.to(char, {
            x: pushX,
            y: pushY,
            rotation: rotation,
            duration: 0.3,
            ease: 'power2.out',
            overwrite: 'auto'
          });
        } else {
          // snap back
          gsap.to(char, {
            x: 0,
            y: 0,
            rotation: 0,
            duration: 0.8,
            ease: 'elastic.out(1, 0.3)',
            overwrite: 'auto'
          });
        }
      });
    };

    const handleMouseLeave = () => {
      charsRef.current.forEach(char => {
        if (char) {
          gsap.to(char, { x: 0, y: 0, rotation: 0, duration: 1, ease: 'elastic.out(1, 0.5)' });
        }
      });
    };

    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [scatterIntensity]);

  // split text to words then letters to preserve word wrapping
  const words = text.split(' ');
  let globalCharIndex = 0;

  return (
    <div ref={containerRef} className={className}>
      {words.map((word, wordIdx) => (
        <span key={wordIdx} className="inline-block whitespace-nowrap">
          {word.split('').map((char, charIdx) => {
            const index = globalCharIndex++;
            return (
              <span 
                key={charIdx} 
                className="inline-block min-w-[0.25rem] origin-center"
                ref={(el) => (charsRef.current[index] = el)}
              >
                {char}
              </span>
            );
          })}
          {wordIdx < words.length - 1 && <span className="inline-block">&nbsp;</span>}
        </span>
      ))}
    </div>
  );
}
