import { Canvas } from '@react-three/fiber';
import { AsciiRenderer } from '@react-three/drei';
import MorphingEntity from './MorphingEntity';
import { useAppStore } from '../../store';

export default function SceneCanvas() {
  const characters = useAppStore((state) => state.characters);
  const setForeground = useAppStore((state) => state.setForeground);

  // Set Ascii colors based on state
  const fgColor = setForeground ? '#8B8B82' : '#F2F0E8';
  const bgColor = 'transparent';

  return (
    <div className="fixed inset-0 z-0 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <color attach="background" args={['#000000']} />
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 10]} intensity={1} />
        <MorphingEntity />
        <AsciiRenderer 
          fgColor={fgColor} 
          bgColor={bgColor} 
          characters={characters} 
          resolution={0.15} // high res characters
        />
      </Canvas>
    </div>
  );
}
