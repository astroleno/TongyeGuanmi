import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { MorphMaterial } from './MorphShader';
import { useAppStore } from '../../store';

export default function MorphingEntity() {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef(MorphMaterial.clone());
  
  // Track smoothed values to ensure organic movement
  const scrollTarget = useRef(0);
  const morphTarget = useRef(0);
  const pulseTarget = useRef(0);

  useFrame((state, delta) => {
    if (!materialRef.current || !meshRef.current) return;
    
    // Slow rotation
    meshRef.current.rotation.y += delta * 0.15;
    meshRef.current.rotation.x += delta * 0.05;

    // Fetch state from global store
    const { scrollProgress, morphProgress } = useAppStore.getState();

    // Lerp values for smooth transition
    scrollTarget.current = THREE.MathUtils.lerp(scrollTarget.current, scrollProgress, 0.05);
    morphTarget.current = THREE.MathUtils.lerp(morphTarget.current, morphProgress, 0.05);
    
    // Audio pulse decay (if triggered in UI)
    pulseTarget.current = THREE.MathUtils.lerp(pulseTarget.current, 0, 0.08);

    materialRef.current.uniforms.uTime.value = state.clock.getElapsedTime();
    materialRef.current.uniforms.uScroll.value = scrollTarget.current;
    materialRef.current.uniforms.uMorphProgress.value = morphTarget.current;
    materialRef.current.uniforms.uAudioPulse.value = pulseTarget.current;
    
    // Adjust mouse distortion
    const x = (state.pointer.x * 2 - 1) * 0.1;
    const y = -(state.pointer.y * 2 - 1) * 0.1;
    meshRef.current.position.x = THREE.MathUtils.lerp(meshRef.current.position.x, x, 0.05);
    meshRef.current.position.y = THREE.MathUtils.lerp(meshRef.current.position.y, y, 0.05);
  });

  return (
    <mesh ref={meshRef} position={[0, 0, 0]} scale={1.3}>
      <sphereGeometry args={[1, 128, 128]} />
      <primitive object={materialRef.current} attach="material" />
    </mesh>
  );
}
