const THREE_URL = "https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js";

const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const glyphSets = {
  ascii: " .,:;+=*#%@",
  han: " 同野山风土水木火石",
  symbol: " 01/\\|_-+=<>",
};

const state = {
  morph: 0,
  noise: prefersReducedMotion ? 0.12 : 0.28,
  charSize: window.innerWidth < 700 ? 13 : 9.5,
  threshold: 0.12,
  dither: 0.24,
  glitch: 0,
  scan: 0.12,
  breath: prefersReducedMotion ? 0.03 : 0.18,
  foreground: [0.95, 0.94, 0.88],
  background: [0.02, 0.02, 0.018],
};

const pointer = {
  x: window.innerWidth / 2,
  y: window.innerHeight / 2,
  nx: 0,
  ny: 0,
  sx: 0,
  sy: 0,
};

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const lerp = (a, b, t) => a + (b - a) * t;

window.addEventListener("pointermove", (event) => {
  pointer.x = event.clientX;
  pointer.y = event.clientY;
  pointer.nx = (event.clientX / window.innerWidth) * 2 - 1;
  pointer.ny = -(event.clientY / window.innerHeight) * 2 + 1;
});

class PretextField {
  constructor(element) {
    this.element = element;
    this.copy = element.querySelector(".pretext-copy");
    this.text = (this.copy?.textContent || element.textContent || "").replace(/\s+/g, " ").trim();
    this.canvas = document.createElement("canvas");
    this.canvas.className = "pretext-canvas";
    this.ctx = this.canvas.getContext("2d", { alpha: true });
    this.chars = [];
    this.visible = false;
    this.baseSize = Number(element.dataset.size || 18);
    this.leading = Number(element.dataset.leading || 1.45);
    this.minHeight = Number(element.dataset.minHeight || 140);
    this.seed = Math.random() * 1000;
    element.style.setProperty("--pretext-min-height", `${this.minHeight}px`);
    element.appendChild(this.canvas);
    this.layout();
  }

  getFontSize() {
    const width = this.element.clientWidth || 320;
    const mobileScale = width < 560 && this.baseSize > 22 ? 0.72 : 1;
    return clamp(this.baseSize * mobileScale, 12, 34);
  }

  layout() {
    if (!this.ctx) return;
    const rect = this.element.getBoundingClientRect();
    const width = Math.max(120, Math.floor(rect.width));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const fontSize = this.getFontSize();
    const lineHeight = fontSize * this.leading;
    const font = `700 ${fontSize}px "IBM Plex Mono", "SFMono-Regular", Consolas, "Noto Sans SC", monospace`;
    this.ctx.font = font;

    const paddingX = 2;
    let x = paddingX;
    let y = fontSize;
    const nextChars = [];
    const old = this.chars;

    for (let i = 0; i < this.text.length; i += 1) {
      const char = this.text[i];
      const measure = this.ctx.measureText(char === " " ? "·" : char);
      const charWidth = Math.max(measure.width, fontSize * 0.34);
      if (x + charWidth > width - paddingX && char !== " ") {
        x = paddingX;
        y += lineHeight;
      }
      const previous = old[i];
      const targetX = x;
      const targetY = y;
      const spread = 120 + (i % 9) * 8;
      nextChars.push({
        char,
        targetX,
        targetY,
        x: previous ? previous.x : targetX + (Math.random() - 0.5) * spread,
        y: previous ? previous.y : targetY + (Math.random() - 0.5) * spread,
        vx: previous ? previous.vx : 0,
        vy: previous ? previous.vy : 0,
        alpha: previous ? previous.alpha : 0,
        width: charWidth,
        jitter: Math.random() * Math.PI * 2,
      });
      x += charWidth;
    }

    const height = Math.max(this.minHeight, Math.ceil(y + lineHeight * 0.75));
    this.canvas.width = Math.floor(width * dpr);
    this.canvas.height = Math.floor(height * dpr);
    this.canvas.style.height = `${height}px`;
    this.element.style.setProperty("--pretext-height", `${height}px`);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ctx.font = font;
    this.ctx.textBaseline = "alphabetic";
    this.chars = nextChars;
    this.width = width;
    this.height = height;
    this.font = font;
    this.fontSize = fontSize;
  }

  burst(amount = 80) {
    for (const item of this.chars) {
      const angle = Math.atan2(item.y - this.height / 2, item.x - this.width / 2) + (Math.random() - 0.5) * 0.8;
      const force = amount * (0.35 + Math.random() * 0.9);
      item.vx += Math.cos(angle) * force;
      item.vy += Math.sin(angle) * force;
      item.alpha = Math.max(item.alpha, 0.45);
    }
  }

  scramble() {
    for (const item of this.chars) {
      item.x = Math.random() * this.width;
      item.y = Math.random() * this.height;
      item.vx = (Math.random() - 0.5) * 40;
      item.vy = (Math.random() - 0.5) * 40;
      item.alpha = 0.12;
    }
  }

  draw(time) {
    if (!this.ctx) return;
    const rect = this.canvas.getBoundingClientRect();
    const mx = pointer.x - rect.left;
    const my = pointer.y - rect.top;
    const inside = mx > -80 && mx < rect.width + 80 && my > -80 && my < rect.height + 80;
    const radius = Math.min(180, Math.max(92, rect.width * 0.16));

    this.ctx.clearRect(0, 0, this.width, this.height);
    this.ctx.font = this.font;
    this.ctx.textBaseline = "alphabetic";

    for (let i = 0; i < this.chars.length; i += 1) {
      const item = this.chars[i];
      let tx = item.targetX;
      let ty = item.targetY;

      if (inside) {
        const dx = tx - mx;
        const dy = ty - my;
        const distance = Math.sqrt(dx * dx + dy * dy) || 1;
        if (distance < radius) {
          const power = Math.pow(1 - distance / radius, 2);
          tx += (dx / distance) * power * 96;
          ty += (dy / distance) * power * 72;
          tx += Math.sin(time * 0.002 + item.jitter) * power * 20;
        }
      }

      item.vx += (tx - item.x) * 0.06;
      item.vy += (ty - item.y) * 0.06;
      item.vx *= 0.77;
      item.vy *= 0.77;
      item.x += item.vx * 0.12;
      item.y += item.vy * 0.12;
      item.alpha = lerp(item.alpha, this.visible ? 0.92 : 0.36, 0.035);

      if (item.char === " ") continue;
      const accent = i % 17 === 0 || /[同野]/.test(item.char);
      this.ctx.fillStyle = accent
        ? `rgba(197, 255, 74, ${item.alpha * 0.8})`
        : `rgba(242, 240, 232, ${item.alpha})`;
      this.ctx.fillText(item.char, item.x, item.y);
    }
  }
}

function createPretextFields() {
  const fields = Array.from(document.querySelectorAll(".pretext-target")).map((element) => new PretextField(element));
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        const field = fields.find((candidate) => candidate.element === entry.target);
        if (!field) continue;
        field.visible = entry.isIntersecting;
        if (entry.isIntersecting) field.scramble();
      }
    },
    { threshold: 0.18 }
  );
  fields.forEach((field) => observer.observe(field.element));

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(() => fields.forEach((field) => field.layout()), 120);
  });

  function frame(time) {
    fields.forEach((field) => field.draw(time));
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  return fields;
}

function makeGlyphAtlas(THREE, chars) {
  const list = Array.from(chars);
  const cell = 72;
  const canvas = document.createElement("canvas");
  canvas.width = cell * list.length;
  canvas.height = cell;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = `800 ${Math.floor(cell * 0.72)}px "IBM Plex Mono", "SFMono-Regular", Consolas, "Noto Sans SC", monospace`;
  ctx.fillStyle = "white";
  list.forEach((char, index) => {
    const draw = char === " " ? "·" : char;
    ctx.globalAlpha = char === " " ? 0.05 : 1;
    ctx.fillText(draw, index * cell + cell / 2, cell / 2 + 2);
  });
  ctx.globalAlpha = 1;

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.needsUpdate = true;
  return { texture, count: list.length };
}

async function loadThree() {
  try {
    return await import(THREE_URL);
  } catch (error) {
    console.warn("Three.js could not be loaded. Static fallback remains visible.", error);
    document.body.classList.add("webgl-failed");
    return null;
  }
}

function initWebGL(THREE) {
  const canvas = document.getElementById("webgl");
  if (!canvas) return null;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      alpha: false,
      powerPreference: "high-performance",
    });
  } catch (error) {
    console.warn("WebGL is not available.", error);
    document.body.classList.add("webgl-failed");
    return null;
  }

  renderer.setClearColor(0x050505, 1);
  renderer.autoClear = true;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 20);
  camera.position.set(0, 0, 4.25);

  const target = new THREE.WebGLRenderTarget(1, 1, {
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    depthBuffer: true,
    stencilBuffer: false,
  });

  const geometryDetail = window.innerWidth < 700 ? 64 : 112;
  const geometry = new THREE.SphereGeometry(1.12, geometryDetail, geometryDetail);
  const blobMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uMorph: { value: 0 },
      uNoiseStrength: { value: state.noise },
      uBreath: { value: state.breath },
      uMouse: { value: new THREE.Vector2(0, 0) },
    },
    vertexShader: `
      precision highp float;
      uniform float uTime;
      uniform float uMorph;
      uniform float uNoiseStrength;
      uniform float uBreath;
      uniform vec2 uMouse;
      varying vec3 vNormalView;
      varying vec3 vView;
      varying vec2 vUv;
      varying float vField;

      float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
      }

      float noise(vec3 x) {
        vec3 i = floor(x);
        vec3 f = fract(x);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(
            mix(hash(i + vec3(0.0, 0.0, 0.0)), hash(i + vec3(1.0, 0.0, 0.0)), f.x),
            mix(hash(i + vec3(0.0, 1.0, 0.0)), hash(i + vec3(1.0, 1.0, 0.0)), f.x),
            f.y
          ),
          mix(
            mix(hash(i + vec3(0.0, 0.0, 1.0)), hash(i + vec3(1.0, 0.0, 1.0)), f.x),
            mix(hash(i + vec3(0.0, 1.0, 1.0)), hash(i + vec3(1.0, 1.0, 1.0)), f.x),
            f.y
          ),
          f.z
        );
      }

      float fbm(vec3 p) {
        float total = 0.0;
        float amp = 0.5;
        for (int i = 0; i < 5; i++) {
          total += noise(p) * amp;
          p = p * 2.03 + vec3(9.2, 3.1, 4.7);
          amp *= 0.5;
        }
        return total;
      }

      void main() {
        vec3 nrm = normalize(normal);
        vec3 p = position;
        float time = uTime * 0.24;
        float organic = fbm(nrm * 2.6 + vec3(time, -time * 0.7, time * 0.43));
        float fine = fbm(p * 7.2 - vec3(time * 1.5, time * 0.2, time * 0.8));
        float ridge = sin((p.x * 2.0 + p.y * 2.9 + p.z * 1.4) * 3.8 + uTime * 1.15) * 0.5 + 0.5;

        vec3 sphere = nrm * (1.03 + (organic - 0.5) * uNoiseStrength + (fine - 0.5) * uNoiseStrength * 0.45 + sin(uTime * 1.6) * uBreath * 0.04);
        vec3 terrain = sphere;
        terrain.x *= 1.42;
        terrain.z *= 0.62 + 0.16 * sin(uTime * 0.42);
        terrain.y = terrain.y * 0.42 + (organic - 0.5) * 0.88 + ridge * 0.18;

        vec3 wave = sphere + nrm * sin((p.x + p.y * 1.4 + p.z * 0.8) * 5.0 + uTime * 1.25) * 0.24;
        wave.x += sin(p.y * 5.0 + uTime) * 0.08;

        float cell = hash(floor((p + 1.4) * 8.0));
        vec3 fragment = mix(wave, nrm * (1.4 + fine * 1.08 + cell * 0.34), 0.62);
        fragment.xz *= 1.0 + 0.18 * sin(uTime + p.y * 6.0);
        fragment.y += (cell - 0.5) * 0.36;

        vec3 seed = nrm * (0.62 + (organic - 0.5) * 0.18);
        seed.y *= 1.46;
        seed.xz *= 0.72;
        seed.y += sin(p.x * 8.0 + uTime * 0.8) * 0.035;

        float a = smoothstep(0.0, 1.0, uMorph);
        float b = smoothstep(1.0, 2.0, uMorph);
        float c = smoothstep(2.15, 3.25, uMorph);
        vec3 morphed = mix(sphere, terrain, a);
        morphed = mix(morphed, fragment, b);
        morphed = mix(morphed, seed, c);
        morphed.x += uMouse.x * 0.13 * (1.0 - c);
        morphed.y += uMouse.y * 0.1 * (1.0 - c);

        vec4 mv = modelViewMatrix * vec4(morphed, 1.0);
        vNormalView = normalize(normalMatrix * nrm);
        vView = -mv.xyz;
        vUv = uv;
        vField = organic + fine * 0.5 + ridge * 0.2;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: `
      precision highp float;
      uniform float uTime;
      varying vec3 vNormalView;
      varying vec3 vView;
      varying vec2 vUv;
      varying float vField;

      void main() {
        vec3 normal = normalize(vNormalView);
        vec3 viewDir = normalize(vView);
        vec3 lightDir = normalize(vec3(-0.45, 0.76, 0.56));
        float light = max(dot(normal, lightDir), 0.0);
        float rim = pow(1.0 - max(dot(normal, viewDir), 0.0), 1.85);
        float contour = 0.5 + 0.5 * sin((vUv.y + vField * 0.08) * 42.0 + uTime * 1.1);
        float shade = light * 0.72 + rim * 0.92 + vField * 0.26 + contour * 0.08;
        shade = smoothstep(0.12, 1.28, shade);
        gl_FragColor = vec4(vec3(shade), 1.0);
      }
    `,
  });

  const blob = new THREE.Mesh(geometry, blobMaterial);
  scene.add(blob);

  const screenScene = new THREE.Scene();
  const screenCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const atlas = makeGlyphAtlas(THREE, glyphSets.ascii);
  const screenMaterial = new THREE.ShaderMaterial({
    depthWrite: false,
    depthTest: false,
    uniforms: {
      tDiffuse: { value: target.texture },
      tGlyphs: { value: atlas.texture },
      uGlyphCount: { value: atlas.count },
      uResolution: { value: new THREE.Vector2(1, 1) },
      uTime: { value: 0 },
      uCharSize: { value: state.charSize },
      uThreshold: { value: state.threshold },
      uDither: { value: state.dither },
      uGlitch: { value: state.glitch },
      uScan: { value: state.scan },
      uForeground: { value: new THREE.Vector3(...state.foreground) },
      uBackground: { value: new THREE.Vector3(...state.background) },
    },
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,
    fragmentShader: `
      precision highp float;
      uniform sampler2D tDiffuse;
      uniform sampler2D tGlyphs;
      uniform float uGlyphCount;
      uniform vec2 uResolution;
      uniform float uTime;
      uniform float uCharSize;
      uniform float uThreshold;
      uniform float uDither;
      uniform float uGlitch;
      uniform float uScan;
      uniform vec3 uForeground;
      uniform vec3 uBackground;
      varying vec2 vUv;

      float rand(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }

      void main() {
        vec2 frag = gl_FragCoord.xy;
        float charSize = max(uCharSize, 4.0);
        vec2 cell = floor(frag / charSize);
        vec2 cellUv = fract(frag / charSize);
        vec2 sampleUv = (cell + 0.5) * charSize / uResolution;

        float rowNoise = rand(vec2(cell.y, floor(uTime * 13.0)));
        float jump = step(0.94, rowNoise) * (rowNoise - 0.5) * uGlitch * 0.055;
        sampleUv.x += jump;
        sampleUv = clamp(sampleUv, vec2(0.0), vec2(1.0));

        vec3 src = texture2D(tDiffuse, sampleUv).rgb;
        float lum = dot(src, vec3(0.299, 0.587, 0.114));
        float dither = (rand(cell + floor(uTime * 2.0)) - 0.5) * uDither;
        float signal = clamp(lum + dither, 0.0, 1.0);
        float density = smoothstep(uThreshold, 0.92, signal);
        float glyphIndex = floor(clamp(signal * (uGlyphCount - 1.0), 0.0, uGlyphCount - 1.0));
        vec2 glyphUv = vec2((glyphIndex + cellUv.x) / uGlyphCount, cellUv.y);
        float glyph = texture2D(tGlyphs, glyphUv).r;

        float bgSpark = step(0.992, rand(cell + floor(uTime * 5.0))) * 0.18;
        float mask = max(glyph * density, bgSpark * (1.0 - density));
        float scan = 0.93 + 0.07 * sin(frag.y * 1.7 + uTime * 8.0);
        float verticalScan = 0.96 + 0.04 * sin(frag.x * 0.22 + uTime * 0.6);
        vec3 color = mix(uBackground, uForeground, mask * scan * verticalScan);
        color += uForeground * density * 0.045;
        color += vec3(0.55, 1.0, 0.22) * bgSpark * 0.12;
        color *= 1.0 - uScan * 0.1 * sin(frag.y * 0.045 + uTime * 1.8);
        gl_FragColor = vec4(color, 1.0);
      }
    `,
  });

  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), screenMaterial);
  screenScene.add(quad);

  let dpr = 1;
  function resize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    dpr = Math.min(window.devicePixelRatio || 1, window.innerWidth < 700 ? 1.25 : 1.65);
    renderer.setPixelRatio(dpr);
    renderer.setSize(width, height, false);
    target.setSize(Math.max(1, Math.floor(width * dpr)), Math.max(1, Math.floor(height * dpr)));
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    screenMaterial.uniforms.uResolution.value.set(width * dpr, height * dpr);
  }

  function setGlyphSet(name) {
    const chars = glyphSets[name] || glyphSets.ascii;
    const next = makeGlyphAtlas(THREE, chars);
    const previous = screenMaterial.uniforms.tGlyphs.value;
    screenMaterial.uniforms.tGlyphs.value = next.texture;
    screenMaterial.uniforms.uGlyphCount.value = next.count;
    if (previous && previous.dispose) previous.dispose();
  }

  window.addEventListener("resize", resize);
  resize();

  const clock = new THREE.Clock();
  function render() {
    requestAnimationFrame(render);
    const elapsed = clock.getElapsedTime();
    pointer.sx = lerp(pointer.sx, pointer.nx, 0.055);
    pointer.sy = lerp(pointer.sy, pointer.ny, 0.055);

    blob.rotation.y = elapsed * (prefersReducedMotion ? 0.035 : 0.105);
    blob.rotation.x = Math.sin(elapsed * 0.18) * 0.12 + pointer.sy * 0.08;
    blob.rotation.z = Math.sin(elapsed * 0.11) * 0.08 + pointer.sx * 0.05;

    blobMaterial.uniforms.uTime.value = elapsed;
    blobMaterial.uniforms.uMorph.value = state.morph;
    blobMaterial.uniforms.uNoiseStrength.value = state.noise;
    blobMaterial.uniforms.uBreath.value = state.breath;
    blobMaterial.uniforms.uMouse.value.set(pointer.sx, pointer.sy);

    screenMaterial.uniforms.uTime.value = elapsed;
    screenMaterial.uniforms.uCharSize.value = state.charSize * dpr;
    screenMaterial.uniforms.uThreshold.value = state.threshold;
    screenMaterial.uniforms.uDither.value = state.dither;
    screenMaterial.uniforms.uGlitch.value = state.glitch;
    screenMaterial.uniforms.uScan.value = state.scan;

    renderer.setRenderTarget(target);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    renderer.clear();
    renderer.render(screenScene, screenCamera);
  }
  render();

  return { setGlyphSet };
}

function initMotion(fields, webgl) {
  const gsap = window.gsap;
  const ScrollTrigger = window.ScrollTrigger;
  const bootMask = document.getElementById("bootMask");
  const coord = document.getElementById("coord");

  if (!gsap) {
    if (bootMask) bootMask.style.display = "none";
    return;
  }

  if (ScrollTrigger) gsap.registerPlugin(ScrollTrigger);

  gsap.timeline({ defaults: { ease: "power3.out" } })
    .to(bootMask, { opacity: 0, duration: 0.7, delay: 0.55, onComplete: () => bootMask?.remove() })
    .from(".hero-title span", { yPercent: 86, opacity: 0, duration: 1.2, stagger: 0.08 }, 0.36)
    .from(".eyebrow, .section-meta, .hero-data span, .cta-row .button", { y: 18, opacity: 0, duration: 0.8, stagger: 0.055 }, 0.58);

  if (ScrollTrigger && !prefersReducedMotion) {
    gsap.timeline({
      scrollTrigger: {
        trigger: ".site-shell",
        start: "top top",
        end: "bottom bottom",
        scrub: 1.15,
      },
    })
      .to(state, { morph: 0.25, noise: 0.26, charSize: 10.5, dither: 0.2, threshold: 0.12, scan: 0.08 }, 0)
      .to(state, { morph: 1.05, noise: 0.46, charSize: 9.2, dither: 0.34, threshold: 0.1, scan: 0.16 }, 0.25)
      .to(state, { morph: 2.15, noise: 0.66, charSize: 8.2, dither: 0.48, threshold: 0.08, glitch: 0.18, scan: 0.22 }, 0.5)
      .to(state, { morph: 2.72, noise: 0.54, charSize: 7.8, dither: 0.58, threshold: 0.07, glitch: 0.3, scan: 0.46 }, 0.74)
      .to(state, { morph: 3.28, noise: 0.22, charSize: 12.8, dither: 0.22, threshold: 0.16, glitch: 0.02, scan: 0.15 }, 1);

    document.querySelectorAll(".section").forEach((section) => {
      ScrollTrigger.create({
        trigger: section,
        start: "top 45%",
        end: "bottom 45%",
        onEnter: () => activateSection(section),
        onEnterBack: () => activateSection(section),
      });
    });
  }

  function activateSection(section) {
    const glyph = section.dataset.glyph || "ascii";
    webgl?.setGlyphSet(glyph);
    document.body.dataset.section = section.id;
    if (coord) {
      const index = String(Number(section.dataset.section || 0) + 1).padStart(3, "0");
      coord.textContent = `FIELD ${index} / ${section.dataset.state?.toUpperCase() || "LIVE"}`;
    }
  }

  document.querySelectorAll("[data-pulse]").forEach((element) => {
    element.addEventListener("pointerenter", () => {
      fields.forEach((field) => field.burst(40));
      gsap.to(state, { glitch: 0.62, dither: 0.62, duration: 0.18, overwrite: "auto" });
      gsap.to(state, { glitch: 0.04, dither: 0.28, duration: 0.68, delay: 0.18, ease: "power2.out", overwrite: "auto" });
    });
  });

  const preview = document.getElementById("projectPreview");
  document.querySelectorAll(".project-row").forEach((row) => {
    const enter = () => {
      const title = row.querySelector("h3")?.textContent || "PROJECT";
      if (preview) {
        preview.querySelector("span").textContent = title.toUpperCase();
        preview.querySelector("strong").textContent = row.dataset.preview || "实时改变字符场";
      }
      webgl?.setGlyphSet(row.dataset.glyphset || "ascii");
      fields.forEach((field) => field.burst(18));
      gsap.to(state, {
        morph: Number(row.dataset.morph || state.morph),
        glitch: 0.36,
        dither: 0.56,
        noise: 0.58,
        duration: 0.56,
        ease: "power3.out",
        overwrite: "auto",
      });
    };
    const leave = () => {
      gsap.to(state, { glitch: 0.08, dither: 0.34, noise: 0.36, duration: 0.7, ease: "power2.out", overwrite: "auto" });
    };
    row.addEventListener("pointerenter", enter);
    row.addEventListener("focus", enter);
    row.addEventListener("pointerleave", leave);
    row.addEventListener("blur", leave);
  });

  document.querySelectorAll(".signal-list li").forEach((item, index) => {
    item.addEventListener("pointerenter", () => {
      webgl?.setGlyphSet(index % 2 ? "symbol" : "han");
      gsap.to(state, { morph: 0.6 + index * 0.24, noise: 0.48, glitch: 0.18, duration: 0.42, overwrite: "auto" });
    });
  });
}

function initCoordinateTicker() {
  const coord = document.getElementById("coord");
  if (!coord) return;
  window.addEventListener("pointermove", () => {
    const lat = (31.2304 + pointer.ny * 0.012).toFixed(4);
    const lng = (121.4737 + pointer.nx * 0.018).toFixed(4);
    if (!document.body.dataset.section || document.body.dataset.section === "hero") {
      coord.textContent = `${lat}°N / ${lng}°E`;
    }
  });
}

async function main() {
  document.documentElement.classList.add("js-ready");
  const fields = createPretextFields();
  initCoordinateTicker();
  const THREE = await loadThree();
  const webgl = THREE ? initWebGL(THREE) : null;
  initMotion(fields, webgl);
}

main();
