# 同野 TONGYE — WebGL 字符地貌网站原型

这是一个可直接交给前端继续开发的静态网页原型，包含：

- Three.js WebGL morphing blob
- GLSL vertex noise displacement
- FBO → ASCII / character threshold shader
- GSAP ScrollTrigger 滚动 scrub 形态参数
- Pretext-like canvas 字符避让、散开、重组交互
- Hero / Manifesto / Projects / Archive / Contact 五屏结构
- prefers-reduced-motion 与移动端降级

## 本地运行

由于页面使用 ES Module CDN 加载 Three.js，请用本地服务器打开，不要直接双击 `index.html`。

```bash
cd tongye-site
python3 -m http.server 5173
```

然后打开：

```txt
http://localhost:5173
```

## 文件说明

```txt
index.html   页面结构与语义内容
styles.css   视觉、布局、响应式与静态 fallback
app.js       WebGL、shader、GSAP、Pretext-like 交互
```

## 继续工程化建议

MVP 已经把核心体验串起来了。正式工程可以迁到：

```txt
Next.js + TypeScript + @react-three/fiber + GSAP + Tailwind CSS
```

建议拆分为：

```txt
/components/webgl/MorphingEntity.tsx
/components/webgl/AsciiThresholdPass.tsx
/components/text/InteractivePretextBlock.tsx
/components/sections/HeroSection.tsx
/components/sections/ManifestoSection.tsx
/components/sections/ProjectsSection.tsx
/components/sections/ArchiveSection.tsx
/components/sections/ContactSection.tsx
```

当前 `Pretext` 部分是自实现的 canvas 字符布局与避让系统，命名为 Pretext-like，方便先验证体验。正式版可以换成官方 Pretext 布局库，只保留当前的字符物理和渲染层。
