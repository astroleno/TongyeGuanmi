# DICE Berlin GSAP scroll morph replica

这是一个静态前端交互复刻包，重点复刻以下动效结构：

- GSAP + ScrollTrigger 的 pinned scrub 长滚动。
- 中央渐变 blob 通过 `clip-path`、`border-radius`、位移、旋转和缩放进行滚动变形。
- “D / I / C / E” 大字母分成前后两层，滚动时通过 `clip-path` 让 blob 和文字产生前后遮挡。
- Lineup 文本复制成 back/front 两组，同步滚动；front 层被椭圆 mask 裁切，因此文字会像从 blob 前后穿过一样出现。
- 后续 section 使用字词级 blur / y 位移动画，保持原站的海报式排版节奏。

## 运行方式

最简单：直接打开 `index.html`。

建议本地起一个静态服务，避免浏览器对本地文件的限制：

```bash
cd dice-berlin-gsap-clone
python3 -m http.server 5173
# 然后打开 http://localhost:5173
```

> GSAP 通过 jsDelivr CDN 加载。如果你需要完全离线运行，请把 `gsap.min.js` 和 `ScrollTrigger.min.js` 下载到本地，然后替换 `index.html` 底部两个 CDN `<script>`。

## 文件结构

```text
dice-berlin-gsap-clone/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
├── assets/
│   └── favicon.svg
├── package.json
└── README.md
```

## 主要可调位置

- `js/app.js` 里的 `initHeroScroll()`：核心滚动时间线。
- `js/app.js` 里的 `lineup` 数组：滚动人物名单。
- `css/styles.css` 里的 `.blob--main`：渐变、纹理和初始形态。
- `css/styles.css` 里的 `.letter-layer--front`、`.lineup-track--front`：前后叠加和遮罩范围。

## 版权和素材说明

此包没有下载或嵌入 dice.berlin 的官方图片、字体、商标文件或媒体资产。视觉元素使用 CSS 渐变、系统字体和自制 SVG favicon 重建。你可以把文案、色彩、字体和真实媒体替换成自己的项目素材。
