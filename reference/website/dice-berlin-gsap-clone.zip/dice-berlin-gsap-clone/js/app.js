(() => {
  const qs = (selector, scope = document) => scope.querySelector(selector);
  const qsa = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const lineup = [
    "Ami Dang",
    "Marie Davidson & L’Œil Nu",
    "Born in Flamez",
    "Mhysa",
    "Deena Abdelwahed",
    "Kikelemo",
    "Tayhana",
    "DJ Haram",
    "Bishi",
    "Elisita Punto",
    "Nailah Hunter",
    "Isabel Val",
    "Olivia Jack",
    "Dornika Kazerani",
    "Culture Funding Watch Tunisia",
    "Michelle Lai",
    "Naima Amazigh",
    "Camilla Padgitt-Coles",
    "Noah Gokul / bindiram",
    "Anahita Neghabat & Caren Miesenberger",
    "Cru Encarnação",
    "Daily Rhythms Collective",
    "Angel-Ho",
    "Dasychira",
    "Nadine Schildhauer",
    "Anthony Hüseyin",
    "Jenifa Mayanja",
    "+ more to follow"
  ];

  document.documentElement.classList.add("js");

  function buildLineup() {
    const html = lineup
      .map((name, index) => `<div class="line-row" data-row="${index}"><span>${name}</span></div>`)
      .join("");

    qsa(".line-set").forEach((set) => {
      set.innerHTML = html;
      set.setAttribute("aria-hidden", "true");
    });
  }

  function splitChars(element) {
    const text = element.textContent;
    const label = text.replace(/\s+/g, " ").trim();
    element.setAttribute("aria-label", label);
    element.textContent = "";

    Array.from(text).forEach((char) => {
      if (/\s/.test(char)) {
        const space = document.createElement("span");
        space.className = "char-space";
        space.setAttribute("aria-hidden", "true");
        space.innerHTML = "&nbsp;";
        element.appendChild(space);
        return;
      }

      const span = document.createElement("span");
      span.className = "char";
      span.setAttribute("aria-hidden", "true");
      span.textContent = char;
      element.appendChild(span);
    });
  }

  function splitWords(element) {
    const text = element.textContent.replace(/\s+/g, " ").trim();
    element.setAttribute("aria-label", text);
    element.textContent = "";

    text.split(" ").forEach((word, index, words) => {
      const span = document.createElement("span");
      span.className = "word";
      span.setAttribute("aria-hidden", "true");
      span.textContent = word;
      element.appendChild(span);

      if (index < words.length - 1) {
        const space = document.createElement("span");
        space.className = "word-space";
        space.setAttribute("aria-hidden", "true");
        space.innerHTML = "&nbsp;";
        element.appendChild(space);
      }
    });
  }

  function prepareSplitText() {
    qsa(".split-chars").forEach(splitChars);
    qsa(".split-words").forEach(splitWords);
  }

  function initRecordingControls() {
    qsa("[data-toggle-record]").forEach((button) => {
      const type = button.dataset.toggleRecord;
      const label = type === "blob" ? "blob recording" : "BG recording";

      button.addEventListener("click", () => {
        const isPressed = button.getAttribute("aria-pressed") === "true";
        button.setAttribute("aria-pressed", String(!isPressed));
        button.textContent = `${isPressed ? "Start" : "Stop"} ${label}`;
        document.body.classList.toggle(`record-${type}`, !isPressed);
      });
    });
  }

  function initFallbackMenu() {
    const panel = qs("#menu-panel");
    const toggle = qs(".menu-toggle");
    const close = qs(".menu-close");
    const links = qsa(".menu-link");

    if (!panel || !toggle || !close) return;

    const open = () => {
      panel.classList.add("is-open");
      panel.setAttribute("aria-hidden", "false");
      toggle.setAttribute("aria-expanded", "true");
      panel.style.opacity = "1";
      panel.style.visibility = "visible";
    };

    const shut = () => {
      panel.classList.remove("is-open");
      panel.setAttribute("aria-hidden", "true");
      toggle.setAttribute("aria-expanded", "false");
      panel.style.opacity = "";
      panel.style.visibility = "";
    };

    toggle.addEventListener("click", open);
    close.addEventListener("click", shut);
    links.forEach((link) => link.addEventListener("click", shut));
    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") shut();
    });
  }

  buildLineup();
  prepareSplitText();
  initRecordingControls();

  if (!window.gsap || !window.ScrollTrigger) {
    document.body.classList.add("no-gsap");
    initFallbackMenu();
    return;
  }

  gsap.registerPlugin(ScrollTrigger);
  gsap.config({ nullTargetWarn: false });

  if (prefersReducedMotion) {
    document.body.classList.add("reduced-motion");
    initFallbackMenu();
    return;
  }

  function initMenu() {
    const panel = qs("#menu-panel");
    const toggle = qs(".menu-toggle");
    const close = qs(".menu-close");
    const links = qsa(".menu-link");

    if (!panel || !toggle || !close) return;

    gsap.set(panel, { autoAlpha: 0 });
    gsap.set(".menu-panel__background", { scaleY: 0 });
    gsap.set(".menu-link", { yPercent: 115, autoAlpha: 0 });

    const menuTl = gsap.timeline({
      paused: true,
      defaults: { ease: "power3.out" },
      onReverseComplete: () => {
        panel.classList.remove("is-open");
        panel.setAttribute("aria-hidden", "true");
      }
    });

    menuTl
      .set(panel, { autoAlpha: 1 })
      .to(".menu-panel__background", { scaleY: 1, duration: 0.58, ease: "expo.out" }, 0)
      .to(".menu-link", { yPercent: 0, autoAlpha: 1, duration: 0.7, stagger: 0.055 }, 0.12);

    const open = () => {
      panel.classList.add("is-open");
      panel.setAttribute("aria-hidden", "false");
      toggle.setAttribute("aria-expanded", "true");
      menuTl.play(0);
    };

    const shut = () => {
      toggle.setAttribute("aria-expanded", "false");
      menuTl.reverse();
    };

    toggle.addEventListener("click", open);
    close.addEventListener("click", shut);
    links.forEach((link) => link.addEventListener("click", shut));
    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") shut();
    });
  }

  function initCursor() {
    const cursor = qs(".cursor-orb");
    if (!cursor || !window.matchMedia("(pointer: fine)").matches) return;

    window.addEventListener("pointermove", (event) => {
      gsap.to(cursor, {
        x: event.clientX,
        y: event.clientY,
        duration: 0.35,
        ease: "power3.out"
      });
    });

    qsa("a, button, input").forEach((element) => {
      element.addEventListener("pointerenter", () => gsap.to(cursor, { scale: 1.9, duration: 0.25 }));
      element.addEventListener("pointerleave", () => gsap.to(cursor, { scale: 1, duration: 0.25 }));
    });
  }

  function initLoadAnimation() {
    gsap.set(".scene--theme, .scene--featuring, .scene--outro", { autoAlpha: 0 });
    gsap.set(".scene--theme .char, .scene--featuring .char, .scene--outro .char", {
      autoAlpha: 0,
      yPercent: 90,
      rotateX: -65,
      transformOrigin: "50% 80%",
      filter: "blur(16px)"
    });
    gsap.set(".scene--outro .ghost-cta", { autoAlpha: 0, y: 26 });
    gsap.set(".line-row", { autoAlpha: 0, y: 70, filter: "blur(14px)" });
    gsap.set(".line-set", { yPercent: 36 });

    const loadTl = gsap.timeline({ defaults: { ease: "power4.out" } });

    loadTl
      .from(".site-header", { y: -30, autoAlpha: 0, duration: 0.75 }, 0)
      .from(".letter-layer--back .letter", {
        autoAlpha: 0,
        xPercent: (index) => [-16, 16, -18, 14][index],
        yPercent: (index) => [-14, 10, 16, -10][index],
        scale: 0.94,
        duration: 1.2,
        stagger: 0.055
      }, 0.08)
      .from(".letter-layer--front .letter", {
        autoAlpha: 0,
        xPercent: (index) => [-12, 12, -14, 10][index],
        yPercent: (index) => [-10, 8, 12, -8][index],
        scale: 0.96,
        duration: 1.05,
        stagger: 0.045
      }, 0.18)
      .from(".blob-shell", { autoAlpha: 0, scale: 0.35, rotate: -24, duration: 1.15 }, 0.18)
      .from(".scene--date .char", {
        autoAlpha: 0,
        yPercent: 115,
        rotateX: -72,
        filter: "blur(18px)",
        duration: 0.78,
        stagger: { each: 0.008, from: "random" }
      }, 0.45)
      .from(".hero-controls .mini-control", { autoAlpha: 0, y: -12, duration: 0.5, stagger: 0.06 }, 0.72);
  }

  function initHeroScroll() {
    const backRows = qsa(".line-set--back .line-row");
    const frontRows = qsa(".line-set--front .line-row");
    const rowPairs = backRows.map((row, index) => [row, frontRows[index]].filter(Boolean));

    const heroTl = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: () => `+=${Math.max(window.innerHeight * 5.8, 4200)}`,
        scrub: 0.85,
        pin: ".hero-pin",
        anticipatePin: 1,
        invalidateOnRefresh: true
      }
    });

    heroTl
      .to(".hero-progress span", { scaleX: 1, duration: 4.7 }, 0)
      .to(".marquee", { xPercent: -12, duration: 4.7 }, 0)
      .to(".blob-shell", { x: "-8vw", y: "1.5vh", rotate: 31, scale: 1.12, duration: 0.9 }, 0)
      .to(".blob--main", {
        clipPath: "polygon(23% 2%, 69% 0%, 99% 34%, 93% 73%, 54% 100%, 18% 88%, 0% 56%, 9% 18%)",
        borderRadius: "47% 53% 39% 61% / 58% 37% 63% 42%",
        duration: 0.9
      }, 0)
      .to(".letter--d", { x: "-5vw", y: "-4vh", scale: 0.98, duration: 0.9 }, 0)
      .to(".letter--i", { x: "4vw", y: "-3vh", scale: 1.02, duration: 0.9 }, 0)
      .to(".letter--c", { x: "-6vw", y: "4vh", scale: 1.01, duration: 0.9 }, 0)
      .to(".letter--e", { x: "5vw", y: "4vh", scale: 0.98, duration: 0.9 }, 0)
      .to(".letter-layer--front", { clipPath: "inset(0 0 0 43%)", duration: 0.9 }, 0)
      .to(".scene--date .char", {
        autoAlpha: 0,
        yPercent: -110,
        rotateX: 70,
        filter: "blur(18px)",
        duration: 0.58,
        stagger: { each: 0.006, from: "end" },
        ease: "power2.inOut"
      }, 0.22)
      .to(".scene--theme", { autoAlpha: 1, duration: 0.01 }, 0.48)
      .to(".scene--theme .char", {
        autoAlpha: 1,
        yPercent: 0,
        rotateX: 0,
        filter: "blur(0px)",
        duration: 0.78,
        stagger: { each: 0.008, from: "random" },
        ease: "power3.out"
      }, 0.5)
      .to(".blob-shell", { x: "7vw", y: "-2vh", rotate: 116, scale: 1.22, duration: 1.15 }, 0.92)
      .to(".blob--main", {
        clipPath: "polygon(40% 0%, 82% 12%, 100% 49%, 74% 84%, 46% 100%, 9% 80%, 0% 38%, 13% 12%)",
        borderRadius: "60% 40% 51% 49% / 40% 68% 32% 60%",
        duration: 1.15
      }, 0.92)
      .to(".scene--theme .char", {
        autoAlpha: 0,
        yPercent: -95,
        rotateX: 55,
        filter: "blur(14px)",
        duration: 0.48,
        stagger: { each: 0.004, from: "start" },
        ease: "power2.in"
      }, 1.18)
      .to(".scene--theme", { autoAlpha: 0, duration: 0.01 }, 1.66)
      .to(".scene--featuring", { autoAlpha: 1, duration: 0.01 }, 1.36)
      .to(".scene--featuring .char", {
        autoAlpha: 1,
        yPercent: 0,
        rotateX: 0,
        filter: "blur(0px)",
        duration: 0.52,
        stagger: { each: 0.018, from: "center" },
        ease: "power3.out"
      }, 1.4)
      .to(".line-set", { yPercent: -56, duration: 1.92 }, 1.42)
      .to(".lineup-track--front", { clipPath: "ellipse(42vmin 34vmin at 52% 49%)", duration: 1.15 }, 1.45)
      .to(".letter-layer--front", { clipPath: "inset(0 0 0 35%)", duration: 1.7 }, 1.58)
      .to(".blob-shell", { x: "0vw", y: "0vh", rotate: 184, scale: 1.08, duration: 1.12 }, 2.24)
      .to(".blob--main", {
        clipPath: "polygon(35% 1%, 72% 4%, 99% 43%, 88% 77%, 58% 99%, 20% 92%, 2% 55%, 10% 18%)",
        borderRadius: "53% 47% 61% 39% / 48% 49% 51% 52%",
        duration: 1.12
      }, 2.24)
      .to(".scene--featuring .char", {
        autoAlpha: 0,
        yPercent: -60,
        filter: "blur(12px)",
        duration: 0.38,
        stagger: { each: 0.01, from: "end" },
        ease: "power2.in"
      }, 2.72)
      .to(".scene--featuring", { autoAlpha: 0, duration: 0.01 }, 3.16)
      .to(".lineup-track--front", { clipPath: "ellipse(95vw 90vh at 50% 50%)", duration: 0.9 }, 3.05)
      .to(".blob-shell", { width: "82vw", height: "64vh", x: "0vw", y: "0vh", rotate: 0, scale: 1, duration: 0.95 }, 3.06)
      .to(".blob--main", {
        clipPath: "polygon(0% 0%, 100% 0%, 100% 0%, 100% 100%, 100% 100%, 0% 100%, 0% 100%, 0% 0%)",
        borderRadius: "4rem",
        duration: 0.95
      }, 3.06)
      .to(".letter-layer--front", { clipPath: "inset(0 0 0 0%)", duration: 0.95 }, 3.04)
      .to(".letter-layer", { scale: 0.9, opacity: 0.16, duration: 0.85 }, 3.18)
      .to(".scene--outro", { autoAlpha: 1, duration: 0.01 }, 3.26)
      .to(".scene--outro .char", {
        autoAlpha: 1,
        yPercent: 0,
        rotateX: 0,
        filter: "blur(0px)",
        duration: 0.64,
        stagger: { each: 0.006, from: "random" },
        ease: "power3.out"
      }, 3.3)
      .to(".scene--outro .ghost-cta", { autoAlpha: 1, y: 0, duration: 0.36, ease: "power3.out" }, 3.72)
      .to(".hero-pin", { backgroundColor: "#f7f4ed", duration: 0.9 }, 3.26);

    rowPairs.forEach((pair, index) => {
      heroTl.to(pair, {
        autoAlpha: 1,
        y: 0,
        filter: "blur(0px)",
        duration: 0.36,
        ease: "power3.out"
      }, 1.48 + index * 0.032);

      heroTl.to(pair, {
        autoAlpha: 0.16,
        y: -42,
        filter: "blur(11px)",
        duration: 0.34,
        ease: "power2.in"
      }, 2.38 + index * 0.018);
    });
  }

  function initContentScroll() {
    qsa(".section-title").forEach((title) => {
      const words = qsa(".word", title);
      if (!words.length) return;

      gsap.from(words, {
        autoAlpha: 0,
        yPercent: 100,
        rotateX: -55,
        filter: "blur(14px)",
        duration: 0.85,
        stagger: 0.025,
        ease: "power3.out",
        scrollTrigger: {
          trigger: title,
          start: "top 78%"
        }
      });
    });

    qsa(".reveal-copy").forEach((copy) => {
      const words = qsa(".word", copy);
      if (!words.length) return;

      gsap.from(words, {
        autoAlpha: 0,
        yPercent: 80,
        filter: "blur(8px)",
        duration: 0.65,
        stagger: 0.01,
        ease: "power3.out",
        scrollTrigger: {
          trigger: copy,
          start: "top 84%"
        }
      });
    });

    gsap.utils.toArray(".archive-card").forEach((card, index) => {
      gsap.from(card, {
        autoAlpha: 0,
        y: 80,
        rotate: index % 2 ? 2.4 : -2.4,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: {
          trigger: card,
          start: "top 86%"
        }
      });
    });

    gsap.utils.toArray(".press-row").forEach((row) => {
      gsap.from(row, {
        autoAlpha: 0,
        y: 42,
        filter: "blur(12px)",
        duration: 0.7,
        ease: "power3.out",
        scrollTrigger: {
          trigger: row,
          start: "top 86%"
        }
      });
    });

    gsap.utils.toArray(".video-card").forEach((card, index) => {
      gsap.from(card, {
        autoAlpha: 0,
        y: 70,
        scale: 0.96,
        duration: 0.8,
        delay: index * 0.05,
        ease: "power3.out",
        scrollTrigger: {
          trigger: card,
          start: "top 84%"
        }
      });
    });

    gsap.from(".mail-form", {
      autoAlpha: 0,
      y: 64,
      duration: 0.85,
      ease: "power3.out",
      scrollTrigger: {
        trigger: ".mail-form",
        start: "top 84%"
      }
    });
  }

  initMenu();
  initCursor();
  initLoadAnimation();
  initHeroScroll();
  initContentScroll();

  window.addEventListener("load", () => ScrollTrigger.refresh());
})();
