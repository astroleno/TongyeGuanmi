export const contentSections = [
  {
    id: 'belief',
    match: 'canvas-section--belief',
    navLabel: '',
    includeInNav: false,
    theme: 'dark',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'method',
    match: 'id="method"',
    navLabel: '方法',
    includeInNav: true,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'brand',
    match: 'canvas-section--brand',
    navLabel: '',
    includeInNav: false,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'services',
    match: 'id="services"',
    navLabel: '场景',
    includeInNav: true,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'lab',
    match: 'id="lab"',
    navLabel: '',
    includeInNav: false,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'education',
    match: 'id="education"',
    navLabel: '留学',
    includeInNav: true,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'philosophy',
    match: 'id="philosophy"',
    navLabel: '',
    includeInNav: false,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  },
  {
    id: 'contact',
    match: 'id="contact"',
    navLabel: '联系',
    includeInNav: true,
    theme: 'light',
    navBg: 'solid',
    layout: 'editorial-flat'
  }
];

export const chapterTransitions = [
  {
    id: 'home-belief',
    from: 'home',
    to: 'belief',
    module: 'pattern-bloom',
    variant: 'lotus-manifesto',
    drive: 'scroll'
  },
  {
    id: 'belief-method',
    from: 'belief',
    to: 'method-field-law',
    module: 'aod',
    variant: 'measure-order',
    handoffTarget: '#method',
    handoffPhase: 'after-playback'
  },
  {
    id: 'method-brand',
    from: 'method-proof',
    to: 'brand',
    module: 'soft-divider',
    variant: 'method-to-brand'
  },
  {
    id: 'brand-services',
    from: 'brand',
    to: 'services',
    module: 'figure3-transition',
    variant: 'fabric-menu',
    handoffTarget: '#services',
    handoffPhase: 'after-playback'
  },
  {
    id: 'services-lab',
    from: 'services',
    to: 'lab',
    module: 'ttg',
    variant: 'structure-field'
  },
  {
    id: 'lab-education',
    from: 'lab',
    to: 'education',
    module: 'ph',
    variant: 'learning-sun'
  },
  {
    id: 'education-philosophy',
    from: 'education',
    to: 'philosophy',
    module: 'soft-breath',
    variant: 'quiet-values'
  },
  {
    id: 'philosophy-contact',
    from: 'philosophy',
    to: 'contact',
    module: 'crane',
    variant: 'forward-motion',
    handoffTarget: '#contact',
    handoffPhase: 'after-playback'
  }
];

export const sectionEntryPolicies = {
  belief: {
    directVisit: 'replay',
    afterHandoff: 'continue'
  },
  method: {
    directVisit: 'replay',
    afterHandoff: 'skip'
  },
  brand: {
    directVisit: 'replay',
    afterHandoff: 'skip'
  },
  services: {
    directVisit: 'replay',
    afterHandoff: 'skip'
  },
  lab: {
    directVisit: 'replay',
    afterHandoff: 'replay'
  },
  education: {
    directVisit: 'replay',
    afterHandoff: 'replay'
  },
  philosophy: {
    directVisit: 'replay',
    afterHandoff: 'replay'
  },
  contact: {
    directVisit: 'replay',
    afterHandoff: 'skip'
  }
};

export const handoffs = [
  {
    id: 'home-belief',
    transitionId: 'home-belief',
    from: 'home',
    to: 'belief',
    owner: 'target-section',
    transition: {
      mode: 'scroll-bridge',
      ghostScenes: ['pattern-bloom-lotus'],
      targetSelector: '.belief-lower-copy-wrap'
    },
    targetEntry: {
      policy: 'continue',
      suppressOnceAfterHandoff: true,
      directVisitPolicy: 'replay'
    },
    afterComplete: {
      markTargetPresented: true,
      scrollTo: '#belief',
      snapToVisualStart: true,
      cleanupGhosts: true
    },
    reducedMotion: {
      policy: 'jump-to-presented'
    }
  },
  {
    id: 'belief-method',
    transitionId: 'belief-method',
    from: 'belief',
    to: 'method',
    owner: 'target-section',
    transition: {
      mode: 'after-playback',
      ghostScenes: ['aod-field'],
      targetSelector: '.method-edition-layout--after-handoff'
    },
    targetEntry: {
      policy: 'skip',
      suppressOnceAfterHandoff: true,
      directVisitPolicy: 'replay'
    },
    afterComplete: {
      markTargetPresented: true,
      scrollTo: '#method',
      snapToVisualStart: true,
      cleanupGhosts: true
    },
    reducedMotion: {
      policy: 'jump-to-presented'
    }
  },
  {
    id: 'method-proof-brand',
    transitionId: 'method-tooling__method-proof',
    from: 'method-proof',
    to: 'brand',
    owner: 'target-section',
    transition: {
      mode: 'post-scroll',
      ghostScenes: ['method-proof-bridge'],
      targetSelector: '.brand-definition-grid'
    },
    targetEntry: {
      policy: 'skip',
      suppressOnceAfterHandoff: true,
      directVisitPolicy: 'replay'
    },
    afterComplete: {
      markTargetPresented: true,
      scrollTo: '#brand',
      snapToVisualStart: true,
      cleanupGhosts: true
    },
    reducedMotion: {
      policy: 'jump-to-presented'
    }
  },
  {
    id: 'brand-services',
    transitionId: 'brand-services',
    from: 'brand',
    to: 'services',
    owner: 'target-section',
    transition: {
      mode: 'after-playback',
      ghostScenes: ['figure3-fabric'],
      targetSelector: '.enterprise-vertical-layout'
    },
    targetEntry: {
      policy: 'skip',
      suppressOnceAfterHandoff: true,
      directVisitPolicy: 'replay'
    },
    afterComplete: {
      markTargetPresented: true,
      scrollTo: '#services',
      snapToVisualStart: true,
      cleanupGhosts: true
    },
    reducedMotion: {
      policy: 'jump-to-presented'
    }
  },
  {
    id: 'philosophy-contact',
    transitionId: 'philosophy-contact',
    from: 'philosophy',
    to: 'contact',
    owner: 'target-section',
    transition: {
      mode: 'after-playback',
      ghostScenes: ['crane-motion'],
      targetSelector: '.contact-endpoint'
    },
    targetEntry: {
      policy: 'skip',
      suppressOnceAfterHandoff: true,
      directVisitPolicy: 'replay'
    },
    afterComplete: {
      markTargetPresented: true,
      scrollTo: '#contact',
      snapToVisualStart: true,
      cleanupGhosts: true
    },
    reducedMotion: {
      policy: 'jump-to-presented'
    }
  }
];

export const timelineScenes = [];

export const timelineJoins = [];

export const homepageMasterTimeline = {
  scrollUnit: 'vh',
  track: {
    selector: '[data-homepage-master-track]',
    stickySelector: '[data-homepage-master-stage]',
    heightMode: 'generated',
    heightCssVariable: '--homepage-master-track-vh'
  },
  scrollBlocks: [
    { id: 'home-hold', type: 'hold', scene: 'home', scrollVh: 230 },
    { id: 'home-to-belief-upper', type: 'transition', segment: 'home-to-belief-upper' },
    { id: 'belief-upper-hold', type: 'hold', scene: 'belief.upper', scrollVh: 70 },
    { id: 'belief-upper-to-belief-lower', type: 'transition', segment: 'belief-upper-to-belief-lower' },
    { id: 'belief-lower-hold', type: 'hold', scene: 'belief.lower', scrollVh: 80 },
    { id: 'belief-lower-to-method', type: 'transition', segment: 'belief-lower-to-method' },
    { id: 'method-hold', type: 'hold', scene: 'method', scrollVh: 120 },
    { id: 'method-proof-hold', type: 'hold', scene: 'method.proof', scrollVh: 90 },
    { id: 'method-proof-to-brand', type: 'transition', segment: 'method-proof-to-brand' },
    { id: 'brand-hold', type: 'hold', scene: 'brand', scrollVh: 90 },
    { id: 'brand-to-services', type: 'transition', segment: 'brand-to-services' },
    { id: 'services-hold', type: 'hold', scene: 'services', scrollVh: 100 },
    { id: 'services-to-lab', type: 'transition', segment: 'services-to-lab' },
    { id: 'lab-hold', type: 'hold', scene: 'lab', scrollVh: 90 },
    { id: 'lab-to-education', type: 'transition', segment: 'lab-to-education' },
    { id: 'education-hold', type: 'hold', scene: 'education', scrollVh: 90 },
    { id: 'education-to-philosophy', type: 'transition', segment: 'education-to-philosophy' },
    { id: 'philosophy-hold', type: 'hold', scene: 'philosophy', scrollVh: 90 },
    { id: 'philosophy-to-contact', type: 'transition', segment: 'philosophy-to-contact' },
    { id: 'contact-hold', type: 'hold', scene: 'contact', scrollVh: 120 }
  ],
  surfaces: [
    { id: 'home.visual', selector: '[data-master-surface="home.visual"]', kind: 'canvas-or-image', allowGeneratedCanvas: true, producer: 'hero' },
    { id: 'belief.star', selector: '[data-master-surface="belief.star"]', kind: 'canvas', shared: true, allowGeneratedCanvas: false, producer: 'belief-star' },
    { id: 'aod.bridge', selector: '[data-master-surface="aod.bridge"]', kind: 'canvas', allowGeneratedCanvas: true, producer: 'aod', ownerScene: 'belief.lower', canonicalRole: 'transition-source', sameRectAs: 'belief.star' },
    { id: 'method.paper', selector: '[data-master-surface="method.paper"]', kind: 'canvas', allowGeneratedCanvas: true, producer: 'method-paper' },
    { id: 'figure2.bridge', selector: '[data-master-surface="figure2.bridge"]', kind: 'canvas-or-video', allowGeneratedCanvas: true, producer: 'figure2', ownerScene: 'method.proof', canonicalRole: 'scene-visual' },
    { id: 'brand.paper', selector: '[data-master-surface="brand.paper"]', kind: 'canvas', allowGeneratedCanvas: true, producer: 'brand-paper' },
    { id: 'figure3.bridge', selector: '[data-master-surface="figure3.bridge"]', kind: 'canvas-or-video', allowGeneratedCanvas: true, producer: 'figure3', ownerScene: 'brand', canonicalRole: 'transition-source', sameRectAs: 'brand.paper' },
    { id: 'services.paper', selector: '[data-master-surface="services.paper"]', kind: 'canvas', allowGeneratedCanvas: true, producer: 'services-paper' },
    { id: 'lab.visual', selector: '[data-master-surface="lab.visual"]', kind: 'canvas-or-image', allowGeneratedCanvas: true, producer: 'ttg' },
    { id: 'education.visual', selector: '[data-master-surface="education.visual"]', kind: 'canvas-or-image', allowGeneratedCanvas: true, producer: 'ph' },
    { id: 'philosophy.visual', selector: '[data-master-surface="philosophy.visual"]', kind: 'canvas-or-image', allowGeneratedCanvas: true, producer: 'philosophy' },
    { id: 'crane.bridge', selector: '[data-master-surface="crane.bridge"]', kind: 'canvas-or-video', allowGeneratedCanvas: true, producer: 'crane', ownerScene: 'philosophy', canonicalRole: 'transition-source', sameRectAs: 'philosophy.visual' },
    { id: 'contact.paper', selector: '[data-master-surface="contact.paper"]', kind: 'canvas', allowGeneratedCanvas: true, producer: 'contact-paper' }
  ],
  scenes: [
    {
      id: 'home',
      rootSelector: '[data-master-scene-root="home"]',
      sectionSelector: '#home',
      visualSelector: '[data-master-scene-visual="home"]',
      copySelector: '[data-master-copy-id="home"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="home"]',
      surfaceKey: 'home.visual',
      role: 'native'
    },
    {
      id: 'belief.upper',
      rootSelector: '[data-master-scene-root="belief.upper"]',
      sectionSelector: '#belief',
      visualSelector: '[data-master-scene-visual="belief.upper"]',
      copySelector: '[data-master-copy-id="belief.upper"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="belief.upper"]',
      surfaceKey: 'belief.star',
      role: 'native',
      viewportAnchor: { topVh: 24, maxWidthPx: 560, align: 'right', rightVw: 8 },
      copyStaggerSelector: '[data-belief-upper-stagger]'
    },
    {
      id: 'belief.lower',
      rootSelector: '[data-master-scene-root="belief.lower"]',
      sectionSelector: '#belief',
      visualSelector: '[data-master-scene-visual="belief.lower"]',
      copySelector: '[data-master-copy-id="belief.lower"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="belief.lower"]',
      surfaceKey: 'belief.star',
      role: 'native'
    },
    {
      id: 'method',
      rootSelector: '[data-master-scene-root="method"]',
      sectionSelector: '#method',
      visualSelector: '[data-master-scene-visual="method"]',
      copySelector: '[data-master-copy-id="method.intro"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="method"]',
      surfaceKey: 'method.paper',
      viewportAnchor: { topVh: 18, maxWidthPx: 980, align: 'center' },
      role: 'native'
    },
    {
      id: 'method.proof',
      rootSelector: '[data-master-scene-root="method.proof"]',
      sectionSelector: '[data-scene-id="method-proof"]',
      visualSelector: '[data-master-scene-visual="method.proof"]',
      copySelector: '[data-master-copy-id="method.proof"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="method.proof"]',
      surfaceKey: 'figure2.bridge',
      role: 'source-only'
    },
    {
      id: 'brand',
      rootSelector: '[data-master-scene-root="brand"]',
      sectionSelector: '#brand',
      visualSelector: '[data-master-scene-visual="brand"]',
      copySelector: '[data-master-copy-id="brand"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="brand"]',
      surfaceKey: 'brand.paper',
      role: 'native'
    },
    {
      id: 'services',
      rootSelector: '[data-master-scene-root="services"]',
      sectionSelector: '#services',
      visualSelector: '[data-master-scene-visual="services"]',
      copySelector: '[data-master-copy-id="services"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="services"]',
      surfaceKey: 'services.paper',
      role: 'native'
    },
    {
      id: 'lab',
      rootSelector: '[data-master-scene-root="lab"]',
      sectionSelector: '#lab',
      visualSelector: '[data-master-scene-visual="lab"]',
      copySelector: '[data-master-copy-id="lab"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="lab"]',
      surfaceKey: 'lab.visual',
      role: 'native'
    },
    {
      id: 'education',
      rootSelector: '[data-master-scene-root="education"]',
      sectionSelector: '#education',
      visualSelector: '[data-master-scene-visual="education"]',
      copySelector: '[data-master-copy-id="education"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="education"]',
      surfaceKey: 'education.visual',
      role: 'native'
    },
    {
      id: 'philosophy',
      rootSelector: '[data-master-scene-root="philosophy"]',
      sectionSelector: '#philosophy',
      visualSelector: '[data-master-scene-visual="philosophy"]',
      copySelector: '[data-master-copy-id="philosophy"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="philosophy"]',
      surfaceKey: 'philosophy.visual',
      role: 'native'
    },
    {
      id: 'contact',
      rootSelector: '[data-master-scene-root="contact"]',
      sectionSelector: '#contact',
      visualSelector: '[data-master-scene-visual="contact"]',
      copySelector: '[data-master-copy-id="contact"][data-master-copy-root="true"]',
      layoutAnchorSelector: '[data-master-scene-layout="contact"]',
      surfaceKey: 'contact.paper',
      role: 'native'
    }
  ],
  segments: [
    {
      id: 'home-to-belief-upper',
      hostSelector: '[data-transition-id="home-belief"]',
      from: 'home',
      to: 'belief.upper',
      scrollVh: 90,
      transition: {
        type: 'ink',
        adapter: 'pattern-bloom',
        ink: {
          variant: 'radial-center-out',
          sourceSurfaceKey: 'home.visual',
          targetSurfaceKey: 'belief.star',
          window: [0.18, 0.76]
        }
      },
      visualHandoffAt: 0.54,
      scenePresence: {
        from: { opacity: [[0, 1], [0.66, 0.15], [1, 0]], y: [[0, 0], [1, -30]] },
        to: { opacity: [[0, 0], [0.26, 0.25], [0.72, 1], [1, 1]], y: [[0, 26], [1, 0]] }
      },
      copy: {
        source: { exit: [0.38, 0.66], readableUntil: 0.54, foregroundUntil: 0.54 },
        target: {
          policy: 'overlap',
          enter: [0.44, 0.68],
          readableAt: 0.58,
          foregroundAt: 0.54,
          stagger: 'beliefUpperHeroLike',
          staggerItems: [
            { selector: '[data-belief-upper-stagger="index"]', enter: [0.44, 0.52] },
            { selector: '[data-belief-upper-stagger="headline"]', enter: [0.50, 0.62] },
            { selector: '[data-belief-upper-stagger="body"]', enter: [0.58, 0.68] }
          ]
        }
      }
    },
    {
      id: 'belief-upper-to-belief-lower',
      hostSelector: '[data-transition-id="home-belief"]',
      from: 'belief.upper',
      to: 'belief.lower',
      scrollVh: 70,
      transition: {
        type: 'ink',
        adapter: 'pattern-bloom',
        ink: {
          variant: 'vertical-curtain',
          mode: 'overlay-wash',
          direction: 'bottom-up',
          sourceSurfaceKey: 'belief.star',
          targetSurfaceKey: 'belief.star',
          window: [0.14, 0.82]
        }
      },
      visualHandoffAt: 0.62,
      scenePresence: {
        from: { opacity: [[0, 1], [0.62, 0.42], [1, 0]], y: [[0, 0], [1, -18]] },
        to: { opacity: [[0, 0], [0.28, 0.32], [0.78, 1], [1, 1]], y: [[0, 22], [1, 0]] }
      },
      copy: {
        source: { exit: [0.42, 0.68], readableUntil: 0.56, foregroundUntil: 0.62 },
        target: { policy: 'overlap', enter: [0.70, 0.86], readableAt: 0.80, foregroundAt: 0.76 }
      }
    },
    {
      id: 'belief-lower-to-method',
      hostSelector: '[data-transition-id="belief-method"]',
      from: 'belief.lower',
      to: 'method',
      scrollVh: 100,
      transition: {
        type: 'ink',
        adapter: 'aod',
        ink: {
          variant: 'vertical-curtain',
          direction: 'bottom-up',
          sourceSurfaceKey: 'aod.bridge',
          targetSurfaceKey: 'method.paper',
          window: [0.10, 0.74]
        }
      },
      visualHandoffAt: 0.48,
      scenePresence: {
        from: { opacity: [[0, 1], [0.58, 0.35], [1, 0]], y: [[0, 0], [1, -20]] },
        to: { opacity: [[0, 0], [0.18, 0.35], [0.70, 1], [1, 1]], y: [[0, 34], [1, 0]] }
      },
      copy: {
        source: { exit: [0.30, 0.56], readableUntil: 0.46, foregroundUntil: 0.48 },
        target: { policy: 'overlap', enter: [0.42, 0.58], readableAt: 0.52, foregroundAt: 0.48 }
      }
    },
    {
      id: 'method-proof-to-brand',
      hostSelector: '[data-transition-id="method-tooling__method-proof"]',
      from: 'method.proof',
      to: 'brand',
      scrollVh: 120,
      transition: {
        type: 'ink',
        adapter: 'figure2',
        ink: {
          variant: 'vertical-curtain',
          direction: 'bottom-up',
          sourceSurfaceKey: 'figure2.bridge',
          targetSurfaceKey: 'brand.paper',
          window: [0.34, 0.88]
        }
      },
      visualHandoffAt: 0.72,
      scenePresence: {
        from: { opacity: [[0, 1], [0.70, 0.45], [1, 0]], y: [[0, 0], [1, -24]] },
        to: { opacity: [[0, 0], [0.36, 0.26], [0.84, 1], [1, 1]], y: [[0, 28], [1, 0]] }
      },
      copy: {
        source: { exit: [0.54, 0.80], readableUntil: 0.68, foregroundUntil: 0.72 },
        target: { policy: 'overlap', enter: [0.76, 0.92], readableAt: 0.86, foregroundAt: 0.82 }
      }
    },
    {
      id: 'brand-to-services',
      hostSelector: '[data-transition-id="brand-services"]',
      from: 'brand',
      to: 'services',
      scrollVh: 95,
      transition: {
        type: 'ink',
        adapter: 'figure3-transition',
        ink: {
          variant: 'vertical-curtain',
          direction: 'bottom-up',
          sourceSurfaceKey: 'figure3.bridge',
          targetSurfaceKey: 'services.paper',
          window: [0.20, 0.82]
        }
      },
      visualHandoffAt: 0.64,
      scenePresence: {
        from: { opacity: [[0, 1], [0.64, 0.35], [1, 0]], y: [[0, 0], [1, -20]] },
        to: { opacity: [[0, 0], [0.30, 0.30], [0.80, 1], [1, 1]], y: [[0, 26], [1, 0]] }
      },
      copy: {
        source: { exit: [0.46, 0.74], readableUntil: 0.62, foregroundUntil: 0.64 },
        target: { policy: 'overlap', enter: [0.74, 0.90], readableAt: 0.84, foregroundAt: 0.80 }
      }
    },
    {
      id: 'services-to-lab',
      hostSelector: '[data-transition-id="services-lab"]',
      from: 'services',
      to: 'lab',
      scrollVh: 80,
      transition: { type: 'adapter', adapter: 'ttg' },
      visualHandoffAt: 0.72,
      scenePresence: {
        from: { opacity: [[0, 1], [0.72, 0.2], [1, 0]], y: [[0, 0], [1, -18]] },
        to: { opacity: [[0, 0], [0.42, 0.28], [0.82, 1], [1, 1]], y: [[0, 22], [1, 0]] }
      },
      copy: {
        source: { exit: [0.58, 0.82], readableUntil: 0.70, foregroundUntil: 0.72 },
        target: { policy: 'settled-only' }
      }
    },
    {
      id: 'lab-to-education',
      hostSelector: '[data-transition-id="lab-education"]',
      from: 'lab',
      to: 'education',
      scrollVh: 80,
      transition: { type: 'adapter', adapter: 'ph' },
      visualHandoffAt: 0.72,
      scenePresence: {
        from: { opacity: [[0, 1], [0.72, 0.2], [1, 0]], y: [[0, 0], [1, -18]] },
        to: { opacity: [[0, 0], [0.42, 0.28], [0.82, 1], [1, 1]], y: [[0, 22], [1, 0]] }
      },
      copy: {
        source: { exit: [0.58, 0.82], readableUntil: 0.70, foregroundUntil: 0.72 },
        target: { policy: 'settled-only' }
      }
    },
    {
      id: 'education-to-philosophy',
      hostSelector: '[data-transition-id="education-philosophy"]',
      from: 'education',
      to: 'philosophy',
      scrollVh: 70,
      transition: { type: 'soft', adapter: 'soft-breath' },
      visualHandoffAt: 0.74,
      scenePresence: {
        from: { opacity: [[0, 1], [0.72, 0.22], [1, 0]], y: [[0, 0], [1, -16]] },
        to: { opacity: [[0, 0], [0.52, 0.30], [0.84, 1], [1, 1]], y: [[0, 20], [1, 0]] }
      },
      copy: {
        source: { exit: [0.62, 0.84], readableUntil: 0.72, foregroundUntil: 0.74 },
        target: { policy: 'settled-only' }
      }
    },
    {
      id: 'philosophy-to-contact',
      hostSelector: '[data-transition-id="philosophy-contact"]',
      from: 'philosophy',
      to: 'contact',
      scrollVh: 90,
      transition: {
        type: 'ink',
        adapter: 'crane',
        ink: {
          variant: 'vertical-curtain',
          direction: 'bottom-up',
          sourceSurfaceKey: 'crane.bridge',
          targetSurfaceKey: 'contact.paper',
          window: [0.16, 0.80]
        }
      },
      visualHandoffAt: 0.56,
      scenePresence: {
        from: { opacity: [[0, 1], [0.66, 0.32], [1, 0]], y: [[0, 0], [1, -18]] },
        to: { opacity: [[0, 0], [0.24, 0.34], [0.82, 1], [1, 1]], y: [[0, 24], [1, 0]] }
      },
      copy: {
        source: { exit: [0.36, 0.62], readableUntil: 0.52, foregroundUntil: 0.56 },
        target: { policy: 'overlap', enter: [0.50, 0.66], readableAt: 0.60, foregroundAt: 0.56 }
      }
    }
  ]
};

export const executableTransitionModules = [
  'soft-divider',
  'soft-drilldown',
  'soft-breath',
  'aod',
  'figure2',
  'pattern-bloom',
  'ttg',
  'figure3-transition',
  'ph',
  'crane'
];
