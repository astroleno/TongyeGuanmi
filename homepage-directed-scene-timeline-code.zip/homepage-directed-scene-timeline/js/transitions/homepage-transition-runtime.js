import {
  homepageTransitionRegistry,
  homepageSurfaceProducerRegistry
} from './homepage-transition-registry.js';
import { createSectionPresentationController } from './homepage/section-presentation-controller.js';
import { homepageMasterTimeline } from './homepage/master-timeline-manifest.js';
import {
  createMasterTimelineModel,
  resolveMasterTimelineState
} from './homepage/master-scroll-timeline.js';
import { createMasterScrollMap } from './homepage/master-scroll-map.js';
import { createMasterSceneRegistry } from './homepage/master-scene-registry.js';
import { createMasterScenePresenter } from './homepage/master-scene-presenter.js';
import { createMasterSurfaceProducerRegistry } from './homepage/master-surface-producer-registry.js';
import { createMasterInkCompositor } from './homepage/master-ink-compositor.js';

const NAMED_TRANSITION_SELECTOR = [
  '.chapter-transition[data-transition-module]',
  '.scene-transition[data-transition-module]'
].join(',');

const SOFT_MODULES = new Set(['soft-divider', 'soft-drilldown', 'soft-breath']);
const SCROLL_DRIVEN_MODULES = new Set([]);
const HANDOFF_AFTER_PLAYBACK = 'after-playback';
const HANDOFF_POST_SCROLL = 'post-scroll';
const REDUCED_MOTION_CLASS = 'homepage-transition--reduced-motion';

const DEFAULT_PLAY_MS = 1900;
const SNAP_VIEWPORT_HEIGHT_VAR = '--homepage-transition-snap-height';
const SNAP_EXTRA_HEIGHT_VAR = '--homepage-transition-extra-snap-height';
const FIXED_STAGE_CLASS = 'homepage-transition--fixed-stage';
const DEFAULT_SNAP_ENTRY_VH = 1.02;
const DEFAULT_TARGET_GATE_RELEASE_PROGRESS = 0.86;
const POST_SNAP_INPUT_LOCK_MS = 420;
const POST_SCROLL_HANDOFF_PROGRESS = 0.84;
const HANDOFF_LANDING_SUPPRESS_FORWARD_VH = 1.10;
const HANDOFF_LANDING_NEARBY_FORWARD_VH = 1.45;
const DIRECT_HASH_ALIGNMENT_DELAYS = [0, 120, 420, 1100, 2400, 5200, 9200];
const BLOCKED_SCROLL_KEYS = new Set(['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp', 'Home', 'End', ' ']);
const MODULE_PLAY_MS = {
  aod: 1800,
  figure2: 2200,
  'pattern-bloom': 2200,
  ttg: 2500,
  'figure3-transition': 1800,
  ph: 1900,
  crane: 2200
};

const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const easeInOutCubic = (value) => {
  const p = clamp(value);
  return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
};
const parseFiniteNumber = (value, fallback) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};
const parseNumberList = (value, { min = -Infinity, max = Infinity } = {}) => String(value || '')
  .split(',')
  .map((item) => Number(item.trim()))
  .filter((number) => Number.isFinite(number) && number > min && number < max);

function resolveHandoffTarget(root, host) {
  const selector = host?.dataset?.transitionHandoffTarget;
  const queryRoot = typeof root?.querySelector === 'function' ? root : document;
  if (selector) {
    try {
      const target = queryRoot.querySelector(selector);
      if (target) return target;
    } catch (error) {
      console.warn(`Invalid transition handoff selector: ${selector}`, error);
    }
  }

  const transitionTo = host?.dataset?.transitionTo;
  if (!transitionTo) return null;
  return queryRoot.getElementById?.(transitionTo) || null;
}

function getDirectHashTargetId() {
  const hash = window.location.hash || '';
  if (!hash.startsWith('#')) return '';
  try {
    return decodeURIComponent(hash.slice(1));
  } catch {
    return hash.slice(1);
  }
}

function isDirectHashTargetForController(controller) {
  const directHashTargetId = getDirectHashTargetId();
  return Boolean(
    directHashTargetId
    && controller?.handoffTarget
    && (
      controller.handoffTarget.id === directHashTargetId
      || controller.handoffTarget.dataset?.sectionId === directHashTargetId
    )
  );
}

function shouldGateTargetReveal(controller) {
  return Boolean(
    controller?.handoffTarget
    && !controller.timelineJoins?.length
    && !controller.handoffId
    && !controller.handoffPhase
  );
}

function createCleanupStack() {
  const cleanups = [];

  return {
    add(cleanup) {
      if (!cleanup) return;
      const destroy = typeof cleanup === 'function' ? cleanup : cleanup.destroy;
      if (typeof destroy === 'function') cleanups.push(() => destroy.call(cleanup));
    },
    destroy() {
      while (cleanups.length) {
        const dispose = cleanups.pop();
        try {
          dispose();
        } catch (error) {
          console.warn('Homepage transition cleanup failed.', error);
        }
      }
    }
  };
}

function getScrollY() {
  return window.scrollY || window.pageYOffset || 0;
}

function getDocumentTop(element) {
  return getScrollY() + element.getBoundingClientRect().top;
}

function queryOptionalSelector(queryRoot, selector) {
  if (!selector || typeof queryRoot?.querySelector !== 'function') return null;
  try {
    return queryRoot.querySelector(selector);
  } catch (error) {
    console.warn(`Invalid transition visual target selector: ${selector}`, error);
    return null;
  }
}

function createElementScrollProgressSource(element) {
  return () => {
    if (!element) return 0;
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const rect = element.getBoundingClientRect();
    const scrollSpan = Math.max(1, element.offsetHeight || rect.height || viewportHeight);
    return clamp((viewportHeight - rect.top) / scrollSpan);
  };
}

function createHeroLinkedScrollProgressSource(element) {
  return () => {
    const hero = document.querySelector('.hero-wrap');
    if (!hero || !element) return createElementScrollProgressSource(element)();

    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const heroTop = getDocumentTop(hero);
    const hostTop = getDocumentTop(element);
    const heroRange = Math.max(1, hero.offsetHeight - viewportHeight);
    const heroRevealStart = heroTop + heroRange * 0.26;
    const heroRevealEnd = heroTop + heroRange * 0.92;
    const transitionEnd = hostTop + Math.max(viewportHeight, element.offsetHeight || viewportHeight);
    const scrollY = getScrollY();

    if (scrollY <= heroRevealEnd) {
      return clamp((scrollY - heroRevealStart) / Math.max(1, heroRevealEnd - heroRevealStart) * 0.50);
    }

    return clamp(0.50 + ((scrollY - heroRevealEnd) / Math.max(1, transitionEnd - heroRevealEnd)) * 0.50);
  };
}

function getScrollRuntimeLenis(scrollRuntime) {
  return scrollRuntime?.lenis || null;
}

function createNativeScrollTween() {
  let raf = 0;

  const cancel = () => {
    if (!raf) return;
    cancelAnimationFrame(raf);
    raf = 0;
  };

  return {
    scrollTo(targetY, { immediate = false, duration = 0.62, onComplete } = {}) {
      cancel();
      const target = Math.max(0, targetY);

      if (immediate || duration <= 0) {
        window.scrollTo({ top: target, left: window.scrollX, behavior: 'auto' });
        onComplete?.();
        return;
      }

      const startY = getScrollY();
      const distance = target - startY;
      const startTime = performance.now();
      const durationMs = duration * 1000;

      const tick = (now) => {
        const progress = clamp((now - startTime) / durationMs);
        const eased = easeInOutCubic(progress);
        window.scrollTo({ top: startY + distance * eased, left: window.scrollX, behavior: 'auto' });

        if (progress < 1) {
          raf = requestAnimationFrame(tick);
          return;
        }

        raf = 0;
        onComplete?.();
      };

      raf = requestAnimationFrame(tick);
    },
    destroy: cancel
  };
}

function resolveAnchorTarget(root, targetId) {
  if (!targetId) return null;
  const queryRoot = typeof root?.querySelector === 'function' ? root : document;
  const escapedTargetId = typeof CSS !== 'undefined' && typeof CSS.escape === 'function'
    ? CSS.escape(targetId)
    : String(targetId).replace(/"/g, '\\"');
  try {
    return queryRoot.getElementById?.(targetId)
      || queryRoot.querySelector?.(`[data-section-id="${escapedTargetId}"]`)
      || null;
  } catch {
    return queryRoot.getElementById?.(targetId) || null;
  }
}

function createHomepageSnapCoordinator({
  reduceMotion = false,
  scrollRuntime = null,
  root = document,
  presentationController = createSectionPresentationController({ root }),
  sceneTimeline = null
} = {}) {
  const lenis = getScrollRuntimeLenis(scrollRuntime);
  const nativeTween = createNativeScrollTween();
  const originalLenisScrollTo = lenis?.scrollTo || null;
  const controllers = [];
  let activeController = null;
  let lastScrollY = getScrollY();
  let scrollLockDepth = 0;
  let inputLockUntil = 0;
  let releaseTimer = 0;
  let isProgrammaticScroll = false;
  let programmaticScrollToken = 0;
  const rootElement = root.documentElement || document.documentElement;
  const previousSnapViewportHeight = rootElement?.style?.getPropertyValue(SNAP_VIEWPORT_HEIGHT_VAR) || '';

  const isInputCooldownActive = () => performance.now() < inputLockUntil;
  const shouldBlockScrollInput = () => activeController || isInputCooldownActive();
  const shouldSuppressControllerUpdates = () => (
    activeController || isProgrammaticScroll || isInputCooldownActive()
  );

  const syncLastScrollY = () => {
    lastScrollY = getScrollY();
  };

  const syncControllerSnapHold = (controller, viewportHeight = Math.max(1, window.innerHeight || rootElement?.clientHeight || 1)) => {
    const extraHeight = Math.max(0, viewportHeight * (((controller?.stageHoldVh || 0) + (controller?.postScrollVh || 0)) / 100));
    controller?.host?.style?.setProperty(SNAP_EXTRA_HEIGHT_VAR, `${Math.round(extraHeight)}px`);
  };

  const syncSnapViewportHeight = () => {
    const viewportHeight = Math.ceil(Math.max(1, window.innerHeight || rootElement?.clientHeight || 1));
    rootElement?.style?.setProperty(SNAP_VIEWPORT_HEIGHT_VAR, `${viewportHeight}px`);
    controllers.forEach((controller) => syncControllerSnapHold(controller, viewportHeight));
  };

  const getStageHoldPx = (controller, viewportHeight = Math.max(1, window.innerHeight || 1)) => (
    Math.max(0, viewportHeight * ((controller?.stageHoldVh || 0) / 100))
  );

  const getPostScrollPx = (controller, viewportHeight = Math.max(1, window.innerHeight || 1)) => (
    Math.max(0, viewportHeight * ((controller?.postScrollVh || 0) / 100))
  );

  const getHandoffVisualTarget = (controller) => {
    if (!controller?.handoffTarget) return null;
    const selector = controller.handoffTargetSelector || '';
    if (!selector) return controller.handoffTarget;
    return queryOptionalSelector(controller.handoffTarget, selector)
      || queryOptionalSelector(root, selector)
      || controller.handoffTarget;
  };

  const getHandoffAlignmentOffset = (controller, viewportHeight) => (
    controller?.handoffTargetSelector ? viewportHeight * 0.20 : 0
  );

  const getHandoffTargetY = (controller) => {
    const target = getHandoffVisualTarget(controller);
    if (!target) return null;
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    return Math.max(0, Math.round(getDocumentTop(target) - getHandoffAlignmentOffset(controller, viewportHeight)));
  };

  const getDirectHashTargetY = (controller) => {
    const target = getHandoffVisualTarget(controller);
    return target ? Math.max(0, Math.round(getDocumentTop(target) - window.innerHeight * 0.2)) : null;
  };

  const isDirectHashTargetVisible = (controller) => {
    const target = getHandoffVisualTarget(controller);
    if (!target) return true;
    const rect = target.getBoundingClientRect();
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    return rect.bottom > viewportHeight * 0.18 && rect.top < viewportHeight * 0.88;
  };

  const clearForwardSuppression = (controller) => {
    if (!controller) return;
    controller.forwardSuppressedUntilY = 0;
    controller.forwardSuppressionStartY = 0;
    controller.host?.removeAttribute('data-forward-suppressed-until');
  };

  const suppressNearbyForwardControllers = (sourceController, targetY) => {
    if (!Number.isFinite(targetY)) return;
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const suppressUntilY = targetY + viewportHeight * HANDOFF_LANDING_SUPPRESS_FORWARD_VH;
    const nearbyDistance = viewportHeight * HANDOFF_LANDING_NEARBY_FORWARD_VH;
    controllers.forEach((controller) => {
      if (!controller || controller === sourceController || controller.destroyed) return;
      const hostTop = getDocumentTop(controller.host);
      if (hostTop < targetY || hostTop - targetY > nearbyDistance) return;
      controller.forwardSuppressionStartY = targetY;
      controller.forwardSuppressedUntilY = Math.max(controller.forwardSuppressedUntilY || 0, suppressUntilY);
      controller.host.dataset.forwardSuppressedUntil = controller.forwardSuppressedUntilY.toFixed(1);
    });
  };

  const syncFixedStageState = (controller, scrollY = getScrollY()) => {
    if (!controller?.host || controller.destroyed) return;
    controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
    if (controller.skipForDirectHash && isDirectHashTargetForController(controller)) {
      controller.host.classList.remove(FIXED_STAGE_CLASS);
      return;
    }
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const hostTop = getDocumentTop(controller.host);
    const stageHoldPx = getStageHoldPx(controller, viewportHeight);
    const postScrollPx = getPostScrollPx(controller, viewportHeight);
    const fixedStart = hostTop;
    const postStart = hostTop + stageHoldPx;
    const postEnd = postStart + postScrollPx;
    const inStageHold = stageHoldPx > 0
      && controller.playhead > 0.001
      && controller.playhead < 0.998
      && scrollY >= fixedStart - 2
      && scrollY <= postStart + 2;
    const inPostScroll = postScrollPx > 0
      && controller.playhead >= 0.998
      && scrollY >= fixedStart - 2
      && scrollY <= postEnd + viewportHeight * 0.32
      && !controller.handoffComplete;
    controller.host.classList.toggle(FIXED_STAGE_CLASS, inStageHold || inPostScroll);
  };

  const getSnapDocumentTop = (element) => Math.round(getDocumentTop(element));

  const beginProgrammaticScroll = () => {
    programmaticScrollToken += 1;
    isProgrammaticScroll = true;
    syncLastScrollY();
    return programmaticScrollToken;
  };

  const finishProgrammaticScroll = (token) => {
    if (!token || token !== programmaticScrollToken) return false;
    isProgrammaticScroll = false;
    syncLastScrollY();
    return true;
  };

  const cancelProgrammaticScrollTracking = () => {
    if (!isProgrammaticScroll || activeController) return;
    programmaticScrollToken += 1;
    isProgrammaticScroll = false;
    syncLastScrollY();
  };

  const blockEvent = (event) => {
    if (event.cancelable) event.preventDefault();
    event.stopImmediatePropagation?.();
  };

  const clearReleaseTimer = () => {
    if (!releaseTimer) return;
    window.clearTimeout(releaseTimer);
    releaseTimer = 0;
  };

  const preventScrollInput = (event) => {
    if (shouldBlockScrollInput()) {
      blockEvent(event);
      return;
    }
    cancelProgrammaticScrollTracking();
    const inputDirection = Math.sign(Number(event.deltaY) || 0);
    if (inputDirection !== 0) {
      const scrollY = getScrollY();
      controllers.forEach((controller) => updateControllerState(controller, scrollY, inputDirection));
      if (activeController) blockEvent(event);
    }
  };

  const preventScrollKeys = (event) => {
    if (!BLOCKED_SCROLL_KEYS.has(event.key)) return;
    if (shouldBlockScrollInput()) {
      blockEvent(event);
      return;
    }
    cancelProgrammaticScrollTracking();
  };

  const lockScroll = () => {
    scrollLockDepth += 1;
    root.documentElement?.classList?.add('homepage-transition-snap-active');
    lenis?.stop?.();
  };

  const unlockScroll = () => {
    scrollLockDepth = Math.max(0, scrollLockDepth - 1);
    if (scrollLockDepth > 0) return;
    root.documentElement?.classList?.remove('homepage-transition-snap-active');
    lenis?.start?.();
  };

  if (lenis && originalLenisScrollTo) {
    lenis.scrollTo = (target, options = {}) => {
      const programmatic = options.programmatic !== false;
      const token = programmatic ? beginProgrammaticScroll() : 0;
      const onComplete = options.onComplete;

      return originalLenisScrollTo.call(lenis, target, {
        ...options,
        onComplete: (...args) => {
          if (programmatic) finishProgrammaticScroll(token);
          onComplete?.(...args);
        }
      });
    };
  }

  const scrollToY = (targetY, options = {}) => {
    if (lenis?.scrollTo) {
      lenis.scrollTo(Math.max(0, targetY), {
        duration: options.duration ?? 0.62,
        easing: easeInOutCubic,
        force: true,
        immediate: Boolean(options.immediate),
        lock: !options.immediate,
        programmatic: options.programmatic !== false,
        onComplete: options.onComplete
      });
      return;
    }

    const programmatic = options.programmatic !== false;
    const token = programmatic ? beginProgrammaticScroll() : 0;
    nativeTween.scrollTo(targetY, {
      ...options,
      onComplete: () => {
        if (programmatic) finishProgrammaticScroll(token);
        options.onComplete?.();
      }
    });
  };

  const getForwardStageTarget = (controller) => (
    controller.stageStops.find((stop) => stop > controller.playhead + 0.001) ?? 1
  );

  const getStagePlayMs = (controller, direction, target) => {
    if (direction < 0) return controller.playMs;
    const stageIndex = target >= 0.998
      ? controller.stageStops.length
      : controller.stageStops.findIndex((stop) => Math.abs(stop - target) < 0.001);
    return controller.stagePlayMs[stageIndex] || controller.playMs;
  };

  const animateProgress = (controller, direction, target, durationMs, onComplete) => {
    const from = controller.playhead;
    const to = target;
    const startTime = performance.now();
    controller.host.dataset.snapTarget = target.toFixed(4);

    const tick = (now) => {
      if (controller.destroyed) return;
      const progress = clamp((now - startTime) / durationMs);
      controller.playhead = from + (to - from) * easeInOutCubic(progress);
      controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
      if (
        direction > 0
        && controller.targetRevealHeld
        && controller.playhead >= controller.targetRevealReleaseProgress
      ) {
        releaseTargetRevealGate(controller);
      }

      if (progress < 1) {
        controller.raf = requestAnimationFrame(tick);
        return;
      }

      controller.raf = 0;
      controller.playhead = to;
      controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
      onComplete?.();
    };

    cancelAnimationFrame(controller.raf);
    controller.raf = requestAnimationFrame(tick);
  };

  const beginTargetRevealGate = (controller) => {
    if (!shouldGateTargetReveal(controller) || controller.targetRevealHeld) return;
    controller.handoffTarget.setAttribute('data-section-transition-state', 'gated-in');
    controller.handoffTarget.classList.add('homepage-transition-target-gated');
    controller.targetRevealHeld = true;
  };

  const releaseTargetRevealGate = (controller) => {
    if (!controller?.targetRevealHeld) return;
    controller.targetRevealHeld = false;
    controller.handoffTarget?.removeAttribute('data-section-transition-state');
    controller.handoffTarget?.classList.remove('homepage-transition-target-gated');
    window.requestAnimationFrame?.(() => window.ScrollTrigger?.refresh?.());
  };

  const clearSnapVisualState = (controller) => {
    controller?.host?.removeAttribute('data-snap-state');
  };

  const finishPlayback = (controller, { releaseTargetGate = true } = {}) => {
    controller.host.classList.remove('homepage-transition--snapped', 'homepage-transition--playing');
    clearSnapVisualState(controller);
    syncFixedStageState(controller);
    if (releaseTargetGate) releaseTargetRevealGate(controller);
    inputLockUntil = performance.now() + POST_SNAP_INPUT_LOCK_MS;
    syncLastScrollY();
    clearReleaseTimer();
    releaseTimer = window.setTimeout(() => {
      releaseTimer = 0;
      if (activeController !== controller) return;
      activeController = null;
      unlockScroll();
      syncLastScrollY();
    }, POST_SNAP_INPUT_LOCK_MS);
  };

  const notifyHandoffComplete = (controller, { landingY = null } = {}) => {
    if (!controller?.handoffTarget) return;
    controller.host.dataset.handoffComplete = 'true';
    suppressNearbyForwardControllers(controller, landingY);
    presentationController.completeHandoff({
      id: controller.handoffId || controller.host?.dataset?.transitionId || '',
      to: controller.handoffTarget?.dataset?.sectionId || controller.handoffTarget?.id || '',
      target: controller.handoffTarget,
      suppressEntryOnce: controller.host?.dataset?.targetEntrySuppressOnce !== 'false'
    });
    controller.timelineJoins?.forEach((join) => {
      controller.timeline?.releaseJoin(join.id);
    });
  };

  const clearDirectHashAlignmentTimers = (controller) => {
    controller?.directHashAlignmentTimers?.forEach((timer) => window.clearTimeout(timer));
    if (controller) controller.directHashAlignmentTimers = [];
  };

  const alignDirectHashTarget = (controller) => {
    if (
      !controller?.skipForDirectHash
      || controller.destroyed
      || !isDirectHashTargetForController(controller)
      || isDirectHashTargetVisible(controller)
    ) return;

    const targetY = getDirectHashTargetY(controller);
    if (!Number.isFinite(targetY)) return;
    scrollToY(targetY, {
      immediate: true,
      duration: 0
    });
  };

  const completeDirectHashHandoff = (controller) => {
    if (!controller?.handoffTarget || !isDirectHashTargetForController(controller)) return;

    controller.handoffComplete = true;
    controller.playedForward = true;
    controller.playhead = 1;
    controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
    controller.host.dataset.handoffComplete = 'true';
    controller.host.classList.remove(FIXED_STAGE_CLASS);
    clearSnapVisualState(controller);
    if (!controller.directHashHandoffComplete) {
      notifyHandoffComplete(controller);
      controller.directHashHandoffComplete = true;
    }

    clearDirectHashAlignmentTimers(controller);
    controller.directHashAlignmentTimers = DIRECT_HASH_ALIGNMENT_DELAYS.map((delay) => (
      window.setTimeout(() => alignDirectHashTarget(controller), delay)
    ));
  };

  const isAnchorTargetBeyondController = (controller, target) => {
    if (!controller?.host || !target) return false;
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const targetTop = getDocumentTop(target);
    const hostTop = getDocumentTop(controller.host);
    return targetTop >= hostTop + viewportHeight * 0.45;
  };

  const releaseControllerForAnchorNavigation = (controller, target) => {
    if (!controller || controller.destroyed) return;
    if (!isDirectHashTargetForController(controller) && !isAnchorTargetBeyondController(controller, target)) return;

    cancelAnimationFrame(controller.raf);
    controller.raf = 0;
    controller.handoffComplete = true;
    controller.playedForward = true;
    controller.playedBackward = false;
    controller.playhead = 1;
    controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
    controller.host.dataset.handoffComplete = 'true';
    controller.host.classList.remove(
      FIXED_STAGE_CLASS,
      'homepage-transition--snapped',
      'homepage-transition--playing'
    );
    clearSnapVisualState(controller);
    releaseTargetRevealGate(controller);

    if (isDirectHashTargetForController(controller)) {
      completeDirectHashHandoff(controller);
    }
  };

  const handleAnchorNavigation = (event) => {
    const targetId = event?.detail?.targetId || getDirectHashTargetId();
    const target = resolveAnchorTarget(root, targetId);
    if (!target) return;

    clearReleaseTimer();
    inputLockUntil = 0;
    activeController = null;
    scrollLockDepth = 1;
    unlockScroll();
    controllers.forEach((controller) => releaseControllerForAnchorNavigation(controller, target));
    syncLastScrollY();
  };

  const completePlayback = (controller, direction, { hold = false } = {}) => {
    syncSnapViewportHeight();
    const hostTop = getSnapDocumentTop(controller.host);
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const shouldEnterPostScroll = !hold && direction > 0 && controller.postScrollVh > 0 && controller.playhead >= 0.998;
    const shouldInstantExit = !hold && direction > 0 && controller.instantExit && controller.playhead >= 0.998;
    const shouldHandoffAfterPlayback = !hold
      && direction > 0
      && controller.handoffPhase === HANDOFF_AFTER_PLAYBACK
      && controller.handoffTarget
      && controller.playhead >= 0.998;
    const exitY = direction > 0
      ? hostTop + controller.host.offsetHeight + 1
      : hostTop - viewportHeight + 1;
    const targetY = hold
      ? hostTop
      : shouldHandoffAfterPlayback
        ? getHandoffTargetY(controller)
        : shouldEnterPostScroll
          ? getScrollY()
          : exitY;

    scrollToY(targetY, {
      immediate: hold || shouldEnterPostScroll || shouldInstantExit || shouldHandoffAfterPlayback,
      duration: hold || shouldEnterPostScroll || shouldInstantExit || shouldHandoffAfterPlayback ? 0 : 0.58,
      onComplete: () => {
        if (hold && direction > 0) {
          controller.playedForward = false;
          controller.playedBackward = false;
        }
        if (shouldHandoffAfterPlayback) {
          controller.handoffComplete = true;
          notifyHandoffComplete(controller, { landingY: targetY });
        }
        finishPlayback(controller, { releaseTargetGate: !hold && direction > 0 });
      }
    });
  };

  const completePostScrollHandoff = (controller) => {
    const targetY = getHandoffTargetY(controller);
    if (!Number.isFinite(targetY)) return;

    controller.handoffComplete = true;
    clearReleaseTimer();
    inputLockUntil = performance.now() + POST_SNAP_INPUT_LOCK_MS;
    lockScroll();
    scrollToY(targetY, {
      immediate: true,
      duration: 0,
      onComplete: () => {
        notifyHandoffComplete(controller, { landingY: targetY });
        controller.host.classList.remove(FIXED_STAGE_CLASS);
        syncLastScrollY();
        releaseTimer = window.setTimeout(() => {
          releaseTimer = 0;
          unlockScroll();
          syncLastScrollY();
        }, POST_SNAP_INPUT_LOCK_MS);
      }
    });
  };

  const playController = (controller, direction) => {
    if (reduceMotion || activeController || controller.destroyed) return;

    syncSnapViewportHeight();
    clearReleaseTimer();
    inputLockUntil = 0;
    activeController = controller;
    if (direction > 0 && controller.handoffId && controller.handoffTarget) {
      controller.handoffComplete = false;
      controller.host.removeAttribute('data-handoff-complete');
      presentationController.beginHandoff({
        id: controller.handoffId || controller.host?.dataset?.transitionId || '',
        to: controller.handoffTarget?.dataset?.sectionId || controller.handoffTarget?.id || '',
        target: controller.handoffTarget
      });
    }
    if (direction > 0) {
      beginTargetRevealGate(controller);
    } else {
      releaseTargetRevealGate(controller);
    }
    controller.host.classList.add('homepage-transition--snapped', 'homepage-transition--playing');
    controller.host.dataset.snapState = direction > 0 ? 'forward' : 'backward';
    const target = direction > 0 ? getForwardStageTarget(controller) : 0;
    const hold = direction > 0 && target < 0.998;
    const playMs = getStagePlayMs(controller, direction, target);
    const shouldContinueStagedForward = direction > 0 && controller.playhead > 0.001 && target >= 0.998;
    const snapY = direction > 0 && controller.preserveEntry && controller.playhead <= 0.001
      ? getScrollY()
      : shouldContinueStagedForward
        ? getScrollY()
        : getSnapDocumentTop(controller.host);
    if (direction < 0) controller.host.classList.remove(FIXED_STAGE_CLASS);
    controller.playhead = direction > 0
      ? controller.playhead
      : controller.playhead > 0.001 && controller.playhead < 0.998
        ? controller.playhead
        : 1;
    lockScroll();

    scrollToY(snapY, {
      immediate: true,
      onComplete: () => {
        animateProgress(controller, direction, target, playMs, () => completePlayback(controller, direction, { hold }));
      }
    });
  };

  const updateControllerState = (controller, scrollY, direction) => {
    if (controller.destroyed || activeController) return;

    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const hostTop = getDocumentTop(controller.host);
    const hostHeight = Math.max(viewportHeight, controller.host.offsetHeight || viewportHeight);
    const stageHoldOffset = getStageHoldPx(controller, viewportHeight);
    const forwardEntry = hostTop - viewportHeight * controller.snapEntryVh;
    const stagedForwardEntry = controller.playhead > 0.001 && controller.playhead < 0.998
      ? hostTop + stageHoldOffset
      : forwardEntry;
    const forwardExit = hostTop + hostHeight + viewportHeight * 0.18;
    const backwardEntry = controller.playhead >= 0.998 && controller.postScrollVh > 0
      ? hostTop
      : hostTop + hostHeight + viewportHeight * 0.18;
    const backwardExit = hostTop - viewportHeight * 0.58;

    if (controller.skipForDirectHash && isDirectHashTargetForController(controller)) {
      completeDirectHashHandoff(controller);
      return;
    }

    if (scrollY < backwardExit) {
      controller.playedForward = false;
      controller.playhead = 0;
      controller.handoffComplete = false;
      controller.host.removeAttribute('data-handoff-complete');
      controller.host.classList.remove(FIXED_STAGE_CLASS);
      clearSnapVisualState(controller);
      if (
        !controller.forwardSuppressedUntilY
        || scrollY < controller.forwardSuppressionStartY - viewportHeight * 0.35
      ) {
        clearForwardSuppression(controller);
      }
      releaseTargetRevealGate(controller);
    }

    if (scrollY > hostTop + hostHeight + viewportHeight * 0.58) {
      controller.playedBackward = false;
    }

    if (
      controller.handoffComplete
      && controller.handoffPhase === HANDOFF_AFTER_PLAYBACK
      && scrollY >= hostTop - viewportHeight * 0.35
    ) {
      return;
    }

    if (
      direction > 0
      && controller.handoffPhase === HANDOFF_AFTER_PLAYBACK
      && controller.playhead >= 0.998
      && scrollY >= hostTop - 2
    ) {
      return;
    }

    if (direction > 0 && !controller.playedForward && scrollY >= stagedForwardEntry && scrollY < forwardExit) {
      if (controller.forwardSuppressedUntilY && scrollY < controller.forwardSuppressedUntilY) {
        return;
      }
      clearForwardSuppression(controller);
      controller.playedForward = true;
      controller.playedBackward = false;
      playController(controller, 1);
      return;
    }

    if (direction < 0 && !controller.playedBackward && scrollY <= backwardEntry && scrollY > backwardExit) {
      controller.playedBackward = true;
      controller.playedForward = false;
      playController(controller, -1);
    }
  };

  const onScroll = () => {
    if (reduceMotion) return;
    const scrollY = getScrollY();
    controllers.forEach((controller) => syncFixedStageState(controller, scrollY));
    if (!isProgrammaticScroll) {
      controllers.forEach((controller) => {
        if (
          controller.destroyed
          || controller.handoffComplete
          || controller.handoffPhase !== HANDOFF_POST_SCROLL
          || !controller.handoffTarget
          || controller.playhead < 0.998
          || controller.postScrollVh <= 0
        ) return;

        const direction = scrollY >= lastScrollY ? 1 : -1;
        if (direction <= 0 || controller.postProgressSource() < POST_SCROLL_HANDOFF_PROGRESS) return;

        completePostScrollHandoff(controller);
      });
    }
    if (shouldSuppressControllerUpdates()) {
      lastScrollY = scrollY;
      return;
    }
    const direction = scrollY >= lastScrollY ? 1 : -1;
    if (Math.abs(scrollY - lastScrollY) < 1) return;
    lastScrollY = scrollY;
    controllers.forEach((controller) => updateControllerState(controller, scrollY, direction));
  };

  const onResize = () => {
    syncSnapViewportHeight();
    lastScrollY = getScrollY();
  };

  syncSnapViewportHeight();

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onResize, { passive: true });
  window.addEventListener('homepage:anchor-navigation', handleAnchorNavigation);
  window.addEventListener('wheel', preventScrollInput, { passive: false, capture: true });
  window.addEventListener('touchmove', preventScrollInput, { passive: false, capture: true });
  window.addEventListener('keydown', preventScrollKeys, { capture: true });

  return {
    createController(host) {
      const moduleName = host.dataset.transitionModule;
      const handoffTarget = resolveHandoffTarget(root, host);
      const timelineJoins = sceneTimeline?.getJoinsForHost(host) || [];
      const timeline = sceneTimeline?.createAdapterContext(host) || null;
      const directHashTargetId = getDirectHashTargetId();
      const isDirectHandoffTarget = Boolean(
        directHashTargetId
        && host.dataset.handoffId
        && handoffTarget
        && (handoffTarget.id === directHashTargetId || handoffTarget.dataset?.sectionId === directHashTargetId)
      );
      const controller = {
        host,
        timeline,
        timelineJoins,
        timelineJoin: timelineJoins[0] || null,
        playhead: reduceMotion ? 1 : 0,
        playMs: Number(host.dataset.transitionPlayMs) || MODULE_PLAY_MS[moduleName] || DEFAULT_PLAY_MS,
        stageStops: parseNumberList(host.dataset.transitionStageStops, { min: 0, max: 1 }).sort((a, b) => a - b),
        stagePlayMs: parseNumberList(host.dataset.transitionStagePlayMs, { min: 0 }),
        stageHoldVh: Math.max(0, parseFiniteNumber(host.dataset.transitionStageHoldVh, 0)),
        postScrollVh: Math.max(0, parseFiniteNumber(host.dataset.transitionPostScrollVh, 0)),
        snapEntryVh: parseFiniteNumber(host.dataset.transitionSnapEntryVh, DEFAULT_SNAP_ENTRY_VH),
        preserveEntry: host.dataset.transitionPreserveEntry === 'true',
        instantExit: host.dataset.transitionInstantExit === 'true',
        handoffTarget,
        handoffId: host.dataset.handoffId || '',
        handoffOwner: host.dataset.handoffOwner || '',
        handoffScrollTo: host.dataset.handoffScrollTo || '',
        handoffTargetSelector: host.dataset.handoffTargetSelector || '',
        handoffPhase: host.dataset.transitionHandoffPhase || '',
        handoffComplete: isDirectHandoffTarget,
        skipForDirectHash: isDirectHandoffTarget,
        directHashHandoffComplete: false,
        directHashAlignmentTimers: [],
        targetRevealHeld: false,
        forwardSuppressedUntilY: 0,
        forwardSuppressionStartY: 0,
        targetRevealReleaseProgress: clamp(
          parseFiniteNumber(host.dataset.transitionTargetReleaseProgress, DEFAULT_TARGET_GATE_RELEASE_PROGRESS),
          0,
          1
        ),
        raf: 0,
        playedForward: isDirectHandoffTarget,
        playedBackward: false,
        destroyed: false,
        progressSource() {
          return this.playhead;
        },
        postProgressSource() {
          const viewportHeight = Math.max(1, window.innerHeight || 1);
          const postScrollPx = Math.max(0, viewportHeight * ((this.postScrollVh || 0) / 100));
          if (postScrollPx <= 0) return this.playhead >= 0.998 ? 1 : 0;
          const stageHoldPx = Math.max(0, viewportHeight * ((this.stageHoldVh || 0) / 100));
          const postStart = getDocumentTop(this.host) + stageHoldPx;
          return clamp((getScrollY() - postStart) / postScrollPx);
        },
        destroy() {
          this.destroyed = true;
          clearDirectHashAlignmentTimers(this);
          clearForwardSuppression(this);
          releaseTargetRevealGate(this);
          this.host.classList.remove(FIXED_STAGE_CLASS);
          clearSnapVisualState(this);
          this.host.removeAttribute('data-snap-playhead');
          this.host.removeAttribute('data-snap-target');
          cancelAnimationFrame(this.raf);
        }
      };
      controller.host.dataset.snapPlayhead = controller.playhead.toFixed(4);
      syncControllerSnapHold(controller);
      controllers.push(controller);
      if (isDirectHandoffTarget) completeDirectHashHandoff(controller);
      return controller;
    },
    destroy() {
      controllers.forEach((controller) => controller.destroy());
      controllers.length = 0;
      clearReleaseTimer();
      programmaticScrollToken += 1;
      isProgrammaticScroll = false;
      inputLockUntil = 0;
      activeController = null;
      scrollLockDepth = 1;
      unlockScroll();
      if (previousSnapViewportHeight) {
        rootElement?.style?.setProperty(SNAP_VIEWPORT_HEIGHT_VAR, previousSnapViewportHeight);
      } else {
        rootElement?.style?.removeProperty(SNAP_VIEWPORT_HEIGHT_VAR);
      }
      if (lenis && originalLenisScrollTo) lenis.scrollTo = originalLenisScrollTo;
      presentationController.clear();
      nativeTween.destroy();
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('homepage:anchor-navigation', handleAnchorNavigation);
      window.removeEventListener('wheel', preventScrollInput, true);
      window.removeEventListener('touchmove', preventScrollInput, true);
      window.removeEventListener('keydown', preventScrollKeys, true);
    }
  };
}

function fallbackHost(host, error) {
  console.warn('Homepage transition failed; using soft divider.', error);
  host.dataset.transitionModule = 'soft-divider';
  host.classList.add('chapter-transition--fallback', 'scene-transition--fallback');
}

export async function initHomepageTransitions(options = {}) {
  const MASTER_TIMELINE_ENABLED = document.documentElement.dataset.masterTimelineEnabled === 'true';
  if (!MASTER_TIMELINE_ENABLED) return initLegacyHomepageTransitions(options);

  const cleanup = createCleanupStack();
  cleanup.add(await initLegacyHomepageTransitions(options));
  cleanup.add(await initMasterHomepageTransitions(options));
  return cleanup;
}

async function initMasterHomepageTransitions(options = {}) {
  const cleanup = createCleanupStack();
  const runtime = await createHomepageMasterRuntime(options);
  cleanup.add(runtime);
  runtime.start();
  window.addEventListener('pagehide', cleanup.destroy, { once: true });
  cleanup.add(() => window.removeEventListener('pagehide', cleanup.destroy));
  return cleanup;
}

async function createHomepageMasterRuntime(options = {}) {
  const root = options.root || document;
  const masterTimelineModel = createMasterTimelineModel(homepageMasterTimeline);
  const masterScrollMap = createMasterScrollMap({
    root,
    model: masterTimelineModel,
    getViewportHeight: () => window.innerHeight
  });
  const masterSceneRegistry = createMasterSceneRegistry({
    root,
    model: masterTimelineModel
  });
  const masterScenePresenter = createMasterScenePresenter({
    root,
    model: masterTimelineModel,
    registry: masterSceneRegistry
  });
  const masterSurfaceProducerRegistry = createMasterSurfaceProducerRegistry({
    model: masterTimelineModel,
    registry: masterSceneRegistry
  });
  const masterInkCanvas = root.querySelector('[data-master-ink-canvas]');
  if (!masterInkCanvas) throw new Error('Missing [data-master-ink-canvas]');
  const masterInkCompositor = createMasterInkCompositor({
    canvas: masterInkCanvas,
    registry: masterSceneRegistry
  });
	  let previousTimelineVh = 0;
	  let previousMasterState = null;
	  let masterTimelineFrameId = 0;
	  let masterTimelineRunning = false;
	  const mountedAdapterGroups = new Map();
	  const mountedSceneRenderers = new Map();
	  const masterTimelineHud = root.querySelector('[data-master-timeline-hud]');
	  const masterHudFields = masterTimelineHud
	    ? {
	        total: masterTimelineHud.querySelector('[data-master-hud-total]'),
	        block: masterTimelineHud.querySelector('[data-master-hud-block-label]'),
	        segment: masterTimelineHud.querySelector('[data-master-hud-segment]'),
	        local: masterTimelineHud.querySelector('[data-master-hud-local]'),
	        direction: masterTimelineHud.querySelector('[data-master-hud-direction]'),
	        copy: masterTimelineHud.querySelector('[data-master-hud-copy]'),
	        ink: masterTimelineHud.querySelector('[data-master-hud-ink]'),
	        track: masterTimelineHud.querySelector('[data-master-hud-track]'),
	        blocks: [...masterTimelineHud.querySelectorAll('[data-master-hud-block]')]
	      }
	    : null;

  function normalizeHomepageAdapter(adapter) {
    return {
      render: typeof adapter?.render === 'function' ? adapter.render.bind(adapter) : () => {},
      renderIdle: typeof adapter?.renderIdle === 'function' ? adapter.renderIdle.bind(adapter) : () => {},
      destroy: typeof adapter?.destroy === 'function' ? adapter.destroy.bind(adapter) : () => {}
    };
  }

  function mountHomepageAdapterGroup(group, adapter) {
    const key = `${group.adapterName}:${group.hostSelector}`;
    mountedAdapterGroups.set(key, {
      adapterName: group.adapterName,
      hostSelector: group.hostSelector,
      segmentIds: new Set(group.segments.map((segment) => segment.id)),
      adapter: normalizeHomepageAdapter(adapter)
    });
  }

  function normalizeSceneRenderer(renderer) {
    return {
      renderAt: typeof renderer?.renderAt === 'function' ? renderer.renderAt.bind(renderer) : () => {},
      renderIdle: typeof renderer?.renderIdle === 'function' ? renderer.renderIdle.bind(renderer) : () => {},
      destroy: typeof renderer?.destroy === 'function' ? renderer.destroy.bind(renderer) : () => {}
    };
  }

  function mountSceneRenderer(sceneId, renderer) {
    mountedSceneRenderers.set(sceneId, normalizeSceneRenderer(renderer));
  }

	  function renderMasterVisualState(state) {
    const activeSegmentId = state.segment?.id || null;
    for (const group of mountedAdapterGroups.values()) {
      if (activeSegmentId && group.segmentIds.has(activeSegmentId)) {
        group.adapter.render?.(state);
      } else {
        group.adapter.renderIdle?.(state);
      }
    }

    const activeHoldSceneId = state.segment ? null : state.block?.scene;
    for (const [sceneId, renderer] of mountedSceneRenderers) {
      if (sceneId === activeHoldSceneId) {
        renderer.renderAt?.(state.blockProgress, state);
      } else {
        renderer.renderIdle?.(state);
      }
    }
	  }

	  function formatMasterHudCopy(state) {
	    const visibleCopies = [...state.scenes.values()]
	      .filter((sceneState) => sceneState.copy?.opacity > 0.04)
	      .map((sceneState) => {
	        const copyId = sceneState.scene?.id === 'method' ? 'method.intro' : sceneState.scene?.id;
	        const suffix = sceneState.copy.readable ? '' : '*';
	        return `${copyId || 'unknown'}${suffix}`;
	      });
	    return visibleCopies.length ? visibleCopies.join(' + ') : 'none';
	  }

	  function formatMasterHudInk(state) {
	    const ink = state.segment?.transition?.ink;
	    if (!ink) return 'inactive';
	    const [start, end] = ink.window || [0, 1];
	    const activeEnd = Math.max(start, end - 0.0001);
	    const active = state.localProgress >= start && state.localProgress < activeEnd;
	    const source = ink.sourceSurfaceKey || 'source';
	    const target = ink.targetSurfaceKey || 'target';
	    return `${active ? 'active' : 'armed'} ${source}->${target} ${start.toFixed(2)}-${end.toFixed(2)}`;
	  }

	  function updateMasterTimelineHud(state, timelineVh) {
	    if (!masterTimelineHud || !masterHudFields) return;
	    const totalProgress = masterTimelineModel.totalVh
	      ? Math.min(1, Math.max(0, timelineVh / masterTimelineModel.totalVh))
	      : 0;
	    const blockId = state.block?.id || state.segment?.id || 'initial';
	    masterTimelineHud.style.setProperty('--master-hud-progress', totalProgress.toFixed(5));
	    masterTimelineHud.dataset.masterHudBlock = blockId;
	    masterTimelineHud.dataset.masterHudSegment = state.segment?.id || '';
	    masterHudFields.total.textContent = `${(totalProgress * 100).toFixed(1)}% / ${timelineVh.toFixed(1)}vh`;
	    masterHudFields.track?.setAttribute('aria-valuenow', String(Math.round(totalProgress * 100)));
	    masterHudFields.block.textContent = blockId;
	    masterHudFields.segment.textContent = state.segment ? state.segment.id : `hold:${state.block?.scene || 'none'}`;
	    masterHudFields.local.textContent = `${state.localProgress.toFixed(4)} (${state.blockProgress.toFixed(4)})`;
	    masterHudFields.direction.textContent = state.direction;
	    masterHudFields.copy.textContent = formatMasterHudCopy(state);
	    masterHudFields.ink.textContent = formatMasterHudInk(state);
	    for (const block of masterHudFields.blocks) {
	      block.dataset.masterHudActive = block.dataset.masterHudBlock === blockId ? 'true' : 'false';
	    }
	  }

  function createMasterHudScrubber() {
    const hudTrack = masterHudFields?.track;
    if (!masterTimelineHud || !hudTrack) return null;

    let isScrubbing = false;

    const scrollToTimelineVh = (timelineVh) => {
      masterScrollMap.refresh();
      const targetY = masterScrollMap.scrollYForTimelineVh(timelineVh);
      const lenis = options.scrollRuntime?.lenis;
      if (lenis?.scrollTo) {
        lenis.scrollTo(targetY, {
          immediate: true,
          duration: 0,
          force: true,
          lock: false
        });
      } else {
        window.scrollTo({ top: targetY, left: window.scrollX, behavior: 'auto' });
      }
      window.ScrollTrigger?.update?.();
    };

    const timelineVhForClientX = (clientX) => {
      const rect = hudTrack.getBoundingClientRect();
      const progress = rect.width ? clamp((clientX - rect.left) / rect.width) : 0;
      return progress * masterTimelineModel.totalVh;
    };

    const scrubToClientX = (clientX) => {
      scrollToTimelineVh(timelineVhForClientX(clientX));
    };

    const stopScrubbing = () => {
      if (!isScrubbing) return;
      isScrubbing = false;
      delete masterTimelineHud.dataset.masterHudScrubbing;
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);
    };

    const onPointerMove = (event) => {
      if (!isScrubbing) return;
      event.preventDefault();
      scrubToClientX(event.clientX);
    };

    const onPointerUp = (event) => {
      if (isScrubbing) {
        event.preventDefault();
        scrubToClientX(event.clientX);
      }
      stopScrubbing();
    };

    const onPointerDown = (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      event.preventDefault();
      event.stopPropagation();
      isScrubbing = true;
      masterTimelineHud.dataset.masterHudScrubbing = 'true';
      scrubToClientX(event.clientX);
      window.addEventListener('pointermove', onPointerMove, { passive: false });
      window.addEventListener('pointerup', onPointerUp, { passive: false });
      window.addEventListener('pointercancel', onPointerUp, { passive: false });
    };

    const onKeyDown = (event) => {
      const currentTimelineVh = masterScrollMap.positionForScrollY(window.scrollY);
      const step = event.shiftKey ? 25 : 8;
      let nextTimelineVh = currentTimelineVh;
      if (event.key === 'ArrowLeft') nextTimelineVh -= step;
      else if (event.key === 'ArrowRight') nextTimelineVh += step;
      else if (event.key === 'PageUp') nextTimelineVh -= 60;
      else if (event.key === 'PageDown') nextTimelineVh += 60;
      else if (event.key === 'Home') nextTimelineVh = 0;
      else if (event.key === 'End') nextTimelineVh = masterTimelineModel.totalVh;
      else return;

      event.preventDefault();
      event.stopPropagation();
      scrollToTimelineVh(Math.max(0, Math.min(masterTimelineModel.totalVh, nextTimelineVh)));
    };

    hudTrack.addEventListener('pointerdown', onPointerDown);
    hudTrack.addEventListener('keydown', onKeyDown);

    return {
      destroy() {
        stopScrubbing();
        hudTrack.removeEventListener('pointerdown', onPointerDown);
        hudTrack.removeEventListener('keydown', onKeyDown);
      }
    };
  }

	  function renderMasterTimelineFrame() {
    if (!masterTimelineRunning) return;
    const timelineVh = masterScrollMap.positionForScrollY(window.scrollY);
    const resolvedState = resolveMasterTimelineState(masterTimelineModel, timelineVh, previousTimelineVh);
    const isStationary = Math.abs(timelineVh - previousTimelineVh) < 0.0001;
    const state = resolvedState && isStationary && previousMasterState
      ? Object.freeze({ ...resolvedState, direction: previousMasterState.direction })
      : (resolvedState || previousMasterState || masterTimelineModel.initialState);
    previousTimelineVh = timelineVh;
    previousMasterState = state;
    masterScenePresenter.applyLayout(state);
    masterSurfaceProducerRegistry.renderSurfaceProducers(state);
	    renderMasterVisualState(state);
	    masterInkCompositor.render(state);
	    masterScenePresenter.applyVisibility(state);
	    updateMasterTimelineHud(state, timelineVh);
	    masterTimelineFrameId = requestAnimationFrame(renderMasterTimelineFrame);
	  }

  function startMasterTimelineRuntime() {
    if (masterTimelineRunning) return;
    masterScrollMap.refresh();
    masterTimelineRunning = true;
    masterTimelineFrameId = requestAnimationFrame(renderMasterTimelineFrame);
  }

  function destroyMasterTimelineRuntime() {
    masterTimelineRunning = false;
    if (masterTimelineFrameId) {
      cancelAnimationFrame(masterTimelineFrameId);
      masterTimelineFrameId = 0;
    }
    for (const group of mountedAdapterGroups.values()) {
      group.adapter.destroy?.();
    }
    for (const renderer of mountedSceneRenderers.values()) {
      renderer.destroy?.();
    }
    mountedAdapterGroups.clear();
    mountedSceneRenderers.clear();
    masterSurfaceProducerRegistry.destroy();
    masterScrollMap.destroy();
    masterInkCompositor.destroy();
    masterScenePresenter.clear();
    previousMasterState = null;
    masterHudScrubber?.destroy?.();
  }

  async function mountMasterSurfaceProducers() {
    for (const surface of masterTimelineModel.surfaces) {
      const producerFactory = homepageSurfaceProducerRegistry[surface.producer];
      if (typeof producerFactory !== 'function') {
        throw new Error(`Missing master surface producer factory: ${surface.producer}`);
      }
      const producer = await producerFactory({
        ...options,
        surface,
        surfaceEntry: masterSceneRegistry.surfaceFor(surface.id),
        registry: masterSceneRegistry,
        model: masterTimelineModel
      });
      masterSurfaceProducerRegistry.mountSurfaceProducer(surface.id, producer);
    }
  }

  async function mountMasterHomepageAdapters() {
    const groups = new Map();
    for (const segment of masterTimelineModel.segments.filter((item) => item.transition?.type !== 'soft')) {
      const adapterName = segment.transition?.adapter;
      if (!adapterName) continue;
      const key = `${adapterName}:${segment.hostSelector}`;
      if (!groups.has(key)) groups.set(key, { adapterName, hostSelector: segment.hostSelector, segments: [] });
      groups.get(key).segments.push(segment);
    }

    for (const group of groups.values()) {
      const host = root.querySelector(group.hostSelector);
      if (!host) throw new Error(`Missing master adapter host: ${group.hostSelector}`);
      const loadAdapter = homepageTransitionRegistry[group.adapterName];
      if (typeof loadAdapter !== 'function') continue;
      const module = await loadAdapter();
      const factory = module.mountPatternBloomTransition
        || module.mountHomepageTransition
        || module.mountHomepageAdapter
        || module.default;
      if (typeof factory !== 'function') continue;
      const adapter = factory({
        ...options,
        host,
        reduceMotion: Boolean(options.reduceMotion),
        segments: group.segments,
        masterTimeline: masterTimelineModel,
        registry: masterSceneRegistry,
        presenter: masterScenePresenter,
        addCleanup: options.addCleanup
      });
      mountHomepageAdapterGroup(group, adapter);
    }
  }

  // Master-visible salvage mode observes the real legacy visual flow. Do not
  // mount transition adapters here; legacy runtime owns the real DOM/video
  // stages and the master runtime only drives HUD/state diagnostics.
  await mountMasterSurfaceProducers();
  masterSurfaceProducerRegistry.assertAllProducersMounted();
  const masterHudScrubber = createMasterHudScrubber();

  return {
    start: startMasterTimelineRuntime,
    destroy: destroyMasterTimelineRuntime,
    mountSceneRenderer
  };
}

async function initLegacyHomepageTransitions({
  root = document,
  reduceMotion = false,
  scrollRuntime = null,
  gsap = window.gsap,
  ScrollTrigger = window.ScrollTrigger
} = {}) {
  const cleanup = createCleanupStack();
  const hosts = [...root.querySelectorAll(NAMED_TRANSITION_SELECTOR)];
  const presentationController = createSectionPresentationController({ root });
  const sceneTimeline = null;
  const snapCoordinator = createHomepageSnapCoordinator({
    root,
    reduceMotion,
    scrollRuntime,
    presentationController,
    sceneTimeline
  });
  cleanup.add(snapCoordinator);

  await Promise.all(hosts.map(async (host) => {
    const moduleName = host.dataset.transitionModule;
    if (!moduleName || SOFT_MODULES.has(moduleName)) return;

    if (reduceMotion) {
      host.classList.add(REDUCED_MOTION_CLASS);
      cleanup.add(() => host.classList.remove(REDUCED_MOTION_CLASS));
      return;
    }

    const loadAdapter = homepageTransitionRegistry[moduleName];
    if (!loadAdapter) {
      fallbackHost(host, new Error(`Unknown homepage transition module: ${moduleName}`));
      return;
    }

    try {
      const isScrollDriven = host.dataset.transitionDrive === 'scroll' || SCROLL_DRIVEN_MODULES.has(moduleName);
      const snapController = isScrollDriven ? null : snapCoordinator.createController(host);
      const progressSource = isScrollDriven
        ? (host.dataset.transitionId === 'home-belief'
          ? createHeroLinkedScrollProgressSource(host)
          : createElementScrollProgressSource(host))
        : () => snapController.progressSource();
      const handoffTarget = resolveHandoffTarget(root, host);
      const timeline = snapController?.timeline || null;
      const adapterModule = await loadAdapter();
      const mount = adapterModule.mountHomepageTransition || adapterModule.mountPatternBloomTransition;
      if (typeof mount !== 'function') {
        throw new Error(`Transition module ${moduleName} has no homepage mount function.`);
      }

      cleanup.add(mount({
        host,
        reduceMotion,
        progressSource,
        postProgressSource: snapController?.postProgressSource?.bind(snapController),
        handoffTarget,
        timeline,
        addCleanup: cleanup.add,
        gsap,
        ScrollTrigger
      }));
    } catch (error) {
      fallbackHost(host, error);
    }
  }));

  window.addEventListener('pagehide', cleanup.destroy, { once: true });
  cleanup.add(() => window.removeEventListener('pagehide', cleanup.destroy));

  return cleanup;
}
