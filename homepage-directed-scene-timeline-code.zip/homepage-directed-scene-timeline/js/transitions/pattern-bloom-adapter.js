import { createPatternBloomScene } from '../pattern-mirror-stage.js';
import { createInkSceneTransition } from '../effects/ink-scene-transition.js';

const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const range01 = (value, start, end) => clamp((value - start) / Math.max(0.001, end - start));
const smoothStep = (value) => value * value * (3 - 2 * value);

const REVEAL_END = 0.46;
const BLOOM_START = 0.42;
const BLOOM_END = 0.70;
const BELIEF_PIN_CLASS = 'is-pattern-bloom-pinned';
const COVER_PRIOR_SCENE_CLASS = 'is-pattern-bloom-covering';

function getCurrentHashId() {
  const hash = window.location.hash || '';
  if (!hash.startsWith('#')) return '';
  try {
    return decodeURIComponent(hash.slice(1));
  } catch {
    return hash.slice(1);
  }
}

function isDirectVisitToBelief(beliefSection) {
  const hashId = getCurrentHashId();
  return Boolean(
    hashId
    && beliefSection
    && (beliefSection.id === hashId || beliefSection.dataset?.sectionId === hashId)
  );
}

export function mountPatternBloomTransition({
  host,
  reduceMotion = false,
  progressSource,
  timeline,
  addCleanup
} = {}) {
  if (!host || host.dataset.patternBloomMounted === 'true') {
    return { destroy() {} };
  }

  host.dataset.patternBloomMounted = 'true';
  const doc = host.ownerDocument || document;
  const beliefSection = doc.querySelector('.canvas-section--belief');
  if (isDirectVisitToBelief(beliefSection)) {
    delete host.dataset.patternBloomMounted;
    return { destroy() {} };
  }

  host.classList.add('homepage-transition', 'homepage-transition--pattern-bloom', 'chapter-transition--pattern-bloom');
  const previousAriaHidden = host.getAttribute('aria-hidden');
  const previousRole = host.getAttribute('role');
  const previousAriaLabel = host.getAttribute('aria-label');
  host.removeAttribute('aria-hidden');
  host.setAttribute('role', 'region');
  host.setAttribute('aria-label', '同野观幂莲花转场');

  const beliefStarCanvas = beliefSection?.querySelector('[data-belief-star-field]') || null;
  const stage = doc.createElement('div');
  stage.className = 'pattern-bloom-transition__stage';

  const paper = doc.createElement('div');
  paper.className = 'pattern-bloom-transition__paper';
  paper.setAttribute('aria-hidden', 'true');

  const canvas = doc.createElement('canvas');
  canvas.className = 'pattern-bloom-transition__canvas';
  canvas.setAttribute('aria-hidden', 'true');

  const revealInkCanvas = doc.createElement('canvas');
  revealInkCanvas.className = 'pattern-bloom-transition__reveal-ink';
  revealInkCanvas.setAttribute('aria-hidden', 'true');

  const exitInkCanvas = doc.createElement('canvas');
  exitInkCanvas.className = 'pattern-bloom-transition__exit-ink';
  exitInkCanvas.setAttribute('aria-hidden', 'true');

  stage.append(paper, canvas, exitInkCanvas, revealInkCanvas);
  stage.dataset.transitionGhost = 'pattern-bloom-lotus';
  (doc.body || host).append(stage);
  const revealInkTransition = createInkSceneTransition(revealInkCanvas, {
    targetSrc: '',
    nextSceneElement: canvas,
    hideAtEnd: true,
    perlinOverlay: false,
    perlinStrength: 0,
    progressSpan: 1,
    colorLift: 0.58,
    sceneBrightness: 1,
    inkCenterX: 0.5,
    inkCenterY: 0.5,
    transparentOutside: true
  });
  const exitInkTransition = createInkSceneTransition(exitInkCanvas, {
    targetSrc: 'assets/back2.png',
    nextSceneElement: beliefStarCanvas,
    hideAtEnd: true,
    perlinOverlay: true,
    perlinStrength: 0.40,
    progressSpan: 0.94,
    colorLift: 0.62,
    sceneBrightness: 0.92,
    inkCenterX: 0.50,
    inkCenterY: 1.04,
    transparentOutside: true
  });
  const getViewportState = () => {
    const viewportHeight = Math.max(1, window.innerHeight || 1);
    const rect = host.getBoundingClientRect();
    const scrollSpan = Math.max(1, rect.height || host.offsetHeight || viewportHeight);
    const raw = (viewportHeight - rect.top) / scrollSpan;
    return {
      raw,
      progress: clamp(raw),
      active: raw > 0 && raw < 1
    };
  };
  const getRawProgress = () => {
    const viewportState = getViewportState();
    if (typeof progressSource !== 'function') return viewportState.progress;
    return clamp(progressSource());
  };
  const getBloomProgress = () => range01(getRawProgress(), BLOOM_START, BLOOM_END);

  const scene = createPatternBloomScene({
    canvas,
    progressSource: getBloomProgress,
    reducedMotion: reduceMotion,
    reducedMotionProgress: 1,
    continuousMotion: true,
    scrollDrivenMotion: true,
    dprLimit: 1,
    center: {
      x: 0.24,
      y: 0.55,
      mobileX: 0.50,
      mobileY: 0.58
    }
  });

  let destroyed = false;
  let sceneReady = false;
  let overlayRaf = 0;
  let beliefPinY = 0;
  const clearBeliefTransitionState = () => {
    if (!beliefSection) return;
    beliefSection.classList.remove(BELIEF_PIN_CLASS);
    beliefSection.style.removeProperty('--belief-transition-opacity');
    beliefSection.style.removeProperty('--belief-transition-y');
    beliefSection.style.removeProperty('--belief-upper-opacity');
    beliefSection.style.removeProperty('--belief-upper-copy-opacity');
    beliefSection.style.removeProperty('--belief-upper-visibility');
    beliefSection.style.removeProperty('--belief-lower-opacity');
    beliefSection.style.removeProperty('--belief-lower-copy-opacity');
    beliefSection.style.removeProperty('--belief-lower-visibility');
    beliefSection.style.removeProperty('--belief-scene-copy-opacity');
    beliefSection.style.removeProperty('--belief-scene-copy-y');
    beliefSection.style.removeProperty('--belief-scene-copy-blur');
    beliefPinY = 0;
  };
  const setBeliefTransitionState = ({
    pinned,
    sceneOpacity = 1,
    upperOpacity = 0,
    lowerOpacity = 0,
    copyProgress = 1,
    presentationTarget: target = beliefSection
  }) => {
    if (!target) return;
    if (!pinned) {
      clearBeliefTransitionState();
      return;
    }

    const transformedTop = target.getBoundingClientRect().top;
    const baseTop = transformedTop - beliefPinY;
    beliefPinY = -baseTop;

    const copyY = (1 - copyProgress) * 28;
    const copyBlur = (1 - copyProgress) * 10;
    target.classList.add(BELIEF_PIN_CLASS);
    target.style.setProperty('--belief-transition-y', `${beliefPinY.toFixed(2)}px`);
    target.style.setProperty('--belief-transition-opacity', sceneOpacity.toFixed(4));
    target.style.setProperty('--belief-upper-opacity', upperOpacity.toFixed(4));
    target.style.setProperty('--belief-upper-copy-opacity', upperOpacity.toFixed(4));
    target.style.setProperty('--belief-upper-visibility', upperOpacity > 0.01 ? 'visible' : 'hidden');
    target.style.setProperty('--belief-lower-opacity', lowerOpacity.toFixed(4));
    target.style.setProperty('--belief-lower-copy-opacity', lowerOpacity.toFixed(4));
    target.style.setProperty('--belief-lower-visibility', lowerOpacity > 0.01 ? 'visible' : 'hidden');
    target.style.setProperty('--belief-scene-copy-opacity', copyProgress.toFixed(4));
    target.style.setProperty('--belief-scene-copy-y', `${copyY.toFixed(2)}px`);
    target.style.setProperty('--belief-scene-copy-blur', `${copyBlur.toFixed(2)}px`);
  };

  const renderOverlays = () => {
    if (destroyed) return;
    const viewportState = getViewportState();
    const progress = getRawProgress();
    const overlayActive = progress > 0.002 && (progress < 0.999 || viewportState.raw < 1.05);
    const revealProgress = smoothStep(range01(progress, 0, REVEAL_END));
    const revealVisibility = revealProgress >= 0.998
      ? 1
      : (progress > 0.0001 ? Math.max(revealProgress, 0.003) : 0);
    const canvasRevealed = sceneReady && revealProgress >= 0.998;
    const lotusExitProgress = smoothStep(range01(progress, 0.10, 0.34));
    const upperEnterProgress = smoothStep(range01(progress, 0.22, 0.46));
    const upperHoldProgress = smoothStep(range01(progress, 0.46, 0.58));
    const upperExitProgress = smoothStep(range01(progress, 0.58, 0.76));
    const lowerInkProgress = smoothStep(range01(progress, 0.62, 0.88));
    const lowerCopyProgress = smoothStep(range01(progress, 0.74, 0.92));
    timeline?.updateJoin('home-belief', progress, {
      reason: 'pattern-bloom-render',
      milestones: {
        lotusContracted: lotusExitProgress >= 0.92,
        beliefUpperReady: upperEnterProgress > 0.05,
        beliefUpperCopyComplete: upperEnterProgress >= 0.998
      }
    });
    timeline?.updateJoin('belief-upper-lower', progress, {
      reason: 'pattern-bloom-render',
      milestones: {
        upperCopyHeld: upperHoldProgress >= 0.8,
        bottomUpInkStarted: lowerInkProgress > 0.02,
        upperToLowerInkComplete: lowerInkProgress >= 0.998,
        beliefLowerCopyComplete: lowerCopyProgress >= 0.998
      }
    });
    const hasTimelineOwnership = typeof timeline?.getOwnership === 'function';
    const upperOwnership = timeline?.getOwnership?.('home-belief');
    const lowerOwnership = timeline?.getOwnership?.('belief-upper-lower');
    const patternOwnsLayer = !hasTimelineOwnership
      || upperOwnership?.layerOwner === 'pattern-bloom'
      || lowerOwnership?.layerOwner === 'pattern-bloom';
    const patternOwnsRevealMask = !hasTimelineOwnership
      || upperOwnership?.maskOwner === 'pattern-reveal';
    const patternOwnsBottomInk = !hasTimelineOwnership
      || lowerOwnership?.maskOwner === 'bottom-up-ink';
    const patternOwnsMask = patternOwnsRevealMask || patternOwnsBottomInk;
    const starOwnsCanvas = !hasTimelineOwnership
      || lowerOwnership?.canvasOwner === 'belief-star-field';
    const upperCanForeground = !hasTimelineOwnership
      || upperOwnership?.foregroundCopyOwner === 'belief-upper';
    const lowerCanForeground = !hasTimelineOwnership
      || lowerOwnership?.foregroundCopyOwner === 'belief-lower';
    const rawPatternOpacity = clamp(1 - lowerInkProgress);
    const starOpacity = starOwnsCanvas ? smoothStep(range01(progress, 0.80, 0.94)) : 0;
    const patternOpacity = starOpacity > 0.35 ? Math.min(rawPatternOpacity, 0.35) : rawPatternOpacity;
    const exitInkOpacity = patternOwnsMask && lowerInkProgress > 0 && lowerInkProgress < 0.995 ? 1 : 0;
    const upperBaseOpacity = clamp(upperEnterProgress * 1.12 * (1 - upperExitProgress));
    const lowerBaseOpacity = lowerInkProgress > 0.02 ? lowerCopyProgress : 0;
    const upperOpacity = upperCanForeground ? upperBaseOpacity : 0;
    const lowerOpacity = lowerCanForeground ? lowerBaseOpacity : 0;
    const copyProgress = Math.max(upperEnterProgress, lowerCopyProgress);
    const beliefSceneOpacity = patternOwnsLayer ? starOpacity : 0;
    const lotusVisible = patternOwnsLayer && canvasRevealed && patternOpacity > 0.002;

    const coverPriorScene = overlayActive && sceneReady && patternOwnsLayer;
    doc.body?.classList.toggle(COVER_PRIOR_SCENE_CLASS, coverPriorScene);
    setBeliefTransitionState({
      pinned: overlayActive && patternOwnsLayer,
      sceneOpacity: beliefSceneOpacity,
      upperOpacity,
      lowerOpacity,
      copyProgress,
      presentationTarget: beliefSection
    });

    stage.style.opacity = overlayActive && patternOwnsLayer ? patternOpacity.toFixed(4) : '0';
    stage.style.visibility = overlayActive && patternOwnsLayer ? 'visible' : 'hidden';
    paper.style.opacity = '0';
    paper.style.visibility = 'hidden';
    canvas.style.opacity = lotusVisible ? patternOpacity.toFixed(4) : '0';
    canvas.style.visibility = lotusVisible ? 'visible' : 'hidden';
    revealInkTransition?.render(
      revealProgress,
      0,
      0,
      patternOwnsRevealMask && sceneReady ? revealVisibility : 0
    );
    const bottomUpInkCenterY = 1.18 - lowerInkProgress * 0.58;
    exitInkTransition?.render(patternOwnsBottomInk ? lowerInkProgress : 0, 0, 0, exitInkOpacity, {
      perlinStrength: 0.40,
      sceneBrightness: 0.92,
      inkCenterY: bottomUpInkCenterY
    });
    overlayRaf = requestAnimationFrame(renderOverlays);
  };
  renderOverlays();

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    cancelAnimationFrame(overlayRaf);
    clearBeliefTransitionState();
    doc.body?.classList.remove(COVER_PRIOR_SCENE_CLASS);
    scene.destroy();
    stage.remove();
    host.classList.remove('homepage-transition', 'homepage-transition--pattern-bloom', 'chapter-transition--pattern-bloom');
    if (previousAriaHidden === null) {
      host.removeAttribute('aria-hidden');
    } else {
      host.setAttribute('aria-hidden', previousAriaHidden);
    }
    if (previousRole === null) {
      host.removeAttribute('role');
    } else {
      host.setAttribute('role', previousRole);
    }
    if (previousAriaLabel === null) {
      host.removeAttribute('aria-label');
    } else {
      host.setAttribute('aria-label', previousAriaLabel);
    }
    delete host.dataset.patternBloomMounted;
  };

  scene.start().then(() => {
    sceneReady = true;
    canvas.dataset.inkTextureReady = 'true';
  }).catch((error) => {
    console.warn('Pattern bloom transition failed; falling back to soft divider.', error);
    host.dataset.transitionModule = 'soft-divider';
    host.classList.add('chapter-transition--fallback', 'scene-transition--fallback');
    destroy();
  });

  addCleanup?.(destroy);
  return { destroy };
}
