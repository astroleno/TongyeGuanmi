const setVar = (element, name, value) => {
  element?.style?.setProperty(name, value);
};

const applySceneState = (entry, sceneId, state) => {
  if (!entry || !state) return;
  const { rootElement, visualElement, copyRootElement, layoutAnchor } = entry;
  rootElement.setAttribute('data-master-scene-active', state.active ? 'true' : 'false');
  rootElement.setAttribute('data-master-role', state.role || 'inactive');
  rootElement.style.setProperty('--master-scene-z', String(state.visual.zIndex));

  layoutAnchor.setAttribute('data-master-scene-active', state.active ? 'true' : 'false');
  layoutAnchor.setAttribute('data-master-role', state.role || 'inactive');
  if (entry.scene.viewportAnchor) {
    const anchor = entry.scene.viewportAnchor;
    const maxWidth = Number(anchor.maxWidthPx) || 560;
    const rightVw = Number(anchor.rightVw) || 8;
    layoutAnchor.style.position = 'absolute';
    layoutAnchor.style.inset = 'auto';
    layoutAnchor.style.top = `${anchor.topVh}vh`;
    layoutAnchor.style.left = anchor.align === 'center' ? '50%' : 'auto';
    layoutAnchor.style.right = anchor.align === 'right' ? `${rightVw}vw` : 'auto';
    layoutAnchor.style.bottom = 'auto';
    layoutAnchor.style.height = 'auto';
    layoutAnchor.style.width = anchor.align === 'right'
      ? `min(calc(100vw - ${rightVw * 2}vw), ${maxWidth}px)`
      : `min(100%, ${maxWidth}px)`;
    layoutAnchor.style.maxWidth = `${maxWidth}px`;
    layoutAnchor.style.transform = anchor.align === 'center' ? 'translateX(-50%)' : '';
  }

  visualElement.setAttribute('data-master-scene-active', state.active ? 'true' : 'false');
  visualElement.setAttribute('data-master-role', state.role || 'inactive');
  setVar(visualElement, '--master-visual-opacity', state.visual.opacity.toFixed(4));
  setVar(visualElement, '--master-visual-y', `${state.visual.translateY.toFixed(2)}px`);
  setVar(visualElement, '--master-visual-scale', state.visual.scale.toFixed(4));
  setVar(visualElement, '--master-visual-blur', `${state.visual.blur.toFixed(2)}px`);

  copyRootElement.setAttribute('data-master-scene', sceneId);
  copyRootElement.setAttribute('data-master-copy-root', 'true');
  copyRootElement.setAttribute('data-master-scene-active', state.active ? 'true' : 'false');
  copyRootElement.setAttribute('data-master-role', state.role || 'inactive');
  copyRootElement.setAttribute('data-master-scene-readable', state.copy.readable ? 'true' : 'false');
  copyRootElement.setAttribute('data-master-scene-foreground', state.copy.foreground ? 'true' : 'false');
  setVar(copyRootElement, '--master-copy-opacity', state.copy.opacity.toFixed(4));
  setVar(copyRootElement, '--master-copy-y', `${state.copy.translateY.toFixed(2)}px`);
  setVar(copyRootElement, '--master-readable-progress', state.copy.progress.toFixed(4));
  for (const item of state.copy.stagger || []) {
    for (const staggerElement of copyRootElement.querySelectorAll(item.selector)) {
      staggerElement.style.setProperty('--master-stagger-progress', item.progress.toFixed(4));
    }
  }
};

function collectSurfaceStates({ registry, state }) {
  const surfaceStates = new Map();
  for (const [sceneId, entry] of registry.entries()) {
    const sceneState = state.scenes.get(sceneId) || state.inactiveSceneState;
    const surfaceKey = entry.scene.surfaceKey;
    const previous = surfaceStates.get(surfaceKey) || {
      active: false,
      opacity: 0,
      zIndex: 0,
      owners: []
    };
    surfaceStates.set(surfaceKey, {
      active: previous.active || sceneState.active,
      opacity: Math.max(previous.opacity, sceneState.visual.opacity),
      zIndex: Math.max(previous.zIndex, sceneState.visual.zIndex),
      owners: sceneState.active ? [...previous.owners, sceneId] : previous.owners
    });
  }
  return surfaceStates;
}

function applySurfaceStates({ registry, state }) {
  const surfaceStates = collectSurfaceStates({ registry, state });
  for (const [surfaceKey, surfaceEntry] of registry.surfaceEntries()) {
    const surfaceState = surfaceStates.get(surfaceKey) || {
      active: false,
      opacity: 0,
      zIndex: 0,
      owners: []
    };
    const owner = surfaceEntry.shared
      ? surfaceKey
      : (surfaceState.owners[0] || surfaceEntry.surface.ownerScene || '');
    surfaceEntry.element.setAttribute('data-master-surface-owner', owner);
    surfaceEntry.element.setAttribute('data-master-surface-active', surfaceState.active ? 'true' : 'false');
    surfaceEntry.element.style.setProperty('--master-surface-opacity', surfaceState.opacity.toFixed(4));
    surfaceEntry.element.style.setProperty('--master-surface-z', String(surfaceState.zIndex));
  }
}

export function createMasterScenePresenter({ root = document, model, registry }) {
  return Object.freeze({
    applyLayout(state) {
      for (const [sceneId, entry] of registry.entries()) {
        const sceneState = state.scenes.get(sceneId) || state.inactiveSceneState;
        applySceneState(entry, sceneId, sceneState);
      }
      applySurfaceStates({ registry, state });
    },
    applyVisibility(state) {
      for (const [sceneId, entry] of registry.entries()) {
        const sceneState = state.scenes.get(sceneId) || state.inactiveSceneState;
        applySceneState(entry, sceneId, sceneState);
      }
      applySurfaceStates({ registry, state });
      root.documentElement.dataset.masterTimelineSegment = state.segment?.id || '';
      root.documentElement.dataset.masterTimelineDirection = state.direction;
      root.documentElement.dataset.masterTimelineProgress = state.localProgress.toFixed(4);
    },
    clear() {
      for (const [, surfaceEntry] of registry.surfaceEntries()) {
        surfaceEntry.element.removeAttribute('data-master-surface-owner');
        surfaceEntry.element.removeAttribute('data-master-surface-active');
        surfaceEntry.element.removeAttribute('data-master-surface-ready');
        surfaceEntry.element.removeAttribute('data-master-surface-placeholder');
        surfaceEntry.element.style.removeProperty('--master-surface-opacity');
        surfaceEntry.element.style.removeProperty('--master-surface-z');
      }
      for (const [, entry] of registry.entries()) {
        for (const element of [entry.rootElement, entry.visualElement, entry.copyRootElement, entry.layoutAnchor]) {
          element?.removeAttribute('data-master-scene-active');
          element?.removeAttribute('data-master-scene-readable');
          element?.removeAttribute('data-master-scene-foreground');
          element?.removeAttribute('data-master-role');
          element?.style?.removeProperty('--master-scene-z');
          element?.style?.removeProperty('--master-visual-opacity');
          element?.style?.removeProperty('--master-visual-y');
          element?.style?.removeProperty('--master-visual-scale');
          element?.style?.removeProperty('--master-visual-blur');
          element?.style?.removeProperty('--master-copy-opacity');
          element?.style?.removeProperty('--master-copy-y');
          element?.style?.removeProperty('--master-readable-progress');
          for (const staggerElement of element?.querySelectorAll?.('[data-belief-upper-stagger]') || []) {
            staggerElement.style.removeProperty('--master-stagger-progress');
          }
          element?.style?.removeProperty('position');
          element?.style?.removeProperty('inset');
          element?.style?.removeProperty('top');
          element?.style?.removeProperty('left');
          element?.style?.removeProperty('right');
          element?.style?.removeProperty('bottom');
          element?.style?.removeProperty('height');
          element?.style?.removeProperty('width');
          element?.style?.removeProperty('max-width');
          element?.style?.removeProperty('transform');
        }
      }
    }
  });
}
