import { prepareSurface } from './master-surface-renderer.js';

export function createMasterSurfaceProducerRegistry({ model, registry }) {
  const producers = new Map();

  function mountSurfaceProducer(surfaceKey, producer) {
    const entry = registry.surfaceFor(surfaceKey);
    if (!entry) throw new Error(`Missing surface for producer: ${surfaceKey}`);
    if (typeof producer?.renderAt !== 'function') {
      throw new Error(`Surface producer ${surfaceKey} must expose renderAt(context)`);
    }
    producers.set(surfaceKey, {
      renderAt: producer.renderAt.bind(producer),
      renderIdle: typeof producer.renderIdle === 'function' ? producer.renderIdle.bind(producer) : () => {},
      destroy: typeof producer.destroy === 'function' ? producer.destroy.bind(producer) : () => {}
    });
  }

  function renderSurfaceProducers(state) {
    const requiredSurfaceKeys = new Set();
    if (state.segment?.transition?.type === 'ink') {
      requiredSurfaceKeys.add(state.segment.transition.ink.sourceSurfaceKey);
      requiredSurfaceKeys.add(state.segment.transition.ink.targetSurfaceKey);
    }
    for (const sceneState of state.scenes.values()) {
      if (sceneState.scene?.surfaceKey) requiredSurfaceKeys.add(sceneState.scene.surfaceKey);
    }
    for (const surface of model.surfaces || []) {
      if (surface.sameRectAs) requiredSurfaceKeys.add(surface.id);
    }
    for (const surfaceKey of requiredSurfaceKeys) {
      const entry = registry.surfaceFor(surfaceKey);
      const producer = producers.get(surfaceKey);
      const texture = prepareSurface(entry);
      if (producer) {
        producer.renderAt({
          surfaceKey,
          timelineProgress: model.totalVh ? state.scrollVh / model.totalVh : 0,
          blockProgress: state.blockProgress,
          localProgress: state.localProgress,
          sceneId: [...state.scenes.values()].find((sceneState) => (
            sceneState.scene?.surfaceKey === surfaceKey
          ))?.scene?.id || null,
          segmentId: state.segment?.id || null,
          state,
          texture,
          surfaceEntry: entry
        });
      }
    }
  }

  function assertAllProducersMounted() {
    const missing = [];
    for (const surface of model.surfaces || []) {
      if (!producers.has(surface.id)) missing.push(`${surface.id}:${surface.producer}`);
    }
    if (missing.length) {
      throw new Error(`Missing master surface producers: ${missing.join(', ')}`);
    }
  }

  return Object.freeze({
    mountSurfaceProducer,
    renderSurfaceProducers,
    assertAllProducersMounted,
    destroy() {
      for (const producer of producers.values()) producer.destroy();
      producers.clear();
    }
  });
}
