import { clearCanvasSurface, prepareSurface } from './master-surface-renderer.js';

function drawPaperSurface(surfaceEntry, {
  background = '#f7f2e8',
  ink = 'rgba(30, 32, 26, 0.10)',
  lineGap = 28
} = {}) {
  const canvas = prepareSurface(surfaceEntry);
  if (!(canvas instanceof HTMLCanvasElement)) return canvas;
  clearCanvasSurface(canvas);
  const context = canvas.getContext('2d');
  if (!context) return canvas;
  context.fillStyle = background;
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = ink;
  context.lineWidth = Math.max(1, Math.round((window.devicePixelRatio || 1) * 0.8));
  for (let y = lineGap; y < canvas.height; y += lineGap) {
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(canvas.width, y);
    context.stroke();
  }
  surfaceEntry.element.dataset.masterSurfaceReady = 'true';
  canvas.dataset.inkTextureReady = 'true';
  return canvas;
}

function createPaperProducer(context, options) {
  return {
    renderAt() {
      drawPaperSurface(context.surfaceEntry, options);
    },
    renderIdle() {},
    destroy() {}
  };
}

export const createMethodPaperSurfaceProducer = (context) => createPaperProducer(context, {
  background: '#f5efe3',
  ink: 'rgba(41, 38, 31, 0.12)'
});

export const createBrandPaperSurfaceProducer = (context) => createPaperProducer(context, {
  background: '#f3f0e8',
  ink: 'rgba(20, 27, 31, 0.10)'
});

export const createServicesPaperSurfaceProducer = (context) => createPaperProducer(context, {
  background: '#eef3f0',
  ink: 'rgba(22, 40, 34, 0.10)'
});

export const createPhilosophySurfaceProducer = (context) => createPaperProducer(context, {
  background: '#f1efe7',
  ink: 'rgba(35, 31, 27, 0.09)'
});

export const createContactPaperSurfaceProducer = (context) => createPaperProducer(context, {
  background: '#eef0ee',
  ink: 'rgba(22, 32, 28, 0.12)'
});
