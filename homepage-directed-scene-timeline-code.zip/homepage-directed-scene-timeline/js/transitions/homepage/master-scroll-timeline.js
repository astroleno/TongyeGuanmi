const clamp01 = (value) => {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
};

const interpolateCurve = (points, progress) => {
  const t = clamp01(progress);
  if (!Array.isArray(points) || !points.length) return 0;
  if (t <= points[0][0]) return points[0][1];
  for (let index = 1; index < points.length; index += 1) {
    const [rightX, rightY] = points[index];
    const [leftX, leftY] = points[index - 1];
    if (t <= rightX) {
      const local = clamp01((t - leftX) / Math.max(0.0001, rightX - leftX));
      const eased = local * local * (3 - 2 * local);
      return leftY + (rightY - leftY) * eased;
    }
  }
  return points[points.length - 1][1];
};

const resolvePresence = (presence, progress) => ({
  opacity: interpolateCurve(presence?.opacity || [[0, 1], [1, 1]], progress),
  y: interpolateCurve(presence?.y || [[0, 0], [1, 0]], progress),
  scale: interpolateCurve(presence?.scale || [[0, 1], [1, 1]], progress),
  blur: interpolateCurve(presence?.blur || [[0, 0], [1, 0]], progress)
});

const buildTimelineOffsets = (manifest) => {
  const segmentById = new Map((manifest.segments || []).map((segment) => [segment.id, segment]));
  let cursor = 0;
  const blocks = (manifest.scrollBlocks || []).map((block) => {
    const start = cursor;
    const segment = block.type === 'transition' ? segmentById.get(block.segment) : null;
    const length = Number(block.type === 'hold' ? block.scrollVh : segment?.scrollVh) || 1;
    cursor += length;
    const segmentWithOffsets = segment
      ? { ...segment, startVh: start, endVh: cursor, lengthVh: length }
      : null;
    return { ...block, segment: segmentWithOffsets, startVh: start, endVh: cursor, lengthVh: length };
  });
  const segments = (manifest.segments || []).map((segment) => {
    const block = blocks.find((item) => item.type === 'transition' && item.segment?.id === segment.id);
    if (!block) return { ...segment, startVh: 0, endVh: 0, lengthVh: Number(segment.scrollVh) || 1 };
    return { ...segment, startVh: block.startVh, endVh: block.endVh, lengthVh: block.lengthVh };
  });
  return { blocks, segments, totalVh: cursor };
};

const inactiveSceneState = Object.freeze({
  active: false,
  visual: {
    opacity: 0,
    translateY: 0,
    scale: 1,
    blur: 0,
    zIndex: 0
  },
  copy: {
    opacity: 0,
    translateY: 0,
    readable: false,
    foreground: false,
    progress: 0,
    stagger: []
  }
});

const resolveWindowProgress = (window, progress) => {
  if (!Array.isArray(window) || window.length !== 2) return 0;
  return clamp01((progress - window[0]) / Math.max(0.0001, window[1] - window[0]));
};

const resolveSourceCopy = (copyConfig, progress) => {
  const source = copyConfig?.source || {};
  const exitProgress = resolveWindowProgress(source.exit || [1, 1], progress);
  const opacity = 1 - exitProgress;
  return {
    opacity,
    translateY: -18 * exitProgress,
    readable: progress <= source.readableUntil && opacity > 0.04,
    foreground: progress <= source.foregroundUntil && opacity > 0.04,
    progress: 1 - exitProgress,
    stagger: []
  };
};

const resolveTargetCopy = (copyConfig, progress) => {
  const target = copyConfig?.target || { policy: 'none' };
  if (target.policy === 'none' || target.policy === 'settled-only') {
    return {
      opacity: 0,
      translateY: 18,
      readable: false,
      foreground: false,
      progress: 0,
      stagger: []
    };
  }
  const readableProgress = resolveWindowProgress(target.enter, progress);
  const stagger = (target.staggerItems || []).map((item) => ({
    selector: item.selector,
    progress: resolveWindowProgress(item.enter, progress)
  }));
  return {
    opacity: readableProgress,
    translateY: (1 - readableProgress) * 18,
    readable: progress >= target.readableAt && readableProgress > 0.04,
    foreground: progress >= target.foregroundAt && readableProgress > 0.04,
    progress: readableProgress,
    stagger
  };
};

const sceneStateFromPresence = ({ scene, role, presence, active, copy, zIndex }) => ({
  scene,
  role,
  active,
  visual: {
    opacity: presence.opacity,
    translateY: presence.y,
    scale: presence.scale,
    blur: presence.blur,
    zIndex
  },
  copy
});

const holdCopyStateForScene = (scene) => ({
  opacity: 1,
  translateY: 0,
  readable: true,
  foreground: true,
  progress: 1,
  stagger: scene?.copyStaggerSelector
    ? [{ selector: scene.copyStaggerSelector, progress: 1 }]
    : []
});

export function createMasterTimelineModel(manifest) {
  const { blocks, segments, totalVh } = buildTimelineOffsets(manifest);
  const sceneById = new Map((manifest.scenes || []).map((scene) => [scene.id, scene]));
  const firstScene = manifest.scenes?.[0] || null;
  const initialScenes = new Map();
  if (firstScene) {
    initialScenes.set(firstScene.id, {
      ...inactiveSceneState,
      scene: firstScene,
      role: 'idle',
      active: true,
      visual: { ...inactiveSceneState.visual, opacity: 1, zIndex: 1 },
      copy: holdCopyStateForScene(firstScene)
    });
  }
  const initialState = Object.freeze({
    direction: 'forward',
    scrollVh: 0,
    segment: null,
    localProgress: 0,
    scenes: initialScenes,
    inactiveSceneState
  });
  return Object.freeze({ ...manifest, blocks, segments, totalVh, sceneById, initialState, inactiveSceneState });
}

export function resolveMasterTimelineState(model, scrollVh, previousScrollVh = scrollVh) {
  const safeScrollVh = Math.max(0, Number(scrollVh) || 0);
  const direction = safeScrollVh >= previousScrollVh ? 'forward' : 'reverse';
  const lastBlock = model.blocks[model.blocks.length - 1];
  const block = model.blocks.find((candidate) => (
    safeScrollVh >= candidate.startVh &&
    (safeScrollVh < candidate.endVh || candidate === lastBlock)
  )) || lastBlock;
  const blockProgress = block
    ? clamp01((safeScrollVh - block.startVh) / block.lengthVh)
    : 0;
  const segment = block?.type === 'transition' ? block.segment : null;

  if (!segment) {
    const scene = block?.type === 'hold' ? model.sceneById.get(block.scene) : null;
    const scenes = new Map();
    if (scene) {
      scenes.set(scene.id, {
        ...model.inactiveSceneState,
        scene,
        role: 'hold',
        active: true,
        visual: { ...model.inactiveSceneState.visual, opacity: 1, zIndex: 2 },
        copy: holdCopyStateForScene(scene)
      });
    }
    return Object.freeze({
      direction,
      scrollVh: safeScrollVh,
      block,
      blockProgress,
      segment: null,
      localProgress: blockProgress,
      scenes,
      inactiveSceneState: model.inactiveSceneState
    });
  }

  const localProgress = clamp01((safeScrollVh - segment.startVh) / segment.lengthVh);
  const fromScene = model.sceneById.get(segment.from);
  const toScene = model.sceneById.get(segment.to);
  const scenes = new Map();

  const fromPresence = resolvePresence(segment.scenePresence?.from, localProgress);
  scenes.set(segment.from, sceneStateFromPresence({
    scene: fromScene,
    role: 'from',
    active: true,
    copy: resolveSourceCopy(segment.copy, localProgress),
    presence: fromPresence,
    zIndex: localProgress < segment.visualHandoffAt ? 2 : 1
  }));

  const toPresence = resolvePresence(segment.scenePresence?.to, localProgress);
  scenes.set(segment.to, sceneStateFromPresence({
    scene: toScene,
    role: 'to',
    active: true,
    copy: resolveTargetCopy(segment.copy, localProgress),
    presence: toPresence,
    zIndex: localProgress >= segment.visualHandoffAt ? 2 : 1
  }));

  return Object.freeze({
    direction,
    scrollVh: safeScrollVh,
    block,
    blockProgress,
    segment,
    localProgress,
    scenes,
    inactiveSceneState: model.inactiveSceneState
  });
}

export const masterScrollCoordinatesComeFrom = 'master-scroll-map';
