const imageCache = new Map();
const videoCache = new Map();

export const clamp01 = (value) => Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));

export function getImage(src) {
  if (!imageCache.has(src)) {
    const image = new Image();
    image.decoding = 'async';
    image.src = src;
    imageCache.set(src, image);
  }
  return imageCache.get(src);
}

export function getVideo(src) {
  if (!videoCache.has(src)) {
    const video = document.createElement('video');
    video.muted = true;
    video.preload = 'auto';
    video.playsInline = true;
    video.src = src;
    video.load?.();
    videoCache.set(src, video);
  }
  return videoCache.get(src);
}

export function seekVideo(video, progress) {
  if (!video) return false;
  const duration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
  if (duration > 0) {
    try {
      video.pause();
      video.currentTime = clamp01(progress) * duration;
    } catch {
      return video.readyState >= 2;
    }
  }
  return video.readyState >= 2;
}

export function drawCover(context, media, x, y, width, height) {
  const mediaWidth = media?.videoWidth || media?.naturalWidth || media?.width || 0;
  const mediaHeight = media?.videoHeight || media?.naturalHeight || media?.height || 0;
  if (!mediaWidth || !mediaHeight || width <= 0 || height <= 0) return false;
  const scale = Math.max(width / mediaWidth, height / mediaHeight);
  const drawWidth = mediaWidth * scale;
  const drawHeight = mediaHeight * scale;
  context.drawImage(media, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
  return true;
}

export function drawContain(context, media, x, y, width, height) {
  const mediaWidth = media?.videoWidth || media?.naturalWidth || media?.width || 0;
  const mediaHeight = media?.videoHeight || media?.naturalHeight || media?.height || 0;
  if (!mediaWidth || !mediaHeight || width <= 0 || height <= 0) return false;
  const scale = Math.min(width / mediaWidth, height / mediaHeight);
  const drawWidth = mediaWidth * scale;
  const drawHeight = mediaHeight * scale;
  context.drawImage(media, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
  return true;
}

export function imageReady(image) {
  return Boolean(image?.complete && image.naturalWidth);
}

export function mediaReady(media) {
  return imageReady(media) || media?.readyState >= 2;
}

export function markAssetSurfaceReady(surfaceEntry, canvas) {
  surfaceEntry.element.dataset.masterSurfaceReady = 'true';
  surfaceEntry.element.dataset.masterSurfaceSource = 'asset-composite';
  delete surfaceEntry.element.dataset.masterSurfacePlaceholder;
  canvas.dataset.inkTextureReady = 'true';
}
