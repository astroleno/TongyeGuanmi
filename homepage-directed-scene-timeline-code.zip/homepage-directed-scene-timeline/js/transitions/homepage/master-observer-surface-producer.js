export function createObserverSurfaceProducer({ surfaceEntry }) {
  return {
    renderAt() {
      if (!surfaceEntry?.element) return;
      surfaceEntry.element.dataset.masterSurfaceReady = 'true';
      surfaceEntry.element.dataset.masterSurfaceSource = 'real-flow-observer';
      delete surfaceEntry.element.dataset.masterSurfacePlaceholder;

      const texture = surfaceEntry.textureProvider?.();
      if (texture?.dataset) texture.dataset.inkTextureReady = 'true';
    },
    renderIdle() {},
    destroy() {}
  };
}
