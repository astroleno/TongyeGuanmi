import { createInkCurtainTransition } from '../../effects/ink-scene-transition.js';

const clamp01 = (value) => {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
};

const range01 = (value, start, end) => clamp01((value - start) / Math.max(0.0001, end - start));
const INK_WINDOW_END_EPSILON = 0.0001;

function markInkInactive(canvas) {
  canvas.dataset.masterInkActive = 'false';
  canvas.dataset.inkBridgeActive = 'false';
  canvas.dataset.inkSourceReady = '0';
  canvas.dataset.inkNextReady = '0';
}

export function createMasterInkCompositor({ canvas, registry }) {
  let activeTransition = null;
  let activeKey = '';

  function createTransition(segment) {
    const sourceTexture = registry.textureSourceForSurface(segment.transition.ink.sourceSurfaceKey);
    const targetTexture = registry.textureSourceForSurface(segment.transition.ink.targetSurfaceKey);
    const transition = createInkCurtainTransition(canvas, {
      variant: segment.transition.ink.variant,
      mode: segment.transition.ink.mode || 'scene-replacement',
      direction: segment.transition.ink.direction || 'bottom-up',
      sourceTexture,
      targetTexture,
      sourceSceneId: segment.from,
      targetSceneId: segment.to,
      sourceSurfaceKey: segment.transition.ink.sourceSurfaceKey,
      targetSurfaceKey: segment.transition.ink.targetSurfaceKey,
      deterministicTimeScale: 1.75,
      progressSpan: 1,
      fadeOutStart: 0.90,
      fadeOutEnd: 1
    });
    if (!transition) {
      canvas.dataset.masterInkUnavailable = 'true';
      return null;
    }
    canvas.removeAttribute('data-master-ink-unavailable');
    canvas.dataset.masterInkSource = segment.from;
    canvas.dataset.masterInkTarget = segment.to;
    canvas.dataset.masterInkSourceSurface = segment.transition.ink.sourceSurfaceKey;
    canvas.dataset.masterInkTargetSurface = segment.transition.ink.targetSurfaceKey;
    canvas.dataset.masterInkVariant = segment.transition.ink.variant;
    canvas.dataset.masterInkDirection = segment.transition.ink.direction || 'bottom-up';
    return transition;
  }

  function clearInactive() {
    activeTransition?.destroy?.();
    activeTransition = null;
    activeKey = '';
    markInkInactive(canvas);
    canvas.removeAttribute('data-master-ink-source');
    canvas.removeAttribute('data-master-ink-target');
    canvas.removeAttribute('data-master-ink-source-surface');
    canvas.removeAttribute('data-master-ink-target-surface');
    canvas.removeAttribute('data-master-ink-variant');
    canvas.removeAttribute('data-master-ink-direction');
    canvas.removeAttribute('data-master-ink-progress');
    canvas.removeAttribute('data-master-ink-segment');
    canvas.removeAttribute('data-master-ink-unavailable');
  }

  return Object.freeze({
    render(state) {
      const segment = state.segment;
      if (segment?.transition?.type !== 'ink') {
        clearInactive();
        return;
      }
      const key = `${segment.id}:${segment.from}->${segment.to}`;
      if (key !== activeKey) {
        clearInactive();
        activeTransition = createTransition(segment);
        activeKey = key;
      }
      const [start, end] = segment.transition.ink.window || [0, 1];
      const inkProgress = range01(state.localProgress, start, end);
      const inkEndBoundary = Math.max(start, end - INK_WINDOW_END_EPSILON);
      const insideInkWindow = state.localProgress >= start && state.localProgress < inkEndBoundary;
      if (!insideInkWindow) {
        activeTransition?.clear?.();
        markInkInactive(canvas);
        canvas.dataset.masterInkSegment = segment.id;
        canvas.dataset.masterInkProgress = inkProgress.toFixed(4);
        return;
      }
      if (!activeTransition?.render) {
        canvas.dataset.masterInkActive = 'false';
        canvas.dataset.masterInkUnavailable = 'true';
        return;
      }
      activeTransition.render(inkProgress, 0, 0, {
        deterministicTime: inkProgress * 1.75
      });
      canvas.dataset.masterInkActive = 'true';
      canvas.dataset.masterInkSegment = segment.id;
      canvas.dataset.masterInkProgress = inkProgress.toFixed(4);
    },
    clear: clearInactive,
    destroy: clearInactive
  });
}
