const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const TEXTURE_DPR_LIMIT = 1.12;

function resizeTextureCanvas(canvas, context) {
  const viewportWidth = Math.max(1, window.innerWidth || 1);
  const viewportHeight = Math.max(1, window.innerHeight || 1);
  const ratio = Math.min(window.devicePixelRatio || 1, TEXTURE_DPR_LIMIT);
  const nextWidth = Math.max(1, Math.round(viewportWidth * ratio));
  const nextHeight = Math.max(1, Math.round(viewportHeight * ratio));
  if (canvas.width !== nextWidth || canvas.height !== nextHeight) {
    canvas.width = nextWidth;
    canvas.height = nextHeight;
  }
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { viewportWidth, viewportHeight };
}

function wrapText(context, text, x, y, maxWidth, lineHeight, maxLines = 8) {
  const tokens = text.match(/[\u3400-\u9fff]|[^\s\u3400-\u9fff]+|\s+/g) || [];
  let line = '';
  let cursorY = y;
  let lines = 0;

  for (const token of tokens) {
    const candidate = `${line}${token}`;
    if (line && context.measureText(candidate).width > maxWidth) {
      context.fillText(line.trim(), x, cursorY);
      cursorY += lineHeight;
      lines += 1;
      line = token.trimStart();
      if (lines >= maxLines) return cursorY;
    } else {
      line = candidate;
    }
  }
  if (line.trim() && lines < maxLines) {
    context.fillText(line.trim(), x, cursorY);
    cursorY += lineHeight;
  }
  return cursorY;
}

function paintPaper(context, viewportWidth, viewportHeight, options) {
  const paper = context.createLinearGradient(0, 0, 0, viewportHeight);
  paper.addColorStop(0, options.topColor || '#fbf6eb');
  paper.addColorStop(0.58, options.midColor || '#efe4d2');
  paper.addColorStop(1, options.bottomColor || '#dccbb2');
  context.fillStyle = paper;
  context.fillRect(0, 0, viewportWidth, viewportHeight);
}

function drawNodeAtRect(context, node, viewportWidth, viewportHeight, options) {
  const rect = node.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return false;
  if (rect.bottom <= viewportHeight * 0.02 || rect.top >= viewportHeight * 0.98) return false;
  if (rect.right <= 0 || rect.left >= viewportWidth) return false;

  const computed = getComputedStyle(node);
  if (computed.display === 'none' || computed.visibility === 'hidden') return false;
  const text = (node.textContent || '').replace(/\s+/g, ' ').trim();
  if (!text) return false;

  const fontSize = parseFloat(computed.fontSize) || clamp(viewportWidth * 0.020, 20, 38);
  const parsedLineHeight = parseFloat(computed.lineHeight);
  const lineHeight = Number.isFinite(parsedLineHeight) ? parsedLineHeight : fontSize * 1.38;
  const nodeOpacity = options.ignoreOpacity === false ? Number(computed.opacity) : 1;
  const opacity = Number.isFinite(nodeOpacity) ? nodeOpacity : 1;
  if (opacity <= 0.001) return false;

  context.save();
  context.globalAlpha = opacity * (options.alpha ?? 0.90);
  context.fillStyle = node.matches('p')
    ? (options.bodyColor || 'rgba(68, 58, 42, 0.74)')
    : node.matches('.section-index, .eyebrow')
      ? (options.kickerColor || 'rgba(122, 102, 55, 0.78)')
      : (options.headingColor || 'rgba(42, 39, 29, 0.92)');
  context.font = computed.font || `${computed.fontWeight || 600} ${computed.fontSize || `${fontSize}px`} ${computed.fontFamily || 'serif'}`;
  context.textBaseline = 'top';
  const maxLines = Math.max(1, Math.ceil(rect.height / Math.max(1, lineHeight)) + 1);
  wrapText(context, text, rect.left, rect.top, rect.width, lineHeight, maxLines);
  context.restore();
  return true;
}

function drawLiveTextLayout(context, root, viewportWidth, viewportHeight, options) {
  if (!root?.querySelectorAll) return false;
  let drew = false;
  const selectors = options.textSelectors || ['.section-index', '.eyebrow', 'h2', 'p'];
  for (const node of root.querySelectorAll(selectors.join(','))) {
    drew = drawNodeAtRect(context, node, viewportWidth, viewportHeight, options) || drew;
  }
  return drew;
}

function drawBrandFallback(context, root, viewportWidth, viewportHeight, options) {
  const articles = [...(root?.querySelectorAll?.('article') || [])];
  if (!articles.length) return false;

  const columns = [
    { x: Math.max(96, viewportWidth * 0.13), y: viewportHeight * 0.26, width: Math.min(520, viewportWidth * 0.33) },
    { x: Math.max(viewportWidth * 0.52, 620), y: viewportHeight * 0.37, width: Math.min(560, viewportWidth * 0.36) }
  ];
  articles.slice(0, 2).forEach((article, index) => {
    const column = columns[index] || columns[0];
    const kicker = article.querySelector('.section-index')?.textContent?.trim() || '';
    const heading = article.querySelector('h2')?.textContent?.trim() || '';
    const body = article.querySelector('p')?.textContent?.trim() || '';
    let y = column.y;

    context.save();
    context.textBaseline = 'top';
    if (kicker) {
      context.fillStyle = options.kickerColor || 'rgba(122, 102, 55, 0.78)';
      context.font = '700 13px sans-serif';
      context.fillText(kicker, column.x, y);
      y += clamp(viewportHeight * 0.065, 42, 74);
    }
    if (heading) {
      const headingSize = clamp(viewportWidth * 0.036, 40, 68);
      context.fillStyle = options.headingColor || 'rgba(42, 39, 29, 0.92)';
      context.font = `600 ${headingSize.toFixed(1)}px serif`;
      y = wrapText(context, heading, column.x, y, column.width, headingSize * 1.12, 4);
      y += clamp(viewportHeight * 0.045, 30, 54);
    }
    if (body) {
      const bodySize = clamp(viewportWidth * 0.012, 16, 20);
      context.fillStyle = options.bodyColor || 'rgba(68, 58, 42, 0.74)';
      context.font = `400 ${bodySize.toFixed(1)}px sans-serif`;
      wrapText(context, body, column.x, y, column.width, bodySize * 1.78, 5);
    }
    context.restore();
  });
  return true;
}

function drawGenericFallback(context, root, viewportWidth, viewportHeight, options) {
  const text = (root?.textContent || '').replace(/\s+/g, ' ').trim();
  if (!text) return false;
  const maxWidth = Math.min(viewportWidth * 0.62, 900);
  const x = options.align === 'center' ? (viewportWidth - maxWidth) / 2 : viewportWidth * 0.16;
  const y = viewportHeight * 0.30;
  const fontSize = clamp(viewportWidth * 0.019, 22, 36);
  context.save();
  context.fillStyle = options.headingColor || 'rgba(42, 39, 29, 0.88)';
  context.font = `600 ${fontSize.toFixed(1)}px serif`;
  context.textBaseline = 'top';
  wrapText(context, text, x, y, maxWidth, fontSize * 1.64, 7);
  context.restore();
  return true;
}

export function createSceneTextCanvas(root, options = {}) {
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d', { alpha: true });
  if (!context) return null;
  let disposed = false;

  return {
    canvas,
    update() {
      if (disposed) return;
      const { viewportWidth, viewportHeight } = resizeTextureCanvas(canvas, context);
      context.clearRect(0, 0, viewportWidth, viewportHeight);
      paintPaper(context, viewportWidth, viewportHeight, options);

      const drewLiveText = drawLiveTextLayout(context, root, viewportWidth, viewportHeight, options);
      if (!drewLiveText && options.layout === 'brand-definition') {
        drawBrandFallback(context, root, viewportWidth, viewportHeight, options);
      } else if (!drewLiveText) {
        drawGenericFallback(context, root, viewportWidth, viewportHeight, options);
      }
      canvas.dataset.inkTextureReady = 'true';
    },
    destroy() {
      disposed = true;
      canvas.dataset.inkTextureReady = 'false';
    }
  };
}
