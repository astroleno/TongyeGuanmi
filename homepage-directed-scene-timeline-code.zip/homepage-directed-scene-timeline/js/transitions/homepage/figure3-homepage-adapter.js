import {
  prepareFigure3Transition,
  renderFigure3TransitionProgress,
  waitForFigure3TransitionMetadata
} from '../../components/figure3-transition.js';

export function mountHomepageTransition({ host, reduceMotion = false, progressSource, timeline, addCleanup }) {
  host.classList.add('homepage-transition', 'homepage-transition--figure3');
  host.innerHTML = `
    <section
      class="figure3-transition"
      data-figure3-transition
      data-figure3-duration="2"
      data-figure3-scroll-vh="20"
      aria-hidden="true"
    >
      <div class="figure3-transition__sticky">
        <div class="figure3-transition__backdrop" aria-hidden="true"></div>
        <div class="figure3-transition__stage" aria-hidden="true">
          <video class="figure3-transition__video" data-figure3-alpha-video src="assets/figure3-alpha-scrub.webm?v=1280-q40" poster="assets/figure3-alpha-poster.png" muted preload="auto" playsinline webkit-playsinline></video>
          <div class="figure3-transition__fill" data-figure3-fill aria-hidden="true"></div>
          <div class="figure3-transition__visual-bridge" data-transition-ghost="figure3-fabric" aria-hidden="true"></div>
        </div>
      </div>
    </section>
  `;

  const section = host.querySelector('[data-figure3-transition]');
  const { alphaVideo } = prepareFigure3Transition(section, { progress: reduceMotion ? 1 : 0 });
  let raf = 0;
  let destroyed = false;

  const render = () => {
    if (destroyed) return;
    const progress = reduceMotion ? 1 : progressSource();
    renderFigure3TransitionProgress(section, progress);
    const servicesJoinProgress = progress;
    timeline?.updateJoin('brand-services', servicesJoinProgress, {
      reason: 'figure3-render',
      milestones: {
        servicesCopyReadable: servicesJoinProgress >= 0.72,
        playbackComplete: servicesJoinProgress >= 0.998
      }
    });
    const hasTimelineOwnership = typeof timeline?.getOwnership === 'function';
    const ownership = timeline?.getOwnership('brand-services');
    const state = timeline?.getState('brand-services');
    const figure3OwnsCanvas = !ownership?.enforced || ownership?.canvasOwner === 'figure3';
    const figure3OwnsMask = !ownership?.enforced || ownership?.maskOwner === 'figure3-transition';
    const figure3OwnsLayer = !ownership?.enforced || ownership?.layerOwner === 'figure3-transition';
    const servicesCanForeground = !ownership?.enforced || ownership?.foregroundCopyOwner === 'services';
    const released = state?.released || (!hasTimelineOwnership && host.dataset.handoffComplete === 'true');
    const figure3Visible = !released && (figure3OwnsCanvas || figure3OwnsMask || figure3OwnsLayer);
    section.style.opacity = figure3Visible ? '1' : '0';
    section.style.visibility = figure3Visible ? 'visible' : 'hidden';
    section.style.pointerEvents = figure3OwnsLayer ? '' : 'none';
    section.dataset.servicesForegroundBlocked = servicesCanForeground ? 'false' : 'true';
    raf = requestAnimationFrame(render);
  };

  if (reduceMotion) {
    waitForFigure3TransitionMetadata(section).then(() => {
      if (!destroyed) {
        renderFigure3TransitionProgress(section, 1);
        timeline?.updateJoin('brand-services', 1, {
          reason: 'figure3-reduced-motion',
          milestones: {
            servicesCopyReadable: true,
            playbackComplete: true
          }
        });
      }
    });
  } else {
    render();
  }

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    cancelAnimationFrame(raf);
    alphaVideo?.pause?.();
    host.replaceChildren();
    host.classList.remove('homepage-transition', 'homepage-transition--figure3');
  };

  addCleanup?.(destroy);
  return { destroy };
}
