const clamp01 = (value) => {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
};

export function createMasterScrollMap({ root = document, model, getViewportHeight = () => window.innerHeight }) {
  const track = root.querySelector(model.track.selector);
  const stage = root.querySelector(model.track.stickySelector);
  if (!track) throw new Error(`Missing master track: ${model.track.selector}`);
  if (!stage) throw new Error(`Missing master stage: ${model.track.stickySelector}`);

  const state = {
    track,
    stage,
    startY: 0,
    scrollablePx: 1,
    totalVh: model.totalVh,
    refreshRaf: 0
  };

  function shouldUseDocumentScroll() {
    return root.documentElement?.dataset.masterDomMode === 'master-visible';
  }

  function refresh() {
    const viewportHeight = Math.max(1, Number(getViewportHeight()) || 1);
    track.style.setProperty(model.track.heightCssVariable, String(model.totalVh));
    if (shouldUseDocumentScroll()) {
      const documentElement = root.documentElement || document.documentElement;
      state.startY = 0;
      state.scrollablePx = Math.max(1, documentElement.scrollHeight - viewportHeight);
      return { ...state, viewportHeight };
    }
    const rect = track.getBoundingClientRect();
    state.startY = rect.top + window.scrollY;
    state.scrollablePx = Math.max(1, rect.height - viewportHeight);
    return { ...state, viewportHeight };
  }

  function positionForScrollY(scrollY = window.scrollY) {
    const offsetPx = Number(scrollY) - state.startY;
    return clamp01(offsetPx / state.scrollablePx) * state.totalVh;
  }

  function scrollYForTimelineVh(timelineVh = 0) {
    const progress = state.totalVh
      ? clamp01((Number(timelineVh) || 0) / state.totalVh)
      : 0;
    return Math.max(0, state.startY + progress * state.scrollablePx);
  }

  function scheduleRefresh() {
    if (state.refreshRaf) return;
    state.refreshRaf = requestAnimationFrame(() => {
      state.refreshRaf = 0;
      refresh();
    });
  }

  const resizeObserver = typeof ResizeObserver === 'function'
    ? new ResizeObserver(scheduleRefresh)
    : null;
  const mutationObserver = typeof MutationObserver === 'function'
    ? new MutationObserver(scheduleRefresh)
    : null;
  const onFontLoadingDone = () => scheduleRefresh();
  resizeObserver?.observe(track);
  resizeObserver?.observe(stage);
  mutationObserver?.observe(track, {
    attributes: true,
    childList: true,
    subtree: true,
    attributeFilter: ['class', 'style', 'hidden', 'data-master-scene-active']
  });
  window.addEventListener('resize', scheduleRefresh, { passive: true });
  window.visualViewport?.addEventListener('resize', scheduleRefresh, { passive: true });
  root.fonts?.ready?.then?.(scheduleRefresh);
  root.fonts?.addEventListener?.('loadingdone', onFontLoadingDone);
  for (const media of root.querySelectorAll('img,video')) {
    media.addEventListener('load', scheduleRefresh, { passive: true });
    media.addEventListener('loadedmetadata', scheduleRefresh, { passive: true });
  }

  refresh();

  return Object.freeze({
    track,
    stage,
    refresh,
    positionForScrollY,
    scrollYForTimelineVh,
    destroy() {
      if (state.refreshRaf) cancelAnimationFrame(state.refreshRaf);
      resizeObserver?.disconnect();
      mutationObserver?.disconnect();
      window.removeEventListener('resize', scheduleRefresh);
      window.visualViewport?.removeEventListener('resize', scheduleRefresh);
      root.fonts?.removeEventListener?.('loadingdone', onFontLoadingDone);
      for (const media of root.querySelectorAll('img,video')) {
        media.removeEventListener('load', scheduleRefresh);
        media.removeEventListener('loadedmetadata', scheduleRefresh);
      }
    }
  });
}
