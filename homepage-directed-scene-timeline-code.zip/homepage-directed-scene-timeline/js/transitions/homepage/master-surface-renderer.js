export function resizeCanvasToElement(canvas, element = canvas) {
  if (!(canvas instanceof HTMLCanvasElement)) return;
  const rect = element.getBoundingClientRect();
  const dpr = Math.max(1, window.devicePixelRatio || 1);
  const width = Math.max(1, Math.round(rect.width * dpr));
  const height = Math.max(1, Math.round(rect.height * dpr));
  if (canvas.width !== width) canvas.width = width;
  if (canvas.height !== height) canvas.height = height;
}

export function clearCanvasSurface(canvas) {
  if (!(canvas instanceof HTMLCanvasElement)) return;
  const context = canvas.getContext('2d');
  context?.clearRect(0, 0, canvas.width, canvas.height);
}

export function prepareSurface(entry) {
  const texture = entry.textureProvider();
  if (texture instanceof HTMLCanvasElement) {
    resizeCanvasToElement(texture, entry.element);
  }
  return texture;
}
