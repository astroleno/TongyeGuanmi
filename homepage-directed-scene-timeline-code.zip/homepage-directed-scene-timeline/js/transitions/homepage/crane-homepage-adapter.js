import { createCraneTransitionScene } from '../../components/crane-transition.js';

const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const range01 = (value, start, end) => clamp((value - start) / Math.max(0.001, end - start));
const smoothStep = (value) => {
  const p = clamp(value);
  return p * p * (3 - 2 * p);
};

export function mountHomepageTransition({
  host,
  reduceMotion = false,
  progressSource,
  handoffTarget,
  handoffProgressSource,
  timeline,
  addCleanup
}) {
  host.classList.add('homepage-transition', 'homepage-transition--crane', 'crane-page');
  host.innerHTML = `
    <section class="crane-scroll" data-crane-stage aria-hidden="true">
      <div class="crane-sticky">
        <div class="crane-field">
          <div class="crane-paper" aria-hidden="true"></div>
          <div class="crane-layer-stack" data-transition-ghost="crane-motion" aria-hidden="true">
            <img class="crane-layer crane-layer--cloud-back" src="assets/crane1_cloud2-alpha.png" alt="" />
            <div class="crane-video-transition crane-video-transition--figure">
              <video class="crane-figure-video" data-crane-figure-video muted preload="auto" playsinline webkit-playsinline>
                <source src="assets/crane-figure1-transition.webm" type="video/webm" />
              </video>
            </div>
            <img class="crane-layer crane-layer--arch" src="assets/crane1_arch-alpha.png" alt="" />
            <img class="crane-layer crane-layer--cloud-front" src="assets/crane1_cloud1-alpha.png" alt="" />
            <img class="crane-layer crane-layer--cloud-front-second" src="assets/crane1_cloud-front2-alpha.png" alt="" />
            <div class="crane-video-transition crane-video-transition--front">
              <video class="crane-figure-video crane-figure-video--front" data-crane-figure-front-video muted preload="auto" playsinline webkit-playsinline>
                <source src="assets/crane-figure2-transition.webm" type="video/webm" />
              </video>
            </div>
          </div>
          <div class="crane-warmth" aria-hidden="true"></div>
          <div class="crane-center-wash" aria-hidden="true"></div>
          <div class="crane-texture" aria-hidden="true"></div>
          <div class="crane-progress" aria-hidden="true"><span></span></div>
        </div>
      </div>
    </section>
  `;

  const stage = host.querySelector('[data-crane-stage]');
  const scene = createCraneTransitionScene(stage);
  if (!scene) throw new Error('Crane homepage transition could not initialize.');

  let raf = 0;
  let destroyed = false;

  const render = () => {
    if (destroyed) return;
    const progress = reduceMotion ? 1 : progressSource();
    const contactCopyProgress = smoothStep(range01(progress, 0.58, 0.88));
    scene.renderRawProgress(progress);
    timeline?.updateJoin('philosophy-contact', progress, {
      reason: 'crane-render',
      milestones: {
        craneVisualClear: progress >= 0.56,
        contactCopyReady: contactCopyProgress > 0.04,
        contactCopyReadable: contactCopyProgress >= 0.82,
        playbackComplete: progress >= 0.998
      }
    });
    const hasTimelineOwnership = typeof timeline?.getOwnership === 'function';
    const ownership = timeline?.getOwnership('philosophy-contact');
    const state = timeline?.getState('philosophy-contact');
    const craneOwnsCanvas = !ownership?.enforced || ownership?.canvasOwner === 'crane';
    const craneOwnsMask = !ownership?.enforced || ownership?.maskOwner === 'crane-transition';
    const craneOwnsLayer = !ownership?.enforced || ownership?.layerOwner === 'crane-transition';
    const contactCanForeground = !ownership?.enforced || ownership?.foregroundCopyOwner === 'contact';
    const released = state?.released || (!hasTimelineOwnership && host.dataset.handoffComplete === 'true');
    const craneVisible = !released && (craneOwnsCanvas || craneOwnsMask || craneOwnsLayer);
    stage.style.opacity = craneVisible ? '1' : '0';
    stage.style.visibility = craneVisible ? 'visible' : 'hidden';
    stage.style.pointerEvents = craneOwnsLayer ? '' : 'none';
    stage.dataset.contactForegroundBlocked = contactCanForeground ? 'false' : 'true';
    raf = requestAnimationFrame(render);
  };

  scene.prepare();
  if (reduceMotion) {
    scene.mountReducedMotion();
    timeline?.updateJoin('philosophy-contact', 1, {
      reason: 'crane-reduced-motion',
      milestones: {
        craneVisualClear: true,
        contactCopyReady: true,
        contactCopyReadable: true,
        playbackComplete: true
      }
    });
  } else {
    scene.waitForVideos().finally(render);
  }

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    cancelAnimationFrame(raf);
    scene.destroy();
    host.replaceChildren();
    host.classList.remove('homepage-transition', 'homepage-transition--crane', 'crane-page');
  };

  addCleanup?.(destroy);
  return { destroy };
}
