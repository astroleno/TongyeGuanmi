const isTextureSource = (element) => (
  element instanceof HTMLCanvasElement ||
  element instanceof HTMLVideoElement ||
  element instanceof HTMLImageElement ||
  (typeof ImageBitmap !== 'undefined' && element instanceof ImageBitmap) ||
  (typeof OffscreenCanvas !== 'undefined' && element instanceof OffscreenCanvas) ||
  (typeof VideoFrame !== 'undefined' && element instanceof VideoFrame)
);

const queryRequired = (root, selector, label) => {
  const element = root.querySelector(selector);
  if (!element) throw new Error(`Missing ${label}: ${selector}`);
  return element;
};

const findTextureSource = (element) => {
  if (isTextureSource(element)) return element;
  return element?.querySelector?.('canvas,video,img') || null;
};

const ensureGeneratedCanvas = (element, surface) => {
  const canvas = document.createElement('canvas');
  canvas.dataset.masterGeneratedSurface = surface.id;
  canvas.dataset.masterSurface = surface.id;
  canvas.width = 1;
  canvas.height = 1;
  element.append(canvas);
  return canvas;
};

export function createMasterSceneRegistry({ root = document, model }) {
  const scenes = new Map();
  const surfaces = new Map();

  for (const surface of model.surfaces || []) {
    const element = queryRequired(root, surface.selector, `${surface.id} surface`);
    let generatedCanvas = null;
    const textureProvider = () => {
      const textureSource = findTextureSource(element);
      if (!isTextureSource(textureSource) && surface.allowGeneratedCanvas) {
        generatedCanvas ||= ensureGeneratedCanvas(element, surface);
        return generatedCanvas;
      }
      if (!isTextureSource(textureSource)) {
        throw new Error(`${surface.id} surface must provide canvas, video, image, or ImageBitmap texture source`);
      }
      return textureSource;
    };
    surfaces.set(surface.id, {
      surface,
      element,
      textureProvider,
      producer: surface.producer,
      shared: Boolean(surface.shared)
    });
  }

  for (const scene of model.scenes || []) {
    const rootElement = queryRequired(root, scene.rootSelector, `${scene.id} root`);
    const visualElement = queryRequired(root, scene.visualSelector, `${scene.id} visual`);
    const copyRootElement = queryRequired(root, scene.copySelector, `${scene.id} copy`);
    const layoutAnchor = queryRequired(root, scene.layoutAnchorSelector, `${scene.id} layout anchor`);
    const surfaceEntry = surfaces.get(scene.surfaceKey);
    if (!surfaceEntry) throw new Error(`${scene.id} references missing surface ${scene.surfaceKey}`);
    scenes.set(scene.id, {
      scene,
      rootElement,
      visualElement,
      copyRootElement,
      layoutAnchor,
      surfaceEntry
    });
  }

  return Object.freeze({
    get(sceneId) {
      return scenes.get(sceneId) || null;
    },
    textureSourceForScene(sceneId) {
      return scenes.get(sceneId)?.surfaceEntry?.textureProvider() || null;
    },
    textureSourceForSurface(surfaceKey) {
      return surfaces.get(surfaceKey)?.textureProvider() || null;
    },
    entries() {
      return scenes.entries();
    },
    surfaceEntries() {
      return surfaces.entries();
    },
    surfaceFor(surfaceKey) {
      return surfaces.get(surfaceKey) || null;
    }
  });
}
