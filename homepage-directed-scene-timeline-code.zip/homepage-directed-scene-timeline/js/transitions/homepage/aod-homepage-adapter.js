import {
  prepareAodTransition,
  renderAodTransitionProgress,
  waitForAodTransitionMetadata
} from '../../components/aod-transition.js';
import { createInkCurtainTransition } from '../../effects/ink-scene-transition.js';

const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const smoothStep = (value) => value * value * (3 - 2 * value);
const range01 = (value, start, end) => clamp((value - start) / Math.max(0.001, end - start));

export function mountHomepageTransition({
  host,
  reduceMotion = false,
  progressSource,
  handoffTarget,
  handoffProgressSource,
  timeline,
  addCleanup
}) {
  host.classList.add('homepage-transition', 'homepage-transition--aod');
  host.innerHTML = `
    <section
      class="aod-transition"
      data-aod-transition
      data-aod-duration="2"
      data-aod-scroll-vh="20"
      data-aod-video-duration="5.03"
      data-aod-fullscreen-start="0"
      data-aod-fullscreen-end="0.85"
      data-aod-backdrop-exit-start="0.18"
      data-aod-backdrop-exit-end="1.55"
      data-aod-figure-start-scale="1"
      data-aod-figure-start-y-vh="10.5"
      aria-hidden="true"
    >
      <div class="aod-transition__sticky">
        <div class="aod-transition__field">
          <div class="aod-transition__layer-stack" data-transition-ghost="aod-field" aria-hidden="true">
            <img class="aod-transition__layer aod-transition__layer--cloud" data-aod-cloud-layer src="assets/aod_cloud-alpha.png" alt="" />
            <img class="aod-transition__layer aod-transition__layer--sun" data-aod-sun-layer src="assets/aod_sun-alpha.png" alt="" />
          </div>
          <video class="aod-transition__figure-video" data-aod-figure-video src="assets/aod_figure-alpha-front-scrub.webm" muted preload="auto" playsinline webkit-playsinline></video>
          <div class="aod-transition__paper-solid" aria-hidden="true"></div>
          <canvas class="aod-transition__ink" data-aod-ink-canvas aria-hidden="true"></canvas>
          <div class="aod-transition__progress" aria-hidden="true"><span></span></div>
        </div>
      </div>
    </section>
  `;

  const section = host.querySelector('[data-aod-transition]');
  const { figureVideo } = prepareAodTransition(section, { progress: reduceMotion ? 1 : 0 });
  const inkCanvas = host.querySelector('[data-aod-ink-canvas]');
  const field = host.querySelector('.aod-transition__field');
  const inkTransition = reduceMotion ? null : createInkCurtainTransition(inkCanvas, {
    direction: 'bottom-up',
    colorLift: 0.64,
    coverAlpha: 0.64,
    fadeOutStart: 0.82,
    fadeOutEnd: 1,
    progressSpan: 1
  });
  const nav = document.querySelector('.site-nav');
  let raf = 0;
  let destroyed = false;
  let isForcingLightNav = false;

  const syncNavTone = (progress) => {
    if (!nav) return;

    const shouldUseLightNav = progress > 0.12;
    if (shouldUseLightNav) {
      if (isForcingLightNav) return;

      isForcingLightNav = true;
      nav.dataset.tone = 'light';
      nav.classList.add('is-on-light');
      return;
    }

    if (!isForcingLightNav) return;

    isForcingLightNav = false;
    nav.removeAttribute('data-tone');
    nav.classList.remove('is-on-light');
  };

  const render = () => {
    if (destroyed) return;
    const progress = reduceMotion ? 1 : progressSource();
    const inkProgress = smoothStep(range01(progress, 0.08, 0.92));
    const methodCopyProgress = smoothStep(range01(progress, 0.48, 0.82));
    syncNavTone(progress);
    renderAodTransitionProgress(section, progress, {
      accelerate: false,
      progressCurve: 'linear'
    });
    timeline?.updateJoin('belief-method', progress, {
      reason: 'aod-render',
      milestones: {
        aodInkReadable: inkProgress > 0.12 && inkProgress < 0.96,
        methodCopyReady: methodCopyProgress > 0.03,
        methodCopyReadable: methodCopyProgress >= 0.72,
        playbackComplete: progress >= 0.998
      }
    });
    const hasTimelineOwnership = typeof timeline?.getOwnership === 'function';
    const ownership = timeline?.getOwnership('belief-method');
    const aodOwnsCanvas = !ownership?.enforced || ownership?.canvasOwner === 'aod-transition';
    const aodOwnsMask = !ownership?.enforced || ownership?.maskOwner === 'aod-ink';
    const aodOwnsLayer = !ownership?.enforced || ownership?.layerOwner === 'aod-transition';
    const methodCanForeground = !ownership?.enforced || ownership?.foregroundCopyOwner === 'method';
    const released = !hasTimelineOwnership && host.dataset.handoffComplete === 'true';
    const aodVisible = !released && (aodOwnsCanvas || aodOwnsMask || aodOwnsLayer);
    section.style.opacity = aodVisible ? '1' : '0';
    section.style.visibility = aodVisible ? 'visible' : 'hidden';
    field?.style?.setProperty('opacity', aodOwnsCanvas ? '1' : '0');
    inkTransition?.render(aodOwnsMask ? inkProgress : 0);
    if (!aodOwnsMask && inkCanvas) {
      inkCanvas.style.opacity = '0';
      inkCanvas.style.visibility = 'hidden';
    }
    if (!aodOwnsLayer) section.style.pointerEvents = 'none';
    else section.style.removeProperty('pointer-events');
    if (!methodCanForeground) section.dataset.methodForegroundBlocked = 'true';
    else delete section.dataset.methodForegroundBlocked;
    raf = requestAnimationFrame(render);
  };

  if (reduceMotion) {
    waitForAodTransitionMetadata(section).then(() => {
      if (!destroyed) {
        syncNavTone(1);
        renderAodTransitionProgress(section, 1, {
          accelerate: false,
          progressCurve: 'linear'
        });
        timeline?.updateJoin('belief-method', 1, {
          reason: 'aod-reduced-motion',
          milestones: {
            aodInkReadable: false,
            methodCopyReady: true,
            methodCopyReadable: true,
            playbackComplete: true
          }
        });
        inkTransition?.render(1);
      }
    });
  } else {
    render();
  }

  const destroy = () => {
    if (destroyed) return;
    destroyed = true;
    cancelAnimationFrame(raf);
    figureVideo?.pause?.();
    host.replaceChildren();
    host.classList.remove('homepage-transition', 'homepage-transition--aod');
  };

  addCleanup?.(destroy);
  return { destroy };
}
