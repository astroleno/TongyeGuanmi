import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relativePath) => readFileSync(path.join(root, relativePath), 'utf8');
const manifestUrl = pathToFileURL(path.join(root, 'src/section-manifest.mjs')).href;
const { homepageMasterTimeline } = await import(`${manifestUrl}?contract=${Date.now()}`);

assert.ok(homepageMasterTimeline, 'homepage master timeline must exist');

const scenes = new Map(homepageMasterTimeline.scenes.map((scene) => [scene.id, scene]));
const surfaces = new Map(homepageMasterTimeline.surfaces.map((surface) => [surface.id, surface]));
const segments = new Map(homepageMasterTimeline.segments.map((segment) => [segment.id, segment]));

for (const id of ['home', 'belief.upper', 'belief.lower', 'method', 'method.proof', 'brand', 'services', 'lab', 'education', 'philosophy', 'contact']) {
  assert.ok(scenes.has(id), `${id} scene must exist`);
}

assert.equal(scenes.get('belief.upper')?.viewportAnchor?.align, 'right', 'belief.upper must keep the right-side anchor');
assert.equal(scenes.get('method')?.viewportAnchor?.topVh, 18, 'method copy must keep the audited top anchor');
assert.equal(scenes.get('method.proof')?.surfaceKey, 'figure2.bridge', 'method.proof must use the Figure2 canonical surface');

for (const surface of homepageMasterTimeline.surfaces) {
  assert.ok(surface.producer, `${surface.id} must have a surface producer`);
  if (surface.sameRectAs) {
    assert.ok(surfaces.has(surface.sameRectAs), `${surface.id} must align to a declared reference surface`);
  }
}

for (const id of ['home-to-belief-upper', 'belief-upper-to-belief-lower', 'belief-lower-to-method', 'method-proof-to-brand', 'brand-to-services', 'philosophy-to-contact']) {
  const segment = segments.get(id);
  assert.equal(segment?.transition?.type, 'ink', `${id} must use master ink`);
  assert.ok(segment.transition.ink.sourceSurfaceKey, `${id} must declare an ink source surface`);
  assert.ok(segment.transition.ink.targetSurfaceKey, `${id} must declare an ink target surface`);
  assert.ok(Array.isArray(segment.transition.ink.window), `${id} must declare an ink activity window`);
}

assert.equal(segments.get('method-proof-to-brand')?.from, 'method.proof', 'Figure2 bridge must start from method.proof');
assert.equal(segments.get('method-proof-to-brand')?.to, 'brand', 'Figure2 bridge must target brand');
assert.equal(segments.get('belief-upper-to-belief-lower')?.transition?.ink?.direction, 'bottom-up', 'Belief upper/lower ink must be bottom-up');
assert.equal(segments.get('belief-lower-to-method')?.copy?.target?.policy, 'overlap', 'Method copy must overlap the AOD bridge');
assert.equal(segments.get('philosophy-to-contact')?.copy?.target?.policy, 'overlap', 'Contact copy must overlap the Crane bridge');

const html = read('index.html');
for (const text of [
  '你的同行不是更聪明，只是更早把 AI 用进了生意里。',
  '让 AI 从一场培训，变成账上的数字。'
]) {
  assert.ok(html.includes(text), `master-visible build must contain copy: ${text}`);
}

const adapterBundle = [
  'js/transitions/pattern-bloom-adapter.js',
  'js/transitions/homepage/aod-homepage-adapter.js',
  'js/transitions/homepage/figure2-homepage-adapter.js',
  'js/transitions/homepage/figure3-homepage-adapter.js',
  'js/transitions/homepage/crane-homepage-adapter.js',
  'js/transitions/homepage/ttg-homepage-adapter.js',
  'js/transitions/homepage/ph-homepage-adapter.js'
].map(read).join('\n');

assert.match(adapterBundle, /createPatternBloomScene/, 'Pattern Bloom must keep the real animation scene');
assert.match(adapterBundle, /aod_figure-alpha-front-scrub\.webm/, 'AOD must keep its real video asset');
assert.match(adapterBundle, /createTtgTransitionScene/, 'TTG must keep its real transition scene');
assert.match(adapterBundle, /renderPhTransitionProgress/, 'PH must keep its real transition renderer');
assert.doesNotMatch(adapterBundle, /create[A-Za-z]+SurfaceProducer|draw(Ttg|Ph|Aod|Figure2|Figure3|Crane)/, 'visible adapters must not provide placeholder master visuals');

console.log('Homepage master visual timeline contract passed.');
