import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relativePath) => readFileSync(path.join(rootDir, relativePath), 'utf8');
const manifestUrl = pathToFileURL(path.join(rootDir, 'src/section-manifest.mjs')).href;
const { homepageMasterTimeline } = await import(`${manifestUrl}?integration=${Date.now()}`);

const indexHtml = read('index.html');
const registrySource = read('js/transitions/homepage-transition-registry.js');
const runtimeSource = read('js/transitions/homepage-transition-runtime.js');
const continuityCss = read('css/components/homepage-continuity.css');

const adapterPaths = {
  'pattern-bloom': 'js/transitions/pattern-bloom-adapter.js',
  aod: 'js/transitions/homepage/aod-homepage-adapter.js',
  figure2: 'js/transitions/homepage/figure2-homepage-adapter.js',
  'figure3-transition': 'js/transitions/homepage/figure3-homepage-adapter.js',
  crane: 'js/transitions/homepage/crane-homepage-adapter.js',
  ttg: 'js/transitions/homepage/ttg-homepage-adapter.js',
  ph: 'js/transitions/homepage/ph-homepage-adapter.js'
};

function parseAttributes(tag) {
  const attrs = new Map();
  const attrPattern = /\s([A-Za-z0-9:_-]+)(?:="([^"]*)")?/g;
  for (const match of tag.matchAll(attrPattern)) {
    attrs.set(match[1], match[2] ?? '');
  }
  return attrs;
}

function assertExists(relativePath, message) {
  assert.ok(existsSync(path.join(rootDir, relativePath)), message);
}

for (const pathName of Object.values(adapterPaths)) {
  assertExists(pathName, `${pathName} must exist`);
}

assert.match(indexHtml, /data-master-timeline-enabled="true"/, 'generated page must enable the master timeline');
assert.match(indexHtml, /data-master-dom-mode="master-visible"/, 'generated page must use master-visible DOM');
assert.doesNotMatch(indexHtml, /data-homepage-master-track[^>]*(hidden|inert)/, 'master track must not be hidden or inert');

const transitionHosts = [...indexHtml.matchAll(/<div\b[^>]*>/g)]
  .map((match) => ({ tag: match[0], attrs: parseAttributes(match[0]) }))
  .filter((node) => {
    const classes = (node.attrs.get('class') || '').split(/\s+/);
    return classes.includes('chapter-transition') || classes.includes('scene-transition');
  });
const transitionById = new Map(transitionHosts.map((host) => [host.attrs.get('data-transition-id'), host]));

for (const [moduleName, adapterPath] of Object.entries(adapterPaths)) {
  assert.ok(registrySource.includes(moduleName), `registry must include ${moduleName}`);
  const source = read(adapterPath);
  assert.match(source, /mountHomepageTransition|mountPatternBloomTransition/, `${moduleName} adapter must mount the real visible transition`);
  assert.match(source, /return \{ destroy \}|destroy\(\)/, `${moduleName} adapter must expose cleanup`);
  assert.doesNotMatch(source, /create[A-Za-z]+SurfaceProducer|draw(Ttg|Ph|Aod|Figure2|Figure3|Crane)/, `${moduleName} adapter must not provide placeholder master visuals`);
}

const expectedHostModules = new Map([
  ['home-belief', 'pattern-bloom'],
  ['belief-method', 'aod'],
  ['method-tooling__method-proof', 'figure2'],
  ['brand-services', 'figure3-transition'],
  ['services-lab', 'ttg'],
  ['lab-education', 'ph'],
  ['education-philosophy', 'soft-breath'],
  ['philosophy-contact', 'crane']
]);

for (const [transitionId, moduleName] of expectedHostModules) {
  assert.equal(
    transitionById.get(transitionId)?.attrs.get('data-transition-module'),
    moduleName,
    `${transitionId} must keep transition module ${moduleName}`
  );
}

const segmentExpectations = new Map([
  ['home-to-belief-upper', { adapter: 'pattern-bloom', host: '[data-transition-id="home-belief"]' }],
  ['belief-upper-to-belief-lower', { adapter: 'pattern-bloom', host: '[data-transition-id="home-belief"]' }],
  ['belief-lower-to-method', { adapter: 'aod', host: '[data-transition-id="belief-method"]' }],
  ['method-proof-to-brand', { adapter: 'figure2', host: '[data-transition-id="method-tooling__method-proof"]' }],
  ['brand-to-services', { adapter: 'figure3-transition', host: '[data-transition-id="brand-services"]' }],
  ['services-to-lab', { adapter: 'ttg', host: '[data-transition-id="services-lab"]' }],
  ['lab-to-education', { adapter: 'ph', host: '[data-transition-id="lab-education"]' }],
  ['education-to-philosophy', { adapter: 'soft-breath', host: '[data-transition-id="education-philosophy"]' }],
  ['philosophy-to-contact', { adapter: 'crane', host: '[data-transition-id="philosophy-contact"]' }]
]);

for (const segment of homepageMasterTimeline.segments) {
  const expected = segmentExpectations.get(segment.id);
  assert.ok(expected, `${segment.id} must be covered by integration expectations`);
  assert.equal(segment.hostSelector, expected.host, `${segment.id} host selector must match the generated host`);
  assert.equal(segment.transition.adapter, expected.adapter, `${segment.id} adapter must match registry integration`);
}

const producerNames = new Set(homepageMasterTimeline.surfaces.map((surface) => surface.producer));
for (const producerName of producerNames) {
  assert.match(registrySource, new RegExp(producerName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), `surface producer ${producerName} must be registered`);
}

assert.match(read(adapterPaths.figure2), /renderFigure2TransitionProgress|startFigureVideoPlayback/, 'Figure2 adapter must keep real video transition controls');
assert.match(read(adapterPaths.ttg), /createTtgTransitionScene[\s\S]*renderRawProgress/, 'TTG adapter must drive the existing transition scene renderer');
assert.match(read(adapterPaths.ph), /renderPhTransitionProgress/, 'PH adapter must drive the existing transition renderer');

assert.match(runtimeSource, /applyLayout\(state\)[\s\S]*renderSurfaceProducers\(state\)[\s\S]*renderMasterVisualState\(state\)[\s\S]*masterInkCompositor\.render\(state\)[\s\S]*applyVisibility\(state\)/, 'master runtime frame order must keep producer rendering before ink and visibility');
assert.match(runtimeSource, /assertAllProducersMounted/, 'master runtime must require all producers before start');
assert.doesNotMatch(continuityCss, /main > section\[data-section-id\][\s\S]*height:\s*0\s*!important/, 'master-visible CSS must keep real sections in the visible flow');
assert.match(continuityCss, /\[data-homepage-master-stage\][\s\S]*display:\s*none/, 'master observer stage must stay out of the visible path');
assert.match(continuityCss, /\[data-master-scene-layer\]/, 'continuity CSS must style the master scene layer');
assert.doesNotMatch(continuityCss, /homepage-handoff-preview|homepage-handoff-receiver/, 'continuity CSS must not keep retired preview/receiver selectors');

for (const text of [
  '你的同行不是更聪明，只是更早把 AI 用进了生意里。',
  '让 AI 从一场培训，变成账上的数字。',
  'AI 不是技术专家的玩具'
]) {
  assert.ok(indexHtml.includes(text), `master-visible build must contain copy: ${text}`);
}

console.log('Homepage master transition integration contract passed.');
