import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (relativePath) => readFileSync(path.join(root, relativePath), 'utf8');
const exists = (relativePath) => existsSync(path.join(root, relativePath));
const escapeRegExp = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const joined = (...parts) => parts.join('');
const wordPattern = (...parts) => new RegExp(`\\b${escapeRegExp(joined(...parts))}\\b`);

const sourceManifestUrl = pathToFileURL(path.join(root, 'src/section-manifest.mjs')).href;
const sourceManifest = await import(`${sourceManifestUrl}?master=${Date.now()}`);

assert.ok(sourceManifest.homepageMasterTimeline, 'src/section-manifest.mjs must export homepageMasterTimeline');
assert.equal(sourceManifest[joined('ownership', 'Windows')], undefined, 'retired ownership export must be absent');

const timeline = sourceManifest.homepageMasterTimeline;
assert.ok(timeline.track?.selector, 'homepageMasterTimeline.track.selector must exist');
assert.ok(timeline.track?.stickySelector, 'homepageMasterTimeline.track.stickySelector must exist');
assert.equal(Array.isArray(timeline.scenes), true, 'homepageMasterTimeline.scenes must be an array');
assert.equal(Array.isArray(timeline.surfaces), true, 'homepageMasterTimeline.surfaces must be an array');
assert.equal(Array.isArray(timeline.segments), true, 'homepageMasterTimeline.segments must be an array');
assert.equal(Array.isArray(timeline.scrollBlocks), true, 'homepageMasterTimeline.scrollBlocks must be an array');

const sceneIds = new Set(timeline.scenes.map((scene) => scene.id));
const surfaceIds = new Set(timeline.surfaces.map((surface) => surface.id));
const sceneById = new Map(timeline.scenes.map((scene) => [scene.id, scene]));
const surfaceById = new Map(timeline.surfaces.map((surface) => [surface.id, surface]));

for (const sceneId of [
  'home',
  'belief.upper',
  'belief.lower',
  'method',
  'method.proof',
  'brand',
  'services',
  'lab',
  'education',
  'philosophy',
  'contact'
]) {
  assert.equal(sceneIds.has(sceneId), true, `master timeline scene ${sceneId} must exist`);
}

for (const scene of timeline.scenes) {
  assert.ok(scene.rootSelector, `${scene.id} must declare rootSelector`);
  assert.ok(scene.visualSelector, `${scene.id} must declare visualSelector`);
  assert.ok(scene.copySelector, `${scene.id} must declare copySelector`);
  assert.ok(scene.layoutAnchorSelector, `${scene.id} must declare layoutAnchorSelector`);
  assert.ok(scene.surfaceKey, `${scene.id} must declare surfaceKey`);
  assert.equal(surfaceIds.has(scene.surfaceKey), true, `${scene.id} surfaceKey must point to a declared surface`);
  assert.equal(scene.textureKey, undefined, `${scene.id} must not use legacy textureKey`);
}

for (const surface of timeline.surfaces) {
  assert.ok(surface.id, 'surface must declare id');
  assert.ok(surface.selector, `${surface.id} must declare selector`);
  assert.match(surface.kind, /^(canvas|canvas-or-image|canvas-or-video|image|video)$/, `${surface.id} kind must be explicit`);
  assert.ok(surface.producer, `${surface.id} must declare a deterministic surface producer`);
  assert.equal(typeof surface.allowGeneratedCanvas, 'boolean', `${surface.id} must explicitly allow or forbid generated canvas fallback`);
  if (surface.id.endsWith('.bridge')) {
    assert.ok(surface.ownerScene, `${surface.id} bridge surface must declare ownerScene`);
    assert.equal(sceneIds.has(surface.ownerScene), true, `${surface.id} ownerScene must be a declared scene`);
    assert.match(surface.canonicalRole, /^(scene-visual|transition-source)$/, `${surface.id} bridge surface must declare canonicalRole`);
    if (surface.canonicalRole === 'transition-source') {
      assert.ok(surface.sameRectAs, `${surface.id} transition-source bridge must declare sameRectAs`);
      assert.equal(surfaceIds.has(surface.sameRectAs), true, `${surface.id} sameRectAs must point to a declared surface`);
    }
  }
}

const segmentIds = new Set(timeline.segments.map((segment) => segment.id));
for (const segmentId of [
  'home-to-belief-upper',
  'belief-upper-to-belief-lower',
  'belief-lower-to-method',
  'method-proof-to-brand',
  'brand-to-services',
  'services-to-lab',
  'lab-to-education',
  'education-to-philosophy',
  'philosophy-to-contact'
]) {
  assert.equal(segmentIds.has(segmentId), true, `master timeline segment ${segmentId} must exist`);
}

for (const segment of timeline.segments) {
  assert.equal(sceneIds.has(segment.from), true, `${segment.id} from scene must exist`);
  assert.equal(sceneIds.has(segment.to), true, `${segment.id} to scene must exist`);
  assert.equal(Number.isFinite(segment.scrollVh) && segment.scrollVh > 0, true, `${segment.id} must declare positive scrollVh`);
  assert.equal(typeof segment.visualHandoffAt, 'number', `${segment.id} must declare visualHandoffAt`);
  assert.ok(segment.scenePresence?.from, `${segment.id} must define source scene presence`);
  assert.ok(segment.scenePresence?.to, `${segment.id} must define target scene presence`);
  assert.equal(Array.isArray(segment.copy?.source?.exit), true, `${segment.id} must define source copy exit`);
  assert.equal(segment.copy.source.exit.length, 2, `${segment.id} source copy exit must have start and end`);
  assert.equal(typeof segment.copy.source.readableUntil, 'number', `${segment.id} source copy readableUntil must be explicit`);
  assert.equal(typeof segment.copy.source.foregroundUntil, 'number', `${segment.id} source copy foregroundUntil must be explicit`);
  assert.ok(segment.copy?.target?.policy, `${segment.id} must define explicit target copy policy`);
  assert.match(segment.copy.target.policy, /^(overlap|after-ink|settled-only|none)$/, `${segment.id} target copy policy must be supported`);
  if (segment.copy.target.policy === 'settled-only') {
    assert.equal(segment.copy.target.enter, undefined, `${segment.id} settled-only target copy must not enter during transition`);
    assert.equal(segment.copy.target.readableAt, undefined, `${segment.id} settled-only target copy must not declare transition readableAt`);
    assert.equal(segment.copy.target.foregroundAt, undefined, `${segment.id} settled-only target copy must not declare transition foregroundAt`);
  } else if (segment.copy.target.policy === 'none') {
    assert.equal(segment.copy.target.enter, undefined, `${segment.id} none target copy must not declare enter`);
    assert.equal(segment.copy.target.readableAt, undefined, `${segment.id} none target copy must not declare readableAt`);
    assert.equal(segment.copy.target.foregroundAt, undefined, `${segment.id} none target copy must not declare foregroundAt`);
  } else {
    assert.equal(Array.isArray(segment.copy.target.enter), true, `${segment.id} target copy enter must be a tuple`);
    assert.equal(segment.copy.target.enter.length, 2, `${segment.id} target copy enter must have start and end`);
    assert.equal(typeof segment.copy.target.readableAt, 'number', `${segment.id} target copy readableAt must be explicit`);
    assert.equal(typeof segment.copy.target.foregroundAt, 'number', `${segment.id} target copy foregroundAt must be explicit`);
  }
  assert.equal(segment.copy?.toReadable, undefined, `${segment.id} must not use legacy copy.toReadable`);
  assert.equal(segment.copy?.toForeground, undefined, `${segment.id} must not use legacy copy.toForeground`);
  if (segment.transition?.type === 'ink') {
    assert.ok(segment.transition.ink.variant, `${segment.id} ink must declare variant`);
    assert.ok(segment.transition.ink.sourceSurfaceKey, `${segment.id} ink must declare sourceSurfaceKey`);
    assert.ok(segment.transition.ink.targetSurfaceKey, `${segment.id} ink must declare targetSurfaceKey`);
    assert.equal(surfaceIds.has(segment.transition.ink.sourceSurfaceKey), true, `${segment.id} sourceSurfaceKey must exist`);
    assert.equal(surfaceIds.has(segment.transition.ink.targetSurfaceKey), true, `${segment.id} targetSurfaceKey must exist`);
    const fromScene = sceneById.get(segment.from);
    const toScene = sceneById.get(segment.to);
    const sourceSurface = surfaceById.get(segment.transition.ink.sourceSurfaceKey);
    const targetSurface = surfaceById.get(segment.transition.ink.targetSurfaceKey);
    assert.ok(
      segment.transition.ink.sourceSurfaceKey === fromScene.surfaceKey || sourceSurface?.ownerScene === segment.from,
      `${segment.id} sourceSurfaceKey must be owned by segment.from`
    );
    assert.ok(
      segment.transition.ink.targetSurfaceKey === toScene.surfaceKey || targetSurface?.ownerScene === segment.to,
      `${segment.id} targetSurfaceKey must be owned by segment.to`
    );
    const inkEnd = segment.transition.ink.window?.[1];
    if (segment.copy.target.policy === 'overlap') {
      assert.ok(segment.copy.target.enter[0] < inkEnd, `${segment.id} overlap target copy must start before ink ends`);
    }
    if (segment.copy.target.policy === 'after-ink') {
      assert.ok(segment.copy.target.enter[0] >= inkEnd - 0.02, `${segment.id} after-ink target copy must start at or after ink end`);
    }
    assert.equal(segment.transition.ink.component, undefined, `${segment.id} must not use legacy ink.component`);
  }
}

const blockIds = new Set(timeline.scrollBlocks.map((block) => block.id));
for (const blockId of [
  'home-hold',
  'belief-upper-hold',
  'belief-lower-hold',
  'method-hold',
  'method-proof-hold',
  'brand-hold',
  'services-hold',
  'philosophy-hold',
  'contact-hold'
]) {
  assert.equal(blockIds.has(blockId), true, `master scroll block ${blockId} must exist`);
}

for (const block of timeline.scrollBlocks) {
  assert.match(block.type, /^(hold|transition)$/, `${block.id} must be hold or transition`);
  if (block.type === 'hold') {
    assert.equal(sceneIds.has(block.scene), true, `${block.id} hold scene must exist`);
    assert.equal(Number.isFinite(block.scrollVh) && block.scrollVh > 0, true, `${block.id} hold must declare positive scrollVh`);
  }
  if (block.type === 'transition') {
    assert.equal(segmentIds.has(block.segment), true, `${block.id} transition block must point to a segment`);
  }
}

assert.equal(exists('js/transitions/homepage/master-timeline-manifest.js'), true, 'generated master timeline manifest must exist');
assert.equal(exists('js/transitions/homepage/master-scroll-timeline.js'), true, 'master scroll timeline resolver must exist');
assert.equal(exists('js/transitions/homepage/master-scroll-map.js'), true, 'master scroll map must exist');

const resolverUrl = pathToFileURL(path.join(root, 'js/transitions/homepage/master-scroll-timeline.js')).href;
const resolver = await import(`${resolverUrl}?master=${Date.now()}`);
const model = resolver.createMasterTimelineModel(timeline);
const firstTransitionSegment = model.segments.find((segment) => segment.id === 'home-to-belief-upper');
const firstTransitionPosition = firstTransitionSegment.startVh + firstTransitionSegment.lengthVh * 0.5;
const firstState = resolver.resolveMasterTimelineState(model, firstTransitionPosition, firstTransitionPosition - 1);
assert.equal(firstState.direction, 'forward', 'resolver must resolve forward direction');
assert.ok(firstState.segment, 'resolver must resolve an active segment');
assert.equal(firstState.scenes.has(firstState.segment.from), true, 'resolver must include source scene state');
assert.equal(firstState.scenes.has(firstState.segment.to), true, 'resolver must include target scene state');
const reverseState = resolver.resolveMasterTimelineState(model, firstTransitionPosition, firstTransitionPosition + 1);
assert.equal(reverseState.direction, 'reverse', 'resolver must resolve reverse direction from the same segment math');
const visibilitySignature = (state) => JSON.stringify([...state.scenes.entries()]
  .sort(([left], [right]) => left.localeCompare(right))
  .map(([sceneId, sceneState]) => ({
    sceneId,
    active: sceneState.active,
    role: sceneState.role,
    visualOpacity: Number(sceneState.visual.opacity.toFixed(4)),
    visualTranslateY: Number(sceneState.visual.translateY.toFixed(2)),
    visualZIndex: sceneState.visual.zIndex,
    copyOpacity: Number(sceneState.copy.opacity.toFixed(4)),
    copyTranslateY: Number(sceneState.copy.translateY.toFixed(2)),
    copyReadable: sceneState.copy.readable,
    copyForeground: sceneState.copy.foreground
  })));
for (const segment of model.segments) {
  for (const progress of [0.1, 0.25, 0.5, 0.75, 0.9]) {
    const position = segment.startVh + segment.lengthVh * progress;
    const forward = resolver.resolveMasterTimelineState(model, position, position - 1);
    const reverse = resolver.resolveMasterTimelineState(model, position, position + 1);
    assert.equal(forward.segment.id, segment.id, `${segment.id} forward must resolve same segment`);
    assert.equal(reverse.segment.id, segment.id, `${segment.id} reverse must resolve same segment`);
    assert.equal(forward.localProgress.toFixed(4), reverse.localProgress.toFixed(4), `${segment.id} local progress must be direction-independent`);
    assert.equal(forward.direction, 'forward', `${segment.id} forward direction must be forward`);
    assert.equal(reverse.direction, 'reverse', `${segment.id} reverse direction must be reverse`);
    assert.equal(
      visibilitySignature(forward),
      visibilitySignature(reverse),
      `${segment.id} at ${progress}: forward and reverse must render the same visible scene/copy state`
    );
  }
}
const sourceCopyState = firstState.scenes.get(firstState.segment.from).copy;
const targetCopyState = firstState.scenes.get(firstState.segment.to).copy;
assert.ok(sourceCopyState.opacity < 1, 'source copy must be allowed to exit during transition');
assert.ok(targetCopyState.opacity >= 0, 'target copy state must be resolved separately from source copy');
const settledOnlySegment = model.segments.find((segment) => segment.copy?.target?.policy === 'settled-only');
const settledOnlyState = resolver.resolveMasterTimelineState(
  model,
  settledOnlySegment.startVh + settledOnlySegment.lengthVh * 0.9,
  settledOnlySegment.startVh
);
assert.equal(settledOnlyState.scenes.get(settledOnlySegment.to).copy.opacity, 0, 'settled-only target copy must remain hidden during transition');
const blockBeforeBoundary = model.blocks[0];
const blockAfterBoundary = model.blocks[1];
const boundaryState = resolver.resolveMasterTimelineState(model, blockBeforeBoundary.endVh, blockBeforeBoundary.startVh);
assert.equal(boundaryState.block.id, blockAfterBoundary.id, 'block boundary must resolve to the next block, not the completed previous block');
const scrollMapSource = read('js/transitions/homepage/master-scroll-map.js');
assert.match(scrollMapSource, /getBoundingClientRect/, 'master scroll map must measure real DOM track geometry');
assert.match(scrollMapSource, /positionForScrollY/, 'master scroll map must expose real scrollY mapper');
assert.match(scrollMapSource, /ResizeObserver/, 'master scroll map must refresh on layout resize');
assert.match(scrollMapSource, /MutationObserver/, 'master scroll map must refresh after master track structure changes');
assert.match(scrollMapSource, /fonts\?\.ready/, 'master scroll map must refresh after font loading');
assert.match(scrollMapSource, /loadingdone/, 'master scroll map must refresh after late font loading');
assert.match(scrollMapSource, /visualViewport/, 'master scroll map must refresh on visual viewport resize');
assert.match(scrollMapSource, /loadedmetadata/, 'master scroll map must refresh after video metadata loads');
assert.match(scrollMapSource, /destroy\(\)/, 'master scroll map must expose destroy cleanup');
assert.doesNotMatch(read('js/transitions/homepage/master-scroll-timeline.js'), /window\.scrollY/, 'resolver must not read window.scrollY directly');

assert.equal(exists('js/transitions/homepage/master-scene-registry.js'), true, 'master scene registry must exist');
assert.equal(exists('js/transitions/homepage/master-scene-presenter.js'), true, 'master scene presenter must exist');
assert.equal(exists('js/transitions/homepage/master-surface-renderer.js'), true, 'master surface renderer must exist');
assert.equal(exists('js/transitions/homepage/master-surface-producer-registry.js'), true, 'master surface producer registry must exist');

const registrySource = read('js/transitions/homepage/master-scene-registry.js');
assert.match(registrySource, /textureProvider/, 'scene registry must expose textureProvider');
assert.match(registrySource, /surfaceEntries/, 'scene registry must expose surface entries');
assert.match(registrySource, /textureSourceForSurface/, 'scene registry must expose surface texture lookup');
assert.match(registrySource, /allowGeneratedCanvas/, 'scene registry must only create fallback canvases when the manifest allows it');
assert.match(registrySource, /HTMLCanvasElement|HTMLVideoElement|HTMLImageElement|ImageBitmap|OffscreenCanvas|VideoFrame/, 'scene registry must restrict texture sources to CanvasImageSource-compatible inputs');
assert.doesNotMatch(registrySource, /copyElement.*textureProvider/s, 'copy DOM must not be used as texture provider');
const surfaceRendererSource = read('js/transitions/homepage/master-surface-renderer.js');
assert.match(surfaceRendererSource, /resizeCanvasToElement/, 'surface renderer must size canonical canvas surfaces to their viewport rect');
assert.match(surfaceRendererSource, /prepareSurface/, 'surface renderer must expose prepareSurface for adapters');
const surfaceProducerRegistrySource = read('js/transitions/homepage/master-surface-producer-registry.js');
assert.match(surfaceProducerRegistrySource, /mountSurfaceProducer/, 'surface producer registry must mount producers by surface key');
assert.match(surfaceProducerRegistrySource, /renderSurfaceProducers/, 'surface producer registry must render producers before ink');
assert.match(surfaceProducerRegistrySource, /assertAllProducersMounted/, 'surface producer registry must fail when any declared producer is missing');
assert.match(surfaceProducerRegistrySource, /prepareSurface/, 'surface producer registry must prepare canonical surfaces before rendering');
assert.match(surfaceProducerRegistrySource, /surface\.sameRectAs/, 'surface producer registry must prepare sameRectAs bridge surfaces every frame');
assert.match(surfaceProducerRegistrySource, /timelineProgress/, 'surface producer registry must pass global timeline progress');
assert.match(surfaceProducerRegistrySource, /blockProgress/, 'surface producer registry must pass hold block progress');
const observerSurfaceProducerSource = read('js/transitions/homepage/master-observer-surface-producer.js');
assert.match(observerSurfaceProducerSource, /real-flow-observer/, 'master surface producer must observe real visible flow');
const aodProducerSource = read('js/transitions/homepage/aod-homepage-adapter.js');
assert.match(aodProducerSource, /aod_figure-alpha-front-scrub\.webm/, 'AOD visible adapter must use the real AOD figure video');
const figure2ProducerSource = read('js/transitions/homepage/figure2-homepage-adapter.js');
assert.match(figure2ProducerSource, /figure2-transition/, 'Figure2 visible adapter must mount the real transition');
const figure3ProducerSource = read('js/transitions/homepage/figure3-homepage-adapter.js');
assert.match(figure3ProducerSource, /figure3-alpha-scrub\.webm|figure3-alpha-poster\.png/, 'Figure3 visible adapter must use real figure assets');
const craneProducerSource = read('js/transitions/homepage/crane-homepage-adapter.js');
assert.match(craneProducerSource, /crane-figure1-transition\.webm/, 'Crane visible adapter must use real crane figure video');
const presenterSource = read('js/transitions/homepage/master-scene-presenter.js');
assert.match(presenterSource, /applyLayout/, 'presenter must expose applyLayout before surface rendering');
assert.match(presenterSource, /applyVisibility/, 'presenter must expose applyVisibility after ink rendering');
assert.match(presenterSource, /rootElement/, 'presenter must control scene root');
assert.match(presenterSource, /visualElement/, 'presenter must control visual layer');
assert.match(presenterSource, /layoutAnchor/, 'presenter must control layout anchor');
assert.match(presenterSource, /style\.inset = 'auto'/, 'presenter must clear inset for viewport anchored layout');
assert.match(presenterSource, /style\.bottom = 'auto'/, 'presenter must clear bottom for viewport anchored layout');
assert.match(presenterSource, /100vw - \$\{rightVw \* 2\}vw/, 'right-anchored copy must subtract the mobile inset from its width');
assert.match(presenterSource, /surfaceEntry/, 'presenter must control surface layer state');
assert.match(presenterSource, /collectSurfaceStates/, 'presenter must aggregate shared surface state before writing surfaces');
assert.match(presenterSource, /applySurfaceStates/, 'presenter must write each surface once per frame');
assert.match(presenterSource, /surfaceEntry\.shared/, 'presenter must keep shared surface ownership keyed by surface id');
const applySceneStateBody = presenterSource.match(/(?:function|const)\s+applySceneState[\s\S]*?(?=\n\nfunction collectSurfaceStates)/)?.[0] || '';
assert.ok(applySceneStateBody, 'presenter must define applySceneState');
assert.doesNotMatch(applySceneStateBody, /data-master-surface-active/, 'applySceneState must not directly write shared surface state');
assert.match(presenterSource, /data-master-scene-readable/, 'presenter must set data-master-scene-readable');
assert.match(presenterSource, /data-master-scene-foreground/, 'presenter must set data-master-scene-foreground');
assert.match(presenterSource, /--master-visual-opacity/, 'presenter must set master visual opacity');
assert.match(presenterSource, /--master-copy-opacity/, 'presenter must set master copy opacity');
assert.match(presenterSource, /--master-copy-y/, 'presenter must set master copy y');
assert.match(presenterSource, /--master-scene-z/, 'presenter must set master scene z-index');
assert.match(presenterSource, /--master-stagger-progress/, 'presenter must set per-item stagger progress');
const continuityCss = read('css/components/homepage-continuity.css');
assert.match(continuityCss, /\[data-master-scene\]/, 'continuity CSS must style master scenes');
assert.match(continuityCss, /\[data-master-scene-root\]/, 'continuity CSS must style master scene roots');
assert.match(continuityCss, /\[data-master-surface-layer\]/, 'continuity CSS must style master surface layer');
assert.match(continuityCss, /\[data-master-ink-canvas\]/, 'continuity CSS must size master ink canvas');
assert.match(continuityCss, /\[data-master-scene-layer\]/, 'continuity CSS must style master scene layer');
assert.match(continuityCss, /\[data-master-scene-visual-layer\]/, 'continuity CSS must keep scene visuals below ink');
assert.match(continuityCss, /\[data-master-copy-layer\]/, 'continuity CSS must keep copy above ink');
assert.match(continuityCss, /data-master-ink-active="false"/, 'continuity CSS must hide inactive ink canvas');
assert.match(continuityCss, /html\[data-master-dom-mode="master-visible"\]/, 'continuity CSS must neutralize legacy section visibility in master-visible mode');
assert.match(continuityCss, /\[data-homepage-master-track\]/, 'continuity CSS must style master track');
assert.match(continuityCss, /\[data-master-timeline-hud\]/, 'continuity CSS must style master timeline HUD');
assert.match(continuityCss, /data-belief-upper-stagger/, 'continuity CSS must preserve Belief upper stagger');
const builtHtmlForSurfaceCss = read('index.html');
const paperThemeCss = read('css/sections/paper-canvas-theme.css');
assert.match(paperThemeCss, /\[data-master-copy-theme="paper"\]/, 'paper theme must apply to master paper copy roots');
assert.match(builtHtmlForSurfaceCss, /data-master-scene-layout="method" data-master-copy-theme="paper"/, 'Method master copy must inherit paper text theme');
assert.match(builtHtmlForSurfaceCss, /data-master-scene-layout="services" data-master-copy-theme="paper"/, 'Services master copy must inherit paper text theme');
assert.match(builtHtmlForSurfaceCss, /data-master-scene-layout="contact" data-master-copy-theme="paper"/, 'Contact master copy must inherit paper text theme');
assert.match(builtHtmlForSurfaceCss, /data-master-timeline-hud/, 'built page must include the feedback timeline HUD');
assert.match(builtHtmlForSurfaceCss, /data-master-hud-cursor/, 'timeline HUD must include an overall progress cursor');
assert.match(builtHtmlForSurfaceCss, /data-master-surface="belief\.star"/, 'master observer must still register a belief star surface');
assert.doesNotMatch(builtHtmlForSurfaceCss.match(/<div data-master-surface-layer[\s\S]*?<\/div>\n        <div data-master-scene-layer>/)?.[0] || '', /data-belief-star-field/, 'master belief surface must not steal the live Belief star selector');
assert.doesNotMatch(continuityCss, /main > \.hero-wrap[\s\S]*height:\s*0\s*!important/, 'master-visible CSS must not retire the real hero flow');
assert.doesNotMatch(continuityCss, /main > \.long-canvas[\s\S]*height:\s*0\s*!important/, 'master-visible CSS must not retire the real long-canvas flow');
assert.match(continuityCss, /\[data-homepage-master-stage\][\s\S]*display:\s*none/, 'master observer stage must be hidden from the visible path');
assert.match(continuityCss, /html\[data-master-dom-mode="master-visible"\] \.site-nav/, 'master-visible CSS must show nav without legacy hero animation');

assert.equal(exists('js/transitions/homepage/master-ink-compositor.js'), true, 'master ink compositor must exist');

const inkCompositorSource = read('js/transitions/homepage/master-ink-compositor.js');
assert.match(inkCompositorSource, /createInkCurtainTransition/, 'master ink compositor must reuse shared ink component');
assert.match(inkCompositorSource, /textureSourceForSurface\(segment\.transition\.ink\.sourceSurfaceKey\)/, 'master ink compositor must source declared source surface');
assert.match(inkCompositorSource, /textureSourceForSurface\(segment\.transition\.ink\.targetSurfaceKey\)/, 'master ink compositor must source declared target surface');
assert.match(inkCompositorSource, /clearInactive/, 'master ink compositor must clear inactive transition state');
assert.match(inkCompositorSource, /masterInkVariant/, 'master ink compositor must expose active ink variant for browser audit');
assert.match(inkCompositorSource, /masterInkDirection/, 'master ink compositor must expose active ink direction for browser audit');
assert.match(inkCompositorSource, /insideInkWindow/, 'master ink compositor must deactivate outside ink.window');
assert.match(inkCompositorSource, /activeTransition\??\.clear\?\.\(\)/, 'master ink compositor must clear the canvas outside ink.window');
assert.match(inkCompositorSource, /deterministicTime/, 'master ink compositor must pass deterministic shader time');
const inkSource = read('js/effects/ink-scene-transition.js');
assert.match(inkSource, /inkUsesCanonicalSurfaces/, 'ink renderer must expose canonical surface marker');
assert.match(inkSource, /vertical-curtain/, 'ink renderer must support vertical-curtain variant');
assert.match(inkSource, /radial-center-out/, 'ink renderer must support radial-center-out variant');
assert.match(inkSource, /destroy\(\)/, 'ink renderer must expose destroy cleanup');
assert.match(inkSource, /function render\(progress, pointerX = 0, pointerY = 0, frameOptions = \{\}\)/, 'ink renderer must keep pointer args and accept frameOptions as fourth argument');
assert.match(inkSource, /clear: clearFrame/, 'ink renderer must expose clearFrame through clear()');
assert.doesNotMatch(inkSource, /performance\.now|Date\.now/, 'ink renderer must not use wall-clock time for master timeline visuals');
assert.doesNotMatch(inkCompositorSource, /sourceSceneElement|nextSceneElement|targetSceneElement/, 'master ink compositor must not use DOM text elements as textures');

const generatedSource = read('js/transitions/homepage/master-timeline-manifest.js');
assert.match(generatedSource, /Generated by scripts\/build-index\.mjs/, 'master-timeline-manifest.js must be generated');
assert.match(generatedSource, /homepageMasterTimeline/, 'generated manifest must export homepageMasterTimeline');

const runtimeSource = read('js/transitions/homepage-transition-runtime.js');
assert.match(runtimeSource, /createMasterTimelineModel/, 'runtime must create master timeline model');
assert.match(runtimeSource, /createMasterScrollMap/, 'runtime must create master scroll map');
assert.match(runtimeSource, /positionForScrollY/, 'runtime must map real scrollY through master scroll map');
assert.match(runtimeSource, /resolveMasterTimelineState/, 'runtime must resolve master timeline state');
assert.match(runtimeSource, /createMasterSceneRegistry/, 'runtime must create master scene registry');
assert.match(runtimeSource, /createMasterScenePresenter/, 'runtime must create master scene presenter');
assert.match(runtimeSource, /createMasterSurfaceProducerRegistry/, 'runtime must create master surface producer registry');
assert.match(runtimeSource, /createMasterInkCompositor/, 'runtime must create master ink compositor');
assert.match(runtimeSource, /Missing \[data-master-ink-canvas\]/, 'runtime must fail fast when master ink canvas is missing');
assert.match(runtimeSource, /MASTER_TIMELINE_ENABLED/, 'runtime must gate master and legacy visual authority');
assert.match(runtimeSource, /document\.documentElement\.dataset\.masterTimelineEnabled === 'true'/, 'runtime must read the generated master timeline flag');
assert.match(runtimeSource, /initLegacyHomepageTransitions/, 'runtime must isolate legacy homepage implementation');
assert.match(runtimeSource, /initMasterHomepageTransitions/, 'runtime must isolate master homepage implementation');
const masterRuntimeBody = runtimeSource.match(/async function initMasterHomepageTransitions[\s\S]*?async function initLegacyHomepageTransitions/)?.[0] || runtimeSource;
assert.doesNotMatch(masterRuntimeBody, /createHomepageSnapCoordinator|handoffProgressSource|snapController\.progressSource/, 'master runtime must not call legacy snap or ownership visual progress');
assert.doesNotMatch(runtimeSource, new RegExp(joined('scrollY', 'To', 'Timeline', 'Vh')), 'runtime must not use the retired page-top mapper');
assert.doesNotMatch(runtimeSource, /scene-timeline-controller/, 'homepage runtime must not import retired scene timeline controller');
assert.match(runtimeSource, /previousMasterState/, 'runtime must retain previous master state as a render fallback');
assert.match(runtimeSource, /real legacy visual flow/, 'master runtime must document that real legacy flow owns visible animation');
assert.match(runtimeSource, /cancelAnimationFrame/, 'runtime must cancel master RAF on destroy');
assert.match(runtimeSource, /destroyMasterTimelineRuntime/, 'runtime must expose master timeline destroy lifecycle');
assert.match(runtimeSource, /initLegacyHomepageTransitions\(options\)/, 'master-enabled mode must also start the real legacy transition runtime');
assert.match(runtimeSource, /data-master-timeline-hud/, 'master runtime must find the feedback HUD');
assert.match(runtimeSource, /--master-hud-progress/, 'master runtime must update HUD total progress');
assert.match(runtimeSource, /masterHudActive/, 'master runtime must mark the active HUD block');
assert.match(runtimeSource, /renderSurfaceProducers\(state\)/, 'runtime must render surface producers before ink');
assert.match(runtimeSource, /assertAllProducersMounted/, 'runtime must fail if any declared surface producer is missing');
assert.match(runtimeSource, /homepageSurfaceProducerRegistry/, 'runtime must use the homepage surface producer registry');
assert.match(runtimeSource, /applyLayout\(state\)[\s\S]*renderSurfaceProducers\(state\)[\s\S]*renderMasterVisualState\(state\)[\s\S]*masterInkCompositor\.render\(state\)[\s\S]*applyVisibility\(state\)/, 'runtime must keep master observer frame order stable');
assert.match(runtimeSource, /mountedSceneRenderers/, 'runtime must support hold scene renderers');
assert.match(runtimeSource, /blockProgress/, 'runtime must pass blockProgress to hold renderers');
assert.match(runtimeSource, /masterScenePresenter\.clear/, 'runtime destroy must clear master presenter state');
assert.doesNotMatch(masterRuntimeBody, /handoffProgressSource/, 'master observer runtime must not pass handoffProgressSource');
const builtHtml = read('index.html');
assert.match(builtHtml, /data-master-timeline-enabled="true"/, 'built page must enable the master timeline after retirement');
assert.match(builtHtml, /data-master-dom-mode="master-visible"/, 'built page must switch to master-visible DOM after retirement');
assert.doesNotMatch(builtHtml, /data-master-timeline-enabled="false"/, 'built page must not leave the master timeline disabled');
assert.doesNotMatch(builtHtml, /data-master-scaffold-hidden|data-homepage-master-track[^>]*hidden|data-homepage-master-track[^>]*inert/, 'master-visible page must not keep the master track hidden or inert');
const transitionRegistrySource = read('js/transitions/homepage-transition-registry.js');
assert.match(transitionRegistrySource, /homepageSurfaceProducerRegistry/, 'transition registry must export surface producer factories');
for (const surface of timeline.surfaces) {
  assert.match(transitionRegistrySource, new RegExp(escapeRegExp(surface.producer)), `${surface.id} producer ${surface.producer} must be registered`);
}
const observerProducerSource = read('js/transitions/homepage/master-observer-surface-producer.js');
assert.match(observerProducerSource, /real-flow-observer/, 'master surface producer must observe the real visible flow instead of drawing placeholders');
assert.doesNotMatch(transitionRegistrySource, /create(?!Observer)[A-Za-z]+SurfaceProducer\(context\)/, 'registry must not import fake per-scene surface producers');

const beliefHtml = read('src/sections/belief.html');
const heroHtml = read('src/sections/hero.html');
assert.match(heroHtml, /你的同行不是更聪明，只是更早把 AI 用进了生意里。/, 'hero subtitle must remain in hero');
assert.doesNotMatch(beliefHtml, /你的同行不是更聪明，只是更早把 AI 用进了生意里。/, 'hero subtitle must not move into belief');
assert.match(beliefHtml, /data-belief-upper-stagger="headline"/, 'belief upper must keep stagger headline');
assert.match(beliefHtml, /让 AI 从一场培训，变成账上的数字。/, 'belief upper restored copy must exist');

const patternSource = read('js/transitions/pattern-bloom-adapter.js');
assert.match(patternSource, /createPatternBloomScene/, 'Pattern Bloom must run the real animation scene');
assert.match(patternSource, /createInkSceneTransition/, 'Pattern Bloom must keep its real visible ink until master producers are equivalent');
assert.doesNotMatch(patternSource, /prepareSurface|surfaceFor\('belief\.star'\)|surfaceFor\("belief\.star"\)/, 'Pattern Bloom adapter must not draw canonical surfaces in master mode');

const mainSource = read('js/main.js');
assert.match(mainSource, /dataset\.masterTimelineEnabled/, 'main.js must branch legacy visual initializers by master flag');
assert.match(mainSource, /initLayeredHero\(\{ root, body, runtime, reduceMotion \}\)/, 'master mode must start the real Hero runtime');
assert.match(mainSource, /initBeliefStarField\(\{ root: document, reduceMotion \}\)/, 'master mode must start the real Belief star runtime');
assert.doesNotMatch(read('js/sections/hero.js'), /createHeroSurfaceProducer/, 'hero module must not expose a fake master surface producer');
assert.doesNotMatch(read('js/sections/belief.js'), /createBeliefStarSurfaceProducer/, 'belief module must not expose a fake master surface producer');

for (const [label, relativePath] of [
  ['AOD', 'js/transitions/homepage/aod-homepage-adapter.js'],
  ['Figure2', 'js/transitions/homepage/figure2-homepage-adapter.js'],
  ['Figure3', 'js/transitions/homepage/figure3-homepage-adapter.js'],
  ['Crane', 'js/transitions/homepage/crane-homepage-adapter.js']
]) {
  const source = read(relativePath);
  assert.match(source, /mountHomepageTransition/, `${label} adapter must mount its real visible transition`);
  assert.doesNotMatch(source, /create[A-Za-z]+SurfaceProducer/, `${label} adapter must not export a fake master surface producer`);
  assert.doesNotMatch(source, /draw(Aod|Figure2|Figure3|Crane)/, `${label} adapter must not draw placeholder master visuals`);
}

const figure2Source = read('js/transitions/homepage/figure2-homepage-adapter.js');
assert.match(figure2Source, /mountHomepageTransition/, 'Figure2 must mount the real visible transition');
assert.match(figure2Source, /startFigureVideoPlayback|renderFigure2TransitionProgress/, 'Figure2 must keep real transition video/render controls');

for (const [label, relativePath, segmentId] of [
  ['TTG', 'js/transitions/homepage/ttg-homepage-adapter.js', 'services-to-lab'],
  ['PH', 'js/transitions/homepage/ph-homepage-adapter.js', 'lab-to-education']
]) {
  const source = read(relativePath);
  assert.match(source, /mountHomepageTransition/, `${label} adapter must mount its real visible transition`);
  assert.doesNotMatch(source, /create(Ttg|Ph)SurfaceProducer/, `${label} adapter must not export a fake surface producer`);
  assert.doesNotMatch(source, /draw(Ttg|Ph)Surface/, `${label} adapter must not draw placeholder chart visuals`);
}
assert.match(read('js/transitions/homepage/ttg-homepage-adapter.js'), /createTtgTransitionScene[\s\S]*renderRawProgress/, 'TTG adapter must drive the existing transition scene renderer');
assert.match(read('js/transitions/homepage/ph-homepage-adapter.js'), /renderPhTransitionProgress/, 'PH adapter must drive the existing transition renderer');

console.log('Homepage master timeline contract passed.');
