import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  chapterTransitions,
  contentSections,
  handoffs,
  homepageMasterTimeline,
  sectionEntryPolicies,
} from '../src/section-manifest.mjs';

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const srcDir = path.join(rootDir, 'src');
const includePattern = /\{\{>\s*([^}]+?)\s*\}\}/g;
const MASTER_TIMELINE_ENABLED = true;
const MASTER_DOM_MODE = 'master-visible';
const MASTER_ANCHOR_SCENES = {
  home: 'home',
  belief: 'belief.upper',
  method: 'method',
  brand: 'brand',
  services: 'services',
  lab: 'lab',
  education: 'education',
  philosophy: 'philosophy',
  contact: 'contact'
};
const MASTER_PAPER_COPY_SCENES = new Set([
  'method',
  'method.proof',
  'brand',
  'services',
  'lab',
  'education',
  'philosophy',
  'contact'
]);

function resolveSourcePath(partialPath) {
  if (path.isAbsolute(partialPath) || partialPath.split(/[\\/]/).includes('..')) {
    throw new Error(`Refusing unsafe include path: ${partialPath}`);
  }
  return path.join(srcDir, partialPath);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getAttribute(attrs, name) {
  const match = attrs.match(new RegExp(`\\s${escapeRegExp(name)}="([^"]*)"`));
  if (match) return match[1];
  return new RegExp(`(?:^|\\s)${escapeRegExp(name)}(?:\\s|$)`).test(attrs) ? '' : null;
}

function hasClass(attrs, className) {
  return (getAttribute(attrs, 'class') || '').split(/\s+/).includes(className);
}

function matchesSimpleSelector(tagName, attrs, selector) {
  if (selector.startsWith('.')) {
    return hasClass(attrs, selector.slice(1));
  }

  if (selector.startsWith('#')) {
    return getAttribute(attrs, 'id') === selector.slice(1);
  }

  const attrMatch = selector.match(/^\[([A-Za-z0-9:_-]+)(?:="([^"]*)")?\]$/);
  if (attrMatch) {
    const [, name, value] = attrMatch;
    return value === undefined ? getAttribute(attrs, name) !== null : getAttribute(attrs, name) === value;
  }

  return tagName.toLowerCase() === selector.toLowerCase();
}

function setAttribute(attrs, name, value) {
  const escapedValue = escapeHtml(value);
  const pattern = new RegExp(`\\s${escapeRegExp(name)}="[^"]*"`);
  if (pattern.test(attrs)) {
    return attrs.replace(pattern, ` ${name}="${escapedValue}"`);
  }
  return `${attrs} ${name}="${escapedValue}"`;
}

function getHandoffForTransition(transitionId) {
  return handoffs.find((handoff) => handoff.transitionId === transitionId) || null;
}

function injectSectionAttributes(html, section, index) {
  const sectionOpenPattern = /<section\b[^>]*>/g;
  let didInject = false;

  const nextHtml = html.replace(sectionOpenPattern, (tag) => {
    if (didInject || !tag.includes(section.match)) return tag;

    let attrs = tag.slice('<section'.length, -1);
    attrs = setAttribute(attrs, 'id', section.id);
    attrs = setAttribute(attrs, 'data-section-id', section.id);
    attrs = setAttribute(attrs, 'data-section-index', index);
    attrs = setAttribute(attrs, 'data-section-theme', section.theme);
    attrs = setAttribute(attrs, 'data-section-nav-bg', section.navBg);
    attrs = setAttribute(attrs, 'data-section-layout', section.layout);
    const entryPolicy = sectionEntryPolicies[section.id];
    if (entryPolicy) {
      attrs = setAttribute(attrs, 'data-entry-direct', entryPolicy.directVisit);
      attrs = setAttribute(attrs, 'data-entry-after-handoff', entryPolicy.afterHandoff);
    }
    didInject = true;
    return `<section${attrs}>`;
  });

  if (!didInject) {
    throw new Error(`Unable to inject section metadata for ${section.id} using match ${section.match}`);
  }

  return nextHtml;
}

function injectTransitionAttributes(html, transition) {
  const divOpenPattern = /<div\b[^>]*>/g;
  let didInject = false;

  const nextHtml = html.replace(divOpenPattern, (tag) => {
    if (didInject) return tag;

    let attrs = tag.slice('<div'.length, -1);
    if (!hasClass(attrs, 'chapter-transition')) return tag;
    if (getAttribute(attrs, 'data-transition') !== transition.id) return tag;

    attrs = setAttribute(attrs, 'data-transition', transition.id);
    attrs = setAttribute(attrs, 'data-transition-id', transition.id);
    attrs = setAttribute(attrs, 'data-transition-from', transition.from);
    attrs = setAttribute(attrs, 'data-transition-to', transition.to);
    attrs = setAttribute(attrs, 'data-transition-module', transition.module);
    attrs = setAttribute(attrs, 'data-transition-variant', transition.variant);
    if (transition.drive) attrs = setAttribute(attrs, 'data-transition-drive', transition.drive);
    if (transition.handoffTarget) attrs = setAttribute(attrs, 'data-transition-handoff-target', transition.handoffTarget);
    if (transition.handoffPhase) attrs = setAttribute(attrs, 'data-transition-handoff-phase', transition.handoffPhase);
    const handoff = getHandoffForTransition(transition.id);
    if (handoff) {
      attrs = setAttribute(attrs, 'data-handoff-id', handoff.id);
      attrs = setAttribute(attrs, 'data-handoff-owner', handoff.owner);
      attrs = setAttribute(attrs, 'data-target-entry-policy', handoff.targetEntry.policy);
      attrs = setAttribute(attrs, 'data-target-entry-suppress-once', String(handoff.targetEntry.suppressOnceAfterHandoff));
      attrs = setAttribute(attrs, 'data-handoff-scroll-to', handoff.afterComplete.scrollTo);
      attrs = setAttribute(attrs, 'data-handoff-reduced-motion', handoff.reducedMotion.policy);
      if (handoff.transition?.targetSelector) {
        attrs = setAttribute(attrs, 'data-handoff-target-selector', handoff.transition.targetSelector);
      }
      if (handoff.transition?.ghostScenes?.length) {
        attrs = setAttribute(attrs, 'data-transition-ghost-scenes', handoff.transition.ghostScenes.join(','));
      }
    }

    didInject = true;
    return `<div${attrs}>`;
  });

  if (!didInject) {
    throw new Error(`Unable to find transition ${transition.id}`);
  }

  return nextHtml;
}

function injectFirstTagBySelector(html, selector, applyAttributes, label) {
  const openPattern = /<([A-Za-z][A-Za-z0-9:-]*)\b[^>]*>/g;
  let didInject = false;

  const nextHtml = html.replace(openPattern, (tag, tagName) => {
    if (didInject) return tag;

    let attrs = tag.slice(`<${tagName}`.length, -1);
    if (!matchesSimpleSelector(tagName, attrs, selector)) return tag;

    attrs = applyAttributes(attrs);
    didInject = true;
    return `<${tagName}${attrs}>`;
  });

  if (!didInject) {
    throw new Error(`Unable to inject timeline metadata for ${label} using selector ${selector}`);
  }

  return nextHtml;
}

function injectTimelineAttributes(html) {
  return html;
}

function getMasterSegment(segmentId) {
  return homepageMasterTimeline.segments.find((segment) => segment.id === segmentId) || null;
}

function getMasterTrackVh() {
  return homepageMasterTimeline.scrollBlocks.reduce((sum, block) => {
    if (block.type === 'hold') return sum + block.scrollVh;
    return sum + (getMasterSegment(block.segment)?.scrollVh || 0);
  }, 0);
}

function buildMasterVisualRoot(scene) {
  return [
    `      <div data-master-scene-root="${escapeHtml(scene.id)}" data-master-scene="${escapeHtml(scene.id)}">`,
    `        <div data-master-scene-visual="${escapeHtml(scene.id)}" aria-hidden="true"></div>`,
    '      </div>'
  ].join('\n');
}

function buildMasterCopyRoot(scene, sourceHtml) {
  const copyId = scene.id === 'method' ? 'method.intro' : scene.id;
  const themeAttribute = MASTER_PAPER_COPY_SCENES.has(scene.id) ? ' data-master-copy-theme="paper"' : '';

  return [
    `      <div data-master-scene-layout="${escapeHtml(scene.id)}"${themeAttribute}>`,
    `        <div data-master-scene="${escapeHtml(scene.id)}" data-master-copy-root="true" data-master-copy-id="${escapeHtml(copyId)}">`,
    '        </div>',
    '      </div>'
  ].filter(Boolean).join('\n');
}

function getMasterAnchorVh(anchorId) {
  const sceneId = MASTER_ANCHOR_SCENES[anchorId];
  if (!sceneId) return 0;
  if (sceneId === 'home') return 0;
  const segmentById = new Map((homepageMasterTimeline.segments || []).map((segment) => [segment.id, segment]));
  let cursor = 0;
  for (const block of homepageMasterTimeline.scrollBlocks || []) {
    const length = Number(block.type === 'hold' ? block.scrollVh : segmentById.get(block.segment)?.scrollVh) || 1;
    if (block.type === 'hold' && block.scene === sceneId) return cursor;
    cursor += length;
  }
  return 0;
}

function buildMasterAnchors() {
  return Object.keys(MASTER_ANCHOR_SCENES)
    .map((anchorId) => {
      const anchorVh = getMasterAnchorVh(anchorId);
      return `    <span data-master-anchor="${escapeHtml(anchorId)}" data-master-anchor-vh="${anchorVh.toFixed(4)}" aria-hidden="true" style="top: ${anchorVh.toFixed(4)}vh"></span>`;
    })
    .join('\n');
}

function buildMasterSurfaceCanvas(surface) {
  if (surface.id === 'belief.star') {
    return `      <canvas class="belief-star-field" data-master-surface="${escapeHtml(surface.id)}" aria-hidden="true"></canvas>`;
  }
  return `      <canvas data-master-surface="${escapeHtml(surface.id)}"></canvas>`;
}

function getMasterBlockLength(block) {
  if (block.type === 'hold') return Number(block.scrollVh) || 1;
  return Number(getMasterSegment(block.segment)?.scrollVh) || 1;
}

function getMasterBlockLabel(block) {
  if (block.type === 'hold') return `hold:${block.scene}`;
  return block.segment || block.id;
}

function buildMasterTimelineHud() {
  const blocks = homepageMasterTimeline.scrollBlocks || [];
  const slices = blocks.map((block) => {
    const length = getMasterBlockLength(block);
    const id = block.id || block.scene || block.segment;
    const type = block.type || 'block';
    return [
      `      <span data-master-hud-block="${escapeHtml(id)}"`,
      ` data-master-hud-block-type="${escapeHtml(type)}"`,
      ` title="${escapeHtml(getMasterBlockLabel(block))}"`,
      ` style="--master-hud-block-grow: ${length.toFixed(4)}"></span>`
    ].join('');
  }).join('\n');

  return [
    '    <aside data-master-timeline-hud>',
    '      <div data-master-hud-header>',
    '        <span>master timeline</span>',
    '        <span data-master-hud-total>0.0%</span>',
    '      </div>',
    '      <div data-master-hud-track role="slider" tabindex="0" aria-label="Master timeline" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">',
    slices,
    '        <i data-master-hud-cursor></i>',
    '      </div>',
    '      <dl data-master-hud-readout>',
    '        <div><dt>block</dt><dd data-master-hud-block-label>home-hold</dd></div>',
    '        <div><dt>segment</dt><dd data-master-hud-segment>hold:home</dd></div>',
    '        <div><dt>local</dt><dd data-master-hud-local>0.0000</dd></div>',
    '        <div><dt>direction</dt><dd data-master-hud-direction>forward</dd></div>',
    '        <div><dt>copy</dt><dd data-master-hud-copy>home</dd></div>',
    '        <div><dt>ink</dt><dd data-master-hud-ink>inactive</dd></div>',
    '      </dl>',
    '    </aside>'
  ].join('\n');
}

function buildMasterScaffold(sourceHtml) {
  const masterTrackVh = getMasterTrackVh();
  const surfaceCanvases = homepageMasterTimeline.surfaces
    .map(buildMasterSurfaceCanvas)
    .join('\n');
  const masterAnchors = buildMasterAnchors();
  const timelineHud = buildMasterTimelineHud();
  const visualRoots = homepageMasterTimeline.scenes.map(buildMasterVisualRoot).join('\n');
  const copyRoots = homepageMasterTimeline.scenes.map((scene) => buildMasterCopyRoot(scene, sourceHtml)).join('\n');
  const trackAttributes = MASTER_TIMELINE_ENABLED
    ? `data-homepage-master-track style="--homepage-master-track-vh: ${masterTrackVh};"`
    : `data-homepage-master-track data-master-scaffold-hidden="true" hidden inert aria-hidden="true" style="--homepage-master-track-vh: ${masterTrackVh};"`;

  return [
    `<div ${trackAttributes}>`,
    masterAnchors,
    '  <div data-homepage-master-stage>',
    '    <canvas data-master-ink-canvas aria-hidden="true"></canvas>',
    '    <div data-master-surface-layer aria-hidden="true">',
    surfaceCanvases,
    '    </div>',
    '    <div data-master-scene-layer>',
    '      <div data-master-scene-visual-layer>',
    visualRoots,
    '      </div>',
    '      <div data-master-copy-layer>',
    copyRoots,
    '      </div>',
    '    </div>',
    '  </div>',
    timelineHud,
    '</div>'
  ].join('\n');
}

function injectHtmlMasterAttributes(html) {
  return html.replace(/<html\b([^>]*)>/, (_tag, attrs) => {
    let nextAttrs = setAttribute(attrs, 'data-master-timeline-enabled', String(MASTER_TIMELINE_ENABLED));
    nextAttrs = setAttribute(nextAttrs, 'data-master-dom-mode', MASTER_DOM_MODE);
    return `<html${nextAttrs}>`;
  });
}

function injectHomepageMasterScaffold(html) {
  const scaffold = buildMasterScaffold(html)
    .split('\n')
    .map((line) => `    ${line}`)
    .join('\n');
  return html.replace('<main id="top">', `<main id="top">\n${scaffold}`);
}

function injectBeliefStarMasterSurface(html) {
  return html;
}

function retireLegacyHomeAnchor(html) {
  return html;
}

function injectContractAttributes(html) {
  let nextHtml = html;

  nextHtml = injectHtmlMasterAttributes(nextHtml);
  nextHtml = injectHomepageMasterScaffold(nextHtml);
  nextHtml = injectBeliefStarMasterSurface(nextHtml);
  nextHtml = retireLegacyHomeAnchor(nextHtml);

  contentSections.forEach((section, index) => {
    nextHtml = injectSectionAttributes(nextHtml, section, index);
  });

  chapterTransitions.forEach((transition) => {
    nextHtml = injectTransitionAttributes(nextHtml, transition);
  });

  nextHtml = injectTimelineAttributes(nextHtml);

  return nextHtml;
}

function buildGeneratedTimelineManifest() {
  return [
    '// Generated by scripts/build-index.mjs from src/section-manifest.mjs. Do not edit.',
    '',
    'export const legacySceneTimelineRetired = true;',
    ''
  ].join('\n');
}

function buildGeneratedMasterTimelineManifest() {
  return [
    '// Generated by scripts/build-index.mjs from src/section-manifest.mjs. Do not edit.',
    '',
    `export const homepageMasterTimeline = ${JSON.stringify(homepageMasterTimeline, null, 2)};`,
    ''
  ].join('\n');
}

async function renderFile(relativePath, stack = []) {
  if (stack.includes(relativePath)) {
    throw new Error(`Circular include detected: ${[...stack, relativePath].join(' -> ')}`);
  }

  const filePath = resolveSourcePath(relativePath);
  let source = await readFile(filePath, 'utf8');
  const includes = [...source.matchAll(includePattern)];

  for (const match of includes) {
    const rendered = await renderFile(match[1], [...stack, relativePath]);
    source = source.replace(match[0], rendered.trimEnd());
  }

  return source;
}

const html = injectContractAttributes(await renderFile('index.template.html'));
await writeFile(path.join(rootDir, 'index.html'), `${html.trimEnd()}\n`);
await writeFile(
  path.join(rootDir, 'js/transitions/homepage/scene-timeline-manifest.js'),
  buildGeneratedTimelineManifest()
);
await writeFile(
  path.join(rootDir, 'js/transitions/homepage/master-timeline-manifest.js'),
  buildGeneratedMasterTimelineManifest()
);
console.log('Built index.html and homepage scene timeline manifests from src/index.template.html');
