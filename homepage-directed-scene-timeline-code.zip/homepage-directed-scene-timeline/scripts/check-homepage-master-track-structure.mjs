import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { homepageMasterTimeline } from '../src/section-manifest.mjs';

const html = readFileSync('index.html', 'utf8');
const continuityCss = readFileSync('css/components/homepage-continuity.css', 'utf8');
const paperThemeCss = readFileSync('css/sections/paper-canvas-theme.css', 'utf8');
const count = (pattern) => (html.match(pattern) || []).length;
const masterTrackHtml = html.match(/<div data-homepage-master-track[\s\S]*?<\/div>\n    <section class="hero-wrap"/)?.[0] || '';
const surfaceLayerHtml = html.match(/<div data-master-surface-layer[\s\S]*?<\/div>\n        <div data-master-scene-layer>/)?.[0] || '';

assert.equal(count(/data-homepage-master-track/g), 1, 'built page must contain one master track');
assert.equal(count(/data-homepage-master-stage/g), 1, 'built page must contain one master stage');
assert.equal(count(/data-master-timeline-hud/g), 1, 'built page must contain one master timeline HUD');
assert.equal(count(/data-master-hud-block="/g), homepageMasterTimeline.scrollBlocks.length, 'HUD must expose one slice per master scroll block');
assert.match(html, /data-master-timeline-enabled="true"/, 'built page must enable the master timeline after Task 11');
assert.match(html, /data-master-dom-mode="master-visible"/, 'built page must use master-visible DOM after Task 11');
assert.doesNotMatch(html, /data-homepage-master-track[^>]*(hidden|data-master-scaffold-hidden="true"|inert)/, 'master-visible track must not be hidden or inert');
assert.equal(count(/data-master-ink-canvas/g), 1, 'built page must contain one master ink canvas');
assert.equal(count(/data-master-scene-root="belief\.upper"/g), 1, 'belief.upper root must exist exactly once');
assert.equal(count(/data-master-scene-root="belief\.lower"/g), 1, 'belief.lower root must exist exactly once');
assert.equal(count(/data-master-copy-id="method\.intro"/g), 1, 'method intro copy root must exist exactly once');
assert.equal(count(/data-master-surface="belief\.star"/g), 1, 'belief.star must be registered once as a master surface');
assert.match(surfaceLayerHtml, /data-master-surface="belief\.star"/, 'belief.star must live inside the master surface layer');
assert.doesNotMatch(surfaceLayerHtml, /data-belief-star-field/, 'master belief surface must not steal the real Belief star runtime selector');
assert.doesNotMatch(html, /<!-- existing semantic homepage sections remain after the master track -->/, 'built HTML must not keep the old duplicate visual flow marker');
assert.doesNotMatch(masterTrackHtml, /class="[^"]*hero-content/, 'master observer track must not clone hero copy');
assert.doesNotMatch(masterTrackHtml, /class="[^"]*belief-upper-copy-wrap/, 'master observer track must not clone belief copy');
assert.doesNotMatch(masterTrackHtml, /class="[^"]*brand-definition-grid/, 'master observer track must not clone brand copy');
assert.match(html, /class="[^"]*method-flow/, 'visible real Method section must keep the full method process flow');
assert.match(masterTrackHtml, /data-master-scene-layout="method" data-master-copy-theme="paper"/, 'method master copy must carry paper theme');
assert.match(masterTrackHtml, /data-master-scene-layout="services" data-master-copy-theme="paper"/, 'services master copy must carry paper theme');
assert.match(masterTrackHtml, /data-master-scene-layout="contact" data-master-copy-theme="paper"/, 'contact master copy must carry paper theme');

for (const id of ['home', 'belief', 'method', 'brand', 'services', 'lab', 'education', 'philosophy', 'contact']) {
  assert.match(html, new RegExp(`id="${id}"`), `${id} must resolve to the real page flow`);
  assert.doesNotMatch(html, new RegExp(`id="${id}"[^>]*data-master-anchor="${id}"`), `${id} master anchor must not own public hash navigation`);
}

for (const id of ['home', 'belief', 'method', 'brand', 'services', 'lab', 'education', 'philosophy', 'contact']) {
  assert.doesNotMatch(html, new RegExp(`id="legacy-${id}"`), `${id} real flow id must not be renamed away from public hash navigation`);
}

assert.doesNotMatch(continuityCss, /main > \.hero-wrap[\s\S]*height:\s*0\s*!important/, 'master-visible CSS must not retire the real hero flow');
assert.doesNotMatch(continuityCss, /main > \.long-canvas[\s\S]*height:\s*0\s*!important/, 'master-visible CSS must not retire the real long-canvas flow');
assert.match(continuityCss, /\[data-homepage-master-stage\][\s\S]*display:\s*none/, 'master observer stage must be hidden from the visible path');
assert.match(continuityCss, /html\[data-master-dom-mode="master-visible"\] \.site-nav/, 'master-visible CSS must show nav without legacy hero animation');
assert.match(continuityCss, /\[data-master-timeline-hud\]/, 'master-visible CSS must style the feedback HUD');
assert.match(paperThemeCss, /\[data-master-copy-theme="paper"\][\s\S]*--paper-ink: #252719/, 'paper theme variables must apply inside master copy layouts');

for (const file of [
  'js/transitions/homepage/ttg-homepage-adapter.js',
  'js/transitions/homepage/ph-homepage-adapter.js',
  'js/transitions/homepage/aod-homepage-adapter.js',
  'js/transitions/homepage/figure2-homepage-adapter.js',
  'js/transitions/homepage/figure3-homepage-adapter.js',
  'js/transitions/homepage/crane-homepage-adapter.js'
]) {
  const source = readFileSync(file, 'utf8');
  assert.doesNotMatch(source, /draw(Ttg|Ph|Aod|Figure2|Figure3|Crane)/, `${file} must not draw placeholder master visuals`);
  assert.doesNotMatch(source, /create[A-Za-z]+SurfaceProducer/, `${file} must not export a fake master surface producer`);
}

console.log('Homepage master track structure contract passed.');
