import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { homepageMasterTimeline } from '../js/transitions/homepage/master-timeline-manifest.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(root, 'output/playwright/homepage-directed-timeline-cdp');
const viewport = { name: 'desktop', width: 1440, height: 900 };

const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.mjs', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.webm', 'video/webm'],
  ['.mp4', 'video/mp4'],
  ['.svg', 'image/svg+xml'],
  ['.ttf', 'font/ttf'],
  ['.woff2', 'font/woff2']
]);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function findChrome() {
  const candidates = [
    process.env.CHROME_PATH,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium'
  ].filter(Boolean);
  return candidates.find((candidate) => existsSync(candidate)) || null;
}

function startStaticServer() {
  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url || '/', 'http://127.0.0.1');
      const decodedPath = decodeURIComponent(url.pathname);
      const relativePath = decodedPath === '/' ? 'index.html' : decodedPath.replace(/^\/+/, '');
      const filePath = path.resolve(root, relativePath);
      if (!filePath.startsWith(root)) {
        response.writeHead(403);
        response.end('Forbidden');
        return;
      }
      const buffer = await readFile(filePath);
      response.writeHead(200, {
        'content-type': mimeTypes.get(path.extname(filePath).toLowerCase()) || 'application/octet-stream',
        'cache-control': 'no-store',
        'access-control-allow-origin': '*'
      });
      response.end(buffer);
    } catch {
      response.writeHead(404);
      response.end('Not Found');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, url: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

function buildTimelineOffsets(manifest) {
  const segments = new Map((manifest.segments || []).map((segment) => [segment.id, segment]));
  let cursor = 0;
  const blocks = [];
  for (const block of manifest.scrollBlocks || []) {
    const segment = block.type === 'transition' ? segments.get(block.segment) : null;
    const lengthVh = Number(block.type === 'hold' ? block.scrollVh : segment?.scrollVh) || 1;
    blocks.push({
      ...block,
      segment,
      startVh: cursor,
      endVh: cursor + lengthVh,
      lengthVh
    });
    cursor += lengthVh;
  }
  return { blocks, totalVh: cursor };
}

const model = buildTimelineOffsets(homepageMasterTimeline);

function timelineVhForHold(sceneId, progress = 0.5) {
  const block = model.blocks.find((item) => item.type === 'hold' && item.scene === sceneId);
  assert.ok(block, `Missing hold block for ${sceneId}`);
  return block.startVh + block.lengthVh * progress;
}

function timelineVhForSegment(segmentId, progress) {
  const block = model.blocks.find((item) => item.type === 'transition' && item.segment?.id === segmentId);
  assert.ok(block, `Missing transition block for ${segmentId}`);
  return block.startVh + block.lengthVh * progress;
}

async function waitForLoaderHidden(page) {
  await page.waitForFunction(() => (
    document.body.classList.contains('is-loader-hidden') &&
    document.body.classList.contains('is-loaded')
  ), null, { timeout: 14000 });
}

async function pageYForTimelineVh(page, timelineVh) {
  return page.evaluate(({ timelineVh, totalVh }) => {
    const track = document.querySelector('[data-homepage-master-track]');
    const useDocumentScroll = document.documentElement.dataset.masterDomMode === 'master-visible';
    const rect = track?.getBoundingClientRect?.() || { top: 0, height: 0 };
    const startY = useDocumentScroll ? 0 : rect.top + window.scrollY;
    const scrollablePx = useDocumentScroll
      ? Math.max(1, document.documentElement.scrollHeight - window.innerHeight)
      : Math.max(1, rect.height - window.innerHeight);
    return startY + (timelineVh / totalVh) * scrollablePx;
  }, { timelineVh, totalVh: model.totalVh });
}

async function captureCdpScreenshot(client, filePath) {
  const result = await client.send('Page.captureScreenshot', {
    format: 'png',
    fromSurface: true,
    captureBeyondViewport: false
  });
  await writeFile(filePath, Buffer.from(result.data, 'base64'));
}

async function probe(page, label) {
  return page.evaluate((sampleLabel) => {
    const ratioInViewport = (rect) => {
      const width = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
      const height = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
      return rect.width * rect.height ? (width * height) / (rect.width * rect.height) : 0;
    };
    const isEffectivelyVisible = (element, rootElement = element) => {
      let current = element;
      while (current && current.nodeType === Node.ELEMENT_NODE) {
        const style = getComputedStyle(current);
        if (style.visibility === 'hidden' || style.display === 'none' || Number(style.opacity) <= 0.04) return false;
        if (current === rootElement) break;
        current = current.parentElement;
      }
      const rect = element.getBoundingClientRect();
      return ratioInViewport(rect) > 0.02;
    };
    const textVisibility = (rootElement) => {
      const textElements = [rootElement, ...rootElement.querySelectorAll('*')].filter((element) => (
        [...element.childNodes].some((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim())
      ));
      const details = textElements.map((element) => ({
        tag: element.tagName,
        className: String(element.className || ''),
        text: [...element.childNodes]
          .filter((node) => node.nodeType === Node.TEXT_NODE)
          .map((node) => node.textContent.trim())
          .filter(Boolean)
          .join(' ')
          .replace(/\s+/g, ' '),
        visible: isEffectivelyVisible(element, rootElement),
        opacity: Number(getComputedStyle(element).opacity)
      })).filter((item) => item.text);
      return {
        total: details.length,
        visible: details.filter((item) => item.visible).length,
        hidden: details.filter((item) => !item.visible).slice(0, 6)
      };
    };
    const info = (selector) => {
      const element = document.querySelector(selector);
      if (!element) return { exists: false, selector };
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      const opacity = Number(style.opacity);
      const visibleRatio = ratioInViewport(rect);
      return {
        exists: true,
        selector,
        tag: element.tagName,
        text: (element.innerText || element.textContent || '').replace(/\s+/g, ' ').trim(),
        opacity,
        visibility: style.visibility,
        display: style.display,
        transform: style.transform,
        visibleRatio,
        visible: style.visibility !== 'hidden' && style.display !== 'none' && opacity > 0.04 && visibleRatio > 0.02,
        textVisibility: textVisibility(element),
        parentDataset: Object.fromEntries(Object.entries(element.parentElement?.dataset || {})),
        rect: {
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          left: rect.left,
          width: rect.width,
          height: rect.height
        },
        dataset: Object.fromEntries(Object.entries(element.dataset || {}))
      };
    };
    const mediaDetails = (selector) => [...document.querySelectorAll(selector)].map((element) => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      const opacity = Number(style.opacity);
      const visibleRatio = ratioInViewport(rect);
      const src = element.currentSrc || element.src || element.querySelector?.('source')?.src || '';
      return {
        tag: element.tagName,
        className: String(element.className || ''),
        id: element.id || '',
        src,
        currentTime: Number(element.currentTime || 0),
        readyState: Number(element.readyState || 0),
        paused: Boolean(element.paused),
        visible: style.visibility !== 'hidden' && style.display !== 'none' && opacity > 0.04 && visibleRatio > 0.02,
        visibleRatio,
        rect: {
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          left: rect.left,
          width: rect.width,
          height: rect.height
        },
        dataset: Object.fromEntries(Object.entries(element.dataset || {}))
      };
    });
    const copySelectors = {
      home: '.hero-wrap .hero-content',
      'belief.upper': '.belief-upper-copy-wrap',
      'belief.lower': '.belief-lower-copy-wrap',
      'method.intro': '#method .method-edition-layout--after-handoff',
      'method.proof': '#method .homepage-scene--method-proof',
      brand: '#brand .brand-definition-grid',
      services: '#services .enterprise-vertical-layout',
      lab: '#lab .scenario-wide-stage',
      education: '#education .education-vertical-layout',
      philosophy: '#philosophy .philosophy-list',
      contact: '#contact .contact-endpoint'
    };
    const copies = Object.fromEntries(Object.entries(copySelectors).map(([id, selector]) => [id, info(selector)]));
    const surfaces = Object.fromEntries([...document.querySelectorAll('[data-master-surface]')].map((element) => {
      const surface = info(`[data-master-surface="${element.dataset.masterSurface}"]`);
      surface.width = element.width || 0;
      surface.height = element.height || 0;
      surface.parentDataset = Object.fromEntries(Object.entries(element.parentElement?.dataset || {}));
      return [element.dataset.masterSurface, surface];
    }));
    const stagger = [...document.querySelectorAll('.belief-upper-copy-wrap [data-belief-upper-stagger]')].map((element) => {
      const style = getComputedStyle(element);
      return {
        key: element.dataset.beliefUpperStagger,
        opacity: Number(style.opacity),
        transform: style.transform,
        text: (element.innerText || '').replace(/\s+/g, ' ').trim()
      };
    });
    const anchors = Object.fromEntries([...document.querySelectorAll('[data-master-anchor]')].map((element) => {
      const rect = element.getBoundingClientRect();
      return [element.dataset.masterAnchor, {
        dataset: Object.fromEntries(Object.entries(element.dataset || {})),
        rect: {
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          left: rect.left,
          width: rect.width,
          height: rect.height
        }
      }];
    }));
    const realAnchorIds = ['home', 'belief', 'method', 'brand', 'services', 'lab', 'education', 'philosophy', 'contact'];
    const realAnchors = Object.fromEntries(realAnchorIds.map((id) => [id, info(`#${id}`)]));
    const videos = mediaDetails('video');
    const canvases = mediaDetails('canvas');
    const center = document.elementFromPoint(innerWidth / 2, innerHeight / 2);
    return {
      label: sampleLabel,
      scrollY: window.scrollY,
      bodyClass: document.body.className,
      htmlDataset: Object.fromEntries(Object.entries(document.documentElement.dataset || {})),
      anchors,
      realAnchors,
      centerTop: center
        ? {
            tag: center.tagName,
            className: String(center.className || ''),
            id: center.id || '',
            dataset: Object.fromEntries(Object.entries(center.dataset || {}))
          }
        : null,
      loader: info('.loading-screen'),
      legacyHero: info('.hero-wrap'),
      legacyLongCanvas: info('.long-canvas'),
      masterStage: info('[data-homepage-master-stage]'),
      hud: info('[data-master-timeline-hud]'),
      realBeliefStar: info('#belief [data-belief-star-field]'),
      ink: info('[data-master-ink-canvas]'),
      copies,
      surfaces,
      videos,
      canvases,
      visibleVideos: videos.filter((item) => item.visible),
      visibleCanvases: canvases.filter((item) => item.visible),
      beliefUpperStagger: stagger,
      visibleCopies: Object.entries(copies).filter(([, item]) => item.visible).map(([id]) => id),
      activeSurfaces: Object.entries(surfaces)
        .filter(([, item]) => item.dataset.masterSurfaceActive === 'true' && item.visible)
        .map(([id]) => id)
    };
  }, label);
}

function assertCopyVisible(sample, copyId, message) {
  assert.equal(sample.copies[copyId]?.visible, true, message || `${sample.label}: ${copyId} must be visible`);
  const textVisibility = sample.copies[copyId]?.textVisibility;
  assert.ok(textVisibility?.total > 0, `${sample.label}: ${copyId} must contain inspectable text`);
  assert.equal(
    textVisibility.hidden.length,
    0,
    `${sample.label}: ${copyId} has hidden text descendants: ${JSON.stringify(textVisibility.hidden)}`
  );
}

function assertAnyCopyVisible(sample, message) {
  assert.ok(sample.visibleCopies.length > 0, message || `${sample.label}: must not be copyless`);
}

function assertInkReady(sample) {
  assert.equal(sample.ink.dataset.masterInkActive, 'true', `${sample.label}: master ink must be active`);
  assert.equal(sample.ink.dataset.inkSourceReady, '1', `${sample.label}: ink source surface must be ready`);
  assert.equal(sample.ink.dataset.inkNextReady, '1', `${sample.label}: ink target surface must be ready`);
}

function assertInkInactive(sample, message) {
  assert.equal(sample.ink.dataset.masterInkActive, 'false', message || `${sample.label}: master ink must be inactive`);
  assert.equal(sample.ink.dataset.inkBridgeActive, 'false', `${sample.label}: ink bridge must be inactive`);
  assert.equal(sample.ink.dataset.inkSourceReady, '0', `${sample.label}: inactive ink source readiness must be cleared`);
  assert.equal(sample.ink.dataset.inkNextReady, '0', `${sample.label}: inactive ink target readiness must be cleared`);
}

function assertBeliefUpperRightAligned(sample) {
  const rect = sample.copies['belief.upper']?.rect;
  assert.ok(rect, `${sample.label}: belief.upper rect must exist`);
  assert.ok(rect.left >= viewport.width * 0.45, `${sample.label}: belief.upper must start on the right half`);
  assert.ok(rect.right <= viewport.width * 0.96, `${sample.label}: belief.upper must preserve a right viewport inset`);
}

function assertMasterStructure(sample) {
  assert.equal(sample.hud.visible, true, `${sample.label}: master HUD must remain visible`);
  assert.equal(sample.masterStage.visible, false, `${sample.label}: master scaffold stage must stay out of the visible path`);
  assert.equal(sample.legacyHero.exists, true, `${sample.label}: real hero flow must exist`);
  assert.equal(sample.legacyLongCanvas.exists, true, `${sample.label}: real long-canvas flow must exist`);
  assert.ok(sample.legacyHero.rect.height > 100, `${sample.label}: real hero flow must keep layout height`);
  assert.ok(sample.legacyLongCanvas.rect.height > 100, `${sample.label}: real long-canvas flow must keep layout height`);
  assert.equal(sample.realBeliefStar.exists, true, `${sample.label}: real belief star field must stay in the Belief section`);
  assert.notEqual(sample.realBeliefStar.parentDataset.masterSurfaceLayer, '', `${sample.label}: real belief star field must not be moved into the master surface layer`);
}

function assertMasterAnchor(sample, anchorId) {
  assert.equal(sample.realAnchors[anchorId]?.exists, true, `${sample.label}: #${anchorId} must resolve to the real page flow`);
  assert.notEqual(sample.realAnchors[anchorId]?.dataset.masterAnchor, anchorId, `${sample.label}: #${anchorId} must not be owned by a master anchor`);
}

function assertVisibleVideo(sample, pattern, message) {
  const matches = sample.visibleVideos.filter((item) => pattern.test(`${item.src} ${item.className} ${JSON.stringify(item.dataset)}`));
  assert.ok(matches.length > 0, message || `${sample.label}: expected a visible real video matching ${pattern}`);
}

function assertVisibleCanvas(sample, pattern, message) {
  const matches = sample.visibleCanvases.filter((item) => pattern.test(`${item.className} ${JSON.stringify(item.dataset)}`));
  assert.ok(matches.length > 0, message || `${sample.label}: expected a visible real canvas matching ${pattern}`);
}

function assertHudProgress(sample) {
  assert.match(sample.htmlDataset.masterTimelineProgress || '', /^\d/, `${sample.label}: HUD/master progress must update`);
}

async function runAudit() {
  await mkdir(outputDir, { recursive: true });
  const { server, url } = await startStaticServer();
  const chromePath = findChrome();
  const browser = await chromium.launch({
    headless: true,
    ...(chromePath ? { executablePath: chromePath } : {}),
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });
  const context = await browser.newContext({
    viewport: { width: viewport.width, height: viewport.height },
    deviceScaleFactor: 1
  });
  const page = await context.newPage();
  const client = await context.newCDPSession(page);
  const consoleMessages = [];
  const pageErrors = [];
  page.on('console', (message) => consoleMessages.push({ type: message.type(), text: message.text() }));
  page.on('pageerror', (error) => pageErrors.push(String(error?.stack || error)));

  try {
    await client.send('Page.enable');
    await page.goto(`${url}/index.html`, { waitUntil: 'domcontentloaded' });
    await waitForLoaderHidden(page);

    const samples = [];
    async function sample(label, timelineVh, { waitMs = 700 } = {}) {
      const y = await pageYForTimelineVh(page, timelineVh);
      await page.evaluate((nextY) => window.scrollTo(0, nextY), y);
      await sleep(waitMs);
      return sampleCurrent(label, { requestedTimelineVh: timelineVh, waitMs: 0 });
    }

    async function sampleCurrent(label, { requestedTimelineVh = null, waitMs = 700 } = {}) {
      await sleep(waitMs);
      const result = await probe(page, label);
      result.requestedTimelineVh = requestedTimelineVh;
      result.screenshot = path.join(outputDir, `${viewport.name}-${String(samples.length + 1).padStart(2, '0')}-${label}.png`);
      await captureCdpScreenshot(client, result.screenshot);
      samples.push(result);
      console.log(`${label}: ${JSON.stringify({
        segment: result.htmlDataset.masterTimelineSegment,
        direction: result.htmlDataset.masterTimelineDirection,
        progress: result.htmlDataset.masterTimelineProgress,
        visibleCopies: result.visibleCopies,
        visibleVideos: result.visibleVideos.map((item) => item.src || item.className),
        activeSurfaces: result.activeSurfaces,
        inkActive: result.ink.dataset.masterInkActive,
        inkReady: [result.ink.dataset.inkSourceReady, result.ink.dataset.inkNextReady]
      })}`);
      return result;
    }

    const top = await sample('top-loader-hidden', 0);
    assert.equal(top.loader.visible, false, 'loader must be hidden after master runtime starts');
    assert.match(top.bodyClass, /is-loader-hidden/, 'body must record loader hidden');
    assertCopyVisible(top, 'home', 'home copy must be visible after the loader exits');
    assertMasterStructure(top);
    assertMasterAnchor(top, 'method');
    assertHudProgress(top);
    assertVisibleVideo(top, /figure1\.webm|fallback-figure/, 'Hero must keep a visible real video/stage');

    await page.click('.nav-links a[href="#method"]');
    const methodHash = await sampleCurrent('hash-method-anchor', { waitMs: 1400 });
    assertMasterAnchor(methodHash, 'method');
    assertCopyVisible(methodHash, 'method.intro', 'method nav hash must land on the real Method copy');
    assertHudProgress(methodHash);

    const beliefHold = await sample('belief-upper-hold', timelineVhForHold('belief.upper', 0.5));
    assertCopyVisible(beliefHold, 'belief.upper', 'belief.upper hold copy must be visible');
    assertBeliefUpperRightAligned(beliefHold);
    assertHudProgress(beliefHold);
    assert.ok(
      beliefHold.beliefUpperStagger.length >= 4 && beliefHold.beliefUpperStagger.every((item) => item.opacity > 0.95),
      'belief.upper hold stagger items must be fully visible'
    );

    const beliefLate = await sample('belief-upper-to-lower-75', timelineVhForSegment('belief-upper-to-belief-lower', 0.75));
    assertAnyCopyVisible(beliefLate, 'belief upper/lower transition must not be copyless at 75%');
    assertVisibleCanvas(beliefLate, /pattern-bloom-transition__canvas|belief-star-field/, 'Belief transition must keep the real Pattern/Bloom canvas path visible');

    const methodOverlap = await sample('aod-method-55', timelineVhForSegment('belief-lower-to-method', 0.55));
    assertCopyVisible(methodOverlap, 'method.intro', 'method copy must overlap the AOD bridge');
    assertVisibleVideo(methodOverlap, /aod_figure-alpha-front-scrub\.webm|aod-transition__figure-video/, 'AOD bridge must use the real AOD video');

    const figure2Late = await sample('figure2-brand-80', timelineVhForSegment('method-proof-to-brand', 0.80));
    assertAnyCopyVisible(figure2Late, 'Figure2 to brand transition must not be copyless at 80%');
    assertVisibleVideo(figure2Late, /figure2a|figure2b|figure2-figure-video/, 'Figure2 bridge must use the real Figure2 videos');

    const figure3Late = await sample('figure3-services-80', timelineVhForSegment('brand-to-services', 0.80));
    assertAnyCopyVisible(figure3Late, 'Figure3 to services transition must not be copyless at 80%');
    assertVisibleVideo(figure3Late, /figure3-alpha-scrub\.webm|figure3-transition__video/, 'Figure3 bridge must use the real Figure3 video');

    const ttgBridge = await sample('ttg-services-lab-55', timelineVhForSegment('services-to-lab', 0.55));
    assertAnyCopyVisible(ttgBridge, 'TTG bridge must not be copyless');
    assertVisibleVideo(ttgBridge, /ttg_figure-alpha-scrub|ttg-layer--figure/, 'TTG bridge must use the real TTG video');

    const phBridge = await sample('ph-lab-education-55', timelineVhForSegment('lab-to-education', 0.55));
    assertAnyCopyVisible(phBridge, 'PH bridge must not be copyless');
    assertVisibleVideo(phBridge, /ph_figure-alpha-scrub|ph-layer--figure/, 'PH bridge must use the real PH video');

    const craneForward = await sample('crane-contact-70-forward', timelineVhForSegment('philosophy-to-contact', 0.70));
    assertCopyVisible(craneForward, 'contact', 'contact copy must overlap the Crane bridge');
    assertVisibleVideo(craneForward, /crane-figure\d-transition\.webm|crane-figure-video/, 'Crane bridge must use the real Crane videos');

    const craneForwardBoundary = await sample('crane-contact-80-forward-boundary', timelineVhForSegment('philosophy-to-contact', 0.80));
    assertCopyVisible(craneForwardBoundary, 'contact', 'contact copy must remain visible at the Crane boundary');
    assertHudProgress(craneForwardBoundary);

    await sample('contact-hold-before-reverse', timelineVhForHold('contact', 0.65));
    const craneReverseBoundary = await sample('crane-contact-80-reverse-boundary', timelineVhForSegment('philosophy-to-contact', 0.80));
    assert.equal(craneReverseBoundary.htmlDataset.masterTimelineDirection, 'reverse', 'reverse boundary sample must retain reverse direction after settling');
    assertCopyVisible(craneReverseBoundary, 'contact', 'reverse Crane boundary must keep contact copy visible');
    assertHudProgress(craneReverseBoundary);

    const craneReverse = await sample('crane-contact-70-reverse', timelineVhForSegment('philosophy-to-contact', 0.70));
    assert.equal(craneReverse.htmlDataset.masterTimelineDirection, 'reverse', 'reverse sample must retain reverse direction after settling');
    assertCopyVisible(craneReverse, 'contact', 'reverse Crane sample must keep contact copy visible');
    assertVisibleVideo(craneReverse, /crane-figure\d-transition\.webm|crane-figure-video/, 'reverse Crane bridge must use the real Crane videos');

    await writeFile(path.join(outputDir, 'samples.json'), JSON.stringify({
      url,
      viewport,
      totalVh: model.totalVh,
      consoleMessages,
      pageErrors,
      samples
    }, null, 2));
    assert.deepEqual(pageErrors, [], 'page must not throw runtime errors during master CDP audit');
  } finally {
    await browser.close();
    server.close();
  }
}

runAudit()
  .then(() => {
    console.log(`Homepage master CDP audit passed. Output: ${outputDir}`);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
