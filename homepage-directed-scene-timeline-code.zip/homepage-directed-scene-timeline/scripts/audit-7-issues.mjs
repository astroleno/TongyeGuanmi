import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(root, 'output', 'playwright', 'audit-7-issues');

const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.mjs', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.webm', 'video/webm'],
  ['.mp4', 'video/mp4'],
  ['.svg', 'image/svg+xml'],
  ['.ttf', 'font/ttf'],
  ['.woff2', 'font/woff2'],
]);

function startStaticServer() {
  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url || '/', 'http://127.0.0.1');
      const decodedPath = decodeURIComponent(url.pathname);
      const relativePath = decodedPath === '/' ? 'index.html' : decodedPath.replace(/^\/+/, '');
      const filePath = path.resolve(root, relativePath);
      if (!filePath.startsWith(root)) {
        response.writeHead(403);
        response.end('Forbidden');
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const contentType = mimeTypes.get(ext) || 'application/octet-stream';
      const body = await readFile(filePath).catch(() => null);
      if (body === null) {
        response.writeHead(404);
        response.end('Not Found');
        return;
      }
      response.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': '*'
      });
      response.end(body);
    } catch {
      response.writeHead(500);
      response.end('Internal Server Error');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      resolve({ server, url: `http://127.0.0.1:${addr.port}` });
    });
  });
}

async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function probePage(page) {
  return page.evaluate(() => {
    function info(selector) {
      const el = document.querySelector(selector);
      if (!el) return { exists: false };
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return {
        exists: true,
        className: el.className,
        dataset: Object.fromEntries(Object.entries(el.dataset)),
        opacity: Number(style.opacity),
        visibility: style.visibility,
        display: style.display,
        top: rect.top,
        bottom: rect.bottom,
        left: rect.left,
        right: rect.right,
        width: rect.width,
        height: rect.height,
        innerHTML: el.innerHTML.slice(0, 200),
      };
    }
    function hostInfo(id) {
      const el = document.querySelector(`[data-transition-id="${id}"]`);
      if (!el) return { exists: false };
      const rect = el.getBoundingClientRect();
      return {
        exists: true,
        className: el.className,
        dataset: Object.fromEntries(Object.entries(el.dataset)),
        top: rect.top,
        bottom: rect.bottom,
        height: rect.height,
      };
    }
    function allInfo(selector) {
      const els = document.querySelectorAll(selector);
      return Array.from(els).map(el => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return { opacity: Number(style.opacity), display: style.display, visibility: style.visibility, top: rect.top, bottom: rect.bottom, left: rect.left, right: rect.right, width: rect.width, height: rect.height, className: el.className };
      });
    }
    return {
      scrollY: window.scrollY,
      documentHeight: document.documentElement.scrollHeight,
      viewport: { width: window.innerWidth, height: window.innerHeight },
      owners: {
        visualOwner: document.documentElement.dataset.sceneVisualOwner || '',
        copyOwner: document.documentElement.dataset.sceneCopyOwner || '',
        foregroundCopyOwner: document.documentElement.dataset.sceneForegroundCopyOwner || '',
        canvasOwner: document.documentElement.dataset.sceneCanvasOwner || '',
        maskOwner: document.documentElement.dataset.sceneMaskOwner || '',
        layerOwner: document.documentElement.dataset.sceneLayerOwner || '',
        transitionPhase: document.documentElement.dataset.transitionPhase || '',
      },
      upper: info('.belief-upper-copy-wrap'),
      lower: info('.belief-lower-copy-wrap'),
      method: info('.method-edition-layout--after-handoff'),
      brand: info('.brand-definition-grid'),
      services: info('.enterprise-vertical-layout'),
      contact: info('.contact-endpoint'),
      aodStage: info('.aod-transition'),
      figure2Stage: info('.figure2-scroll'),
      figure3Stage: info('.figure3-transition'),
      craneStage: info('.crane-scroll'),
      starField: info('.belief-star-field'),
      starWash: info('.belief-star-wash'),
      hosts: {
        beliefMethod: hostInfo('belief-method'),
        figure2Brand: hostInfo('method-tooling__method-proof'),
        brandServices: hostInfo('brand-services'),
        philosophyContact: hostInfo('philosophy-contact'),
      },
      patternBloom: allInfo('.pattern-bloom-transition__stage'),
      starFields: allInfo('.belief-star-field'),
      methodScenes: allInfo('.homepage-scene--method-field-law, .homepage-scene--method-cocreation, .homepage-scene--method-tooling, .homepage-scene--method-proof'),
      craneScenes: allInfo('.crane-scroll'),
    };
  });
}

async function main() {
  await mkdir(outputDir, { recursive: true });
  const { server, url } = await startStaticServer();

  const browser = await chromium.launch({
    headless: true,
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const page = await context.newPage();

  // Load page and wait for JS to settle
  await page.goto(url + '/index.html', { waitUntil: 'networkidle' });
  await sleep(3000);

  const results = [];
  const screenshots = [];

  async function capture(label, scrollY) {
    if (typeof scrollY === 'number') {
      await page.evaluate((y) => window.scrollTo(0, y), scrollY);
      await sleep(800);
    }
    const data = await probePage(page);
    const screenshotPath = path.join(outputDir, `${label}.png`);
    await page.screenshot({ path: screenshotPath, fullPage: false });
    screenshots.push({ label, path: screenshotPath, scrollY: data.scrollY });
    results.push({ label, data });
    console.log(`\n=== ${label} (scrollY=${data.scrollY}) ===`);
    console.log('owners:', JSON.stringify(data.owners));
    console.log('upper:', JSON.stringify(data.upper));
    console.log('lower:', JSON.stringify(data.lower));
    console.log('method:', JSON.stringify(data.method));
    console.log('contact:', JSON.stringify(data.contact));
    console.log('hosts:', JSON.stringify(data.hosts));
    console.log('starField:', JSON.stringify(data.starField));
    console.log('starFields:', JSON.stringify(data.starFields));
    console.log('aodStage:', JSON.stringify(data.aodStage));
    console.log('figure2Stage:', JSON.stringify(data.figure2Stage));
    console.log('craneStage:', JSON.stringify(data.craneStage));
  }

  // 1. Check hero area at top
  await capture('00-hero', 0);

  // 2. Check belief upper entry (scroll into belief section)
  // Find where belief section starts
  const beliefSectionTop = await page.evaluate(() => {
    const el = document.getElementById('belief');
    return el ? el.offsetTop : 0;
  });
  await capture('01-belief-upper', beliefSectionTop + 100);

  // 3. Check belief lower (scroll further down within belief)
  await capture('02-belief-lower', beliefSectionTop + 600);

  // 4. Check transition between belief upper and lower (scroll to midway)
  const transitionEl = await page.locator('[data-transition-id="home-belief"]').first();
  const transitionBox = await transitionEl.boundingBox().catch(() => null);
  if (transitionBox) {
    await capture('03-belief-transition', Math.round(transitionBox.y + transitionBox.height / 2));
  }

  // 5. Check belief-method transition (AOD)
  const aodTransitionTop = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="belief-method"]');
    return el ? el.offsetTop : 0;
  });
  await capture('04-aod-transition-start', aodTransitionTop);
  await capture('05-aod-transition-mid', aodTransitionTop + 400);
  await capture('06-aod-transition-late', aodTransitionTop + 800);

  // 6. Check method section after AOD
  const methodSectionTop = await page.evaluate(() => {
    const el = document.getElementById('method');
    return el ? el.offsetTop : 0;
  });
  await capture('07-method-entry', methodSectionTop + 100);
  await capture('08-method-visible', methodSectionTop + 400);

  // 7. Check figure2 transition (method-proof to brand)
  const figure2TransitionTop = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="method-tooling__method-proof"]');
    return el ? el.offsetTop : 0;
  });
  await capture('09-figure2-start', figure2TransitionTop);
  await capture('10-figure2-mid', figure2TransitionTop + 300);
  await capture('11-figure2-late', figure2TransitionTop + 600);
  await capture('12-figure2-post', figure2TransitionTop + 1000);

  // 8. Check brand entry
  const brandSectionTop = await page.evaluate(() => {
    const el = document.getElementById('brand');
    return el ? el.offsetTop : 0;
  });
  await capture('13-brand-entry', brandSectionTop + 100);

  // 9. Check figure2 scrolling back up from brand
  await capture('14-figure2-backup', figure2TransitionTop + 500);

  // 10. Check crane to contact transition
  const craneTransitionTop = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="philosophy-contact"]');
    return el ? el.offsetTop : 0;
  });
  await capture('15-crane-transition-start', craneTransitionTop);
  await capture('16-crane-transition-mid', craneTransitionTop + 400);
  await capture('17-crane-transition-late', craneTransitionTop + 800);

  // 11. Check contact section
  const contactSectionTop = await page.evaluate(() => {
    const el = document.getElementById('contact');
    return el ? el.offsetTop : 0;
  });
  await capture('18-contact-entry', contactSectionTop + 100);
  await capture('19-contact-visible', contactSectionTop + 400);

  // Write results
  await writeFile(path.join(outputDir, 'results.json'), JSON.stringify(results, null, 2));
  await writeFile(path.join(outputDir, 'screenshots.json'), JSON.stringify(screenshots, null, 2));

  await browser.close();
  server.close();
  console.log('\nAudit complete. Output saved to', outputDir);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
