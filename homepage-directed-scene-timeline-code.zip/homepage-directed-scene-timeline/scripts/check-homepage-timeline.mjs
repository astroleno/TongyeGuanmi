import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const root = new URL('../', import.meta.url);
const read = (relativePath) => readFileSync(new URL(relativePath, root), 'utf8');
const sourceManifest = await import(`${pathToFileURL(new URL('src/section-manifest.mjs', root).pathname).href}?v=${Date.now()}`);
const generatedMaster = await import(`${pathToFileURL(new URL('js/transitions/homepage/master-timeline-manifest.js', root).pathname).href}?v=${Date.now()}`);
const generatedLegacyPath = new URL('js/transitions/homepage/scene-timeline-manifest.js', root);

assert.ok(sourceManifest.homepageMasterTimeline, 'homepage master timeline must exist');
assert.equal(sourceManifest[['ownership', 'Windows'].join('')], undefined, 'legacy ownership export must be retired');
assert.equal(Array.isArray(sourceManifest.timelineJoins) && sourceManifest.timelineJoins.length, 0, 'legacy joins must be empty after retirement');
assert.deepEqual(generatedMaster.homepageMasterTimeline, sourceManifest.homepageMasterTimeline, 'generated master manifest must match source manifest');

assert.equal(existsSync(generatedLegacyPath), true, 'retired compatibility manifest must still be generated');
const generatedLegacySource = read('js/transitions/homepage/scene-timeline-manifest.js');
assert.match(generatedLegacySource, /legacySceneTimelineRetired = true/, 'legacy scene timeline manifest must be a retired stub');

const html = read('index.html');
assert.match(html, /data-master-timeline-enabled="true"/, 'built page must enable the master timeline');
assert.match(html, /data-master-dom-mode="master-visible"/, 'built page must use master-visible DOM');
assert.doesNotMatch(html, /data-master-timeline-enabled="false"/, 'built page must not leave the master timeline disabled');
assert.doesNotMatch(html, /data-master-scaffold-hidden|data-homepage-master-track[^>]*hidden|data-homepage-master-track[^>]*inert/, 'master track must not be hidden or inert');

const sceneIds = new Set(sourceManifest.homepageMasterTimeline.scenes.map((scene) => scene.id));
const surfaceIds = new Set(sourceManifest.homepageMasterTimeline.surfaces.map((surface) => surface.id));
for (const scene of sourceManifest.homepageMasterTimeline.scenes) {
  assert.ok(surfaceIds.has(scene.surfaceKey), `${scene.id} must use a declared surface`);
  assert.match(html, new RegExp(`data-master-scene-root="${scene.id.replace('.', '\\.')}"`), `${scene.id} master root must be generated`);
  assert.match(html, new RegExp(`data-master-copy-id="${(scene.id === 'method' ? 'method.intro' : scene.id).replace('.', '\\.')}"`), `${scene.id} master copy root must be generated`);
}

for (const segment of sourceManifest.homepageMasterTimeline.segments) {
  assert.ok(sceneIds.has(segment.from), `${segment.id} source scene must exist`);
  assert.ok(sceneIds.has(segment.to), `${segment.id} target scene must exist`);
  assert.ok(Number.isFinite(segment.scrollVh) && segment.scrollVh > 0, `${segment.id} must declare positive scroll length`);
  assert.ok(segment.copy?.source, `${segment.id} must define source copy timing`);
  assert.ok(segment.copy?.target?.policy, `${segment.id} must define target copy policy`);
  if (segment.transition?.type === 'ink') {
    assert.ok(surfaceIds.has(segment.transition.ink.sourceSurfaceKey), `${segment.id} ink source surface must exist`);
    assert.ok(surfaceIds.has(segment.transition.ink.targetSurfaceKey), `${segment.id} ink target surface must exist`);
  }
}

console.log('Homepage master timeline retirement contract passed.');
