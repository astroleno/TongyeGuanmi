import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const root = new URL('../', import.meta.url);
const read = (relativePath) => readFileSync(new URL(relativePath, root), 'utf8');
const manifest = await import(`${pathToFileURL(new URL('src/section-manifest.mjs', root).pathname).href}?handoff=${Date.now()}`);

assert.ok(manifest.homepageMasterTimeline, 'homepage master timeline must exist');
assert.equal(manifest[['ownership', 'Windows'].join('')], undefined, 'legacy ownership export must be retired');

const segmentIds = new Set(manifest.homepageMasterTimeline.segments.map((segment) => segment.id));
for (const id of [
  'home-to-belief-upper',
  'belief-upper-to-belief-lower',
  'belief-lower-to-method',
  'method-proof-to-brand',
  'brand-to-services',
  'services-to-lab',
  'lab-to-education',
  'education-to-philosophy',
  'philosophy-to-contact'
]) {
  assert.ok(segmentIds.has(id), `${id} master handoff segment must exist`);
}

const runtimeSource = read('js/transitions/homepage-transition-runtime.js');
assert.match(runtimeSource, /initMasterHomepageTransitions/, 'homepage runtime must expose the master runtime');
assert.match(runtimeSource, /initLegacyHomepageTransitions\(options\)/, 'master mode must keep the real transition runtime active');
assert.match(runtimeSource, /real legacy visual flow/, 'master runtime must document that visible handoff timing stays with the real flow');
assert.doesNotMatch(runtimeSource, /scene-timeline-controller/, 'homepage runtime must not import the retired scene controller');
const masterRuntimeBody = runtimeSource.match(/async function initMasterHomepageTransitions[\s\S]*?async function initLegacyHomepageTransitions/)?.[0] || '';
assert.doesNotMatch(masterRuntimeBody, /handoffProgressSource|timeline\?\.(update|updateJoin|getOwnership)/, 'master observer runtime must not take over legacy handoff timing');

const adapterSources = [
  'js/transitions/homepage/aod-homepage-adapter.js',
  'js/transitions/homepage/figure2-homepage-adapter.js',
  'js/transitions/homepage/crane-homepage-adapter.js',
  'js/transitions/homepage/figure3-homepage-adapter.js',
  'js/transitions/pattern-bloom-adapter.js'
].map(read).join('\n');

assert.doesNotMatch(adapterSources, /cloneNode\s*\(\s*true\s*\)/, 'homepage handoff code must not clone real target content');
assert.doesNotMatch(adapterSources, /createHandoffReceiver/, 'active homepage adapters must not use retired target DOM receivers');
assert.doesNotMatch(adapterSources, /create[A-Za-z]+SurfaceProducer|draw(Ttg|Ph|Aod|Figure2|Figure3|Crane)/, 'active homepage adapters must not replace real handoffs with master placeholder surfaces');

const registrySource = read('js/transitions/homepage-transition-registry.js');
assert.match(registrySource, /createObserverSurface/, 'master surface registry must use observer producers during visual salvage');
assert.doesNotMatch(registrySource, /create(?!Observer)[A-Za-z]+SurfaceProducer\(context\)/, 'master surface registry must not mount per-scene placeholder producers');

console.log('Homepage master handoff ownership contract passed.');
