import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(root, 'output', 'playwright', 'audit-7-issues-2');

const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.mjs', 'text/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.webp', 'image/webp'],
  ['.webm', 'video/webm'],
  ['.mp4', 'video/mp4'],
  ['.svg', 'image/svg+xml'],
  ['.ttf', 'font/ttf'],
  ['.woff2', 'font/woff2'],
]);

function startStaticServer() {
  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url || '/', 'http://127.0.0.1');
      const decodedPath = decodeURIComponent(url.pathname);
      const relativePath = decodedPath === '/' ? 'index.html' : decodedPath.replace(/^\/+/, '');
      const filePath = path.resolve(root, relativePath);
      if (!filePath.startsWith(root)) {
        response.writeHead(403);
        response.end('Forbidden');
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const contentType = mimeTypes.get(ext) || 'application/octet-stream';
      const body = await readFile(filePath).catch(() => null);
      if (body === null) {
        response.writeHead(404);
        response.end('Not Found');
        return;
      }
      response.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': '*'
      });
      response.end(body);
    } catch {
      response.writeHead(500);
      response.end('Internal Server Error');
    }
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address();
      resolve({ server, url: `http://127.0.0.1:${addr.port}` });
    });
  });
}

async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function main() {
  await mkdir(outputDir, { recursive: true });
  const { server, url } = await startStaticServer();

  const browser = await chromium.launch({
    headless: true,
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
  });
  const page = await context.newPage();

  await page.goto(url + '/index.html', { waitUntil: 'networkidle' });
  await sleep(4000);

  async function capture(label, scrollY) {
    await page.evaluate((y) => window.scrollTo(0, y), scrollY);
    await sleep(500);
    const screenshotPath = path.join(outputDir, `${label}.png`);
    await page.screenshot({ path: screenshotPath, fullPage: false });
    console.log(`Captured ${label} at scrollY=${scrollY}`);
  }

  // Get document height for bottom areas
  const docHeight = await page.evaluate(() => document.documentElement.scrollHeight);
  console.log('Document height:', docHeight);

  // Scroll through key positions quickly to find relevant sections
  const sectionTops = await page.evaluate(() => {
    const ids = ['home', 'belief', 'method', 'brand', 'services', 'lab', 'education', 'philosophy', 'contact'];
    const result = {};
    for (const id of ids) {
      const el = document.getElementById(id);
      result[id] = el ? el.offsetTop : 0;
    }
    return result;
  });
  console.log('Section tops:', sectionTops);

  // Capture figure2 area with post-scroll
  const figure2Transition = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="method-tooling__method-proof"]');
    return el ? { top: el.offsetTop, height: el.offsetHeight } : { top: 0, height: 0 };
  });
  console.log('Figure2 transition:', figure2Transition);

  await capture('20-figure2-backup', figure2Transition.top + Math.round(figure2Transition.height * 0.3));
  await capture('21-figure2-backup-mid', figure2Transition.top + Math.round(figure2Transition.height * 0.6));
  await capture('22-figure2-backup-late', figure2Transition.top + Math.round(figure2Transition.height * 0.9));

  // Capture brand area
  await capture('23-brand-mid', sectionTops.brand + 300);
  await capture('24-brand-late', sectionTops.brand + 700);

  // Capture services-lab transition
  const servicesLab = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="services-lab"]');
    return el ? { top: el.offsetTop, height: el.offsetHeight } : { top: 0, height: 0 };
  });
  await capture('25-services-lab', servicesLab.top + Math.round(servicesLab.height * 0.5));

  // Capture education-philosophy transition
  const eduPhil = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="education-philosophy"]');
    return el ? { top: el.offsetTop, height: el.offsetHeight } : { top: 0, height: 0 };
  });
  await capture('26-edu-phil', eduPhil.top + Math.round(eduPhil.height * 0.5));

  // Capture philosophy-contact transition (crane)
  const philContact = await page.evaluate(() => {
    const el = document.querySelector('[data-transition-id="philosophy-contact"]');
    return el ? { top: el.offsetTop, height: el.offsetHeight } : { top: 0, height: 0 };
  });
  console.log('Philosophy-contact transition:', philContact);

  await capture('27-crane-start', philContact.top);
  await capture('28-crane-mid', philContact.top + Math.round(philContact.height * 0.3));
  await capture('29-crane-late', philContact.top + Math.round(philContact.height * 0.6));
  await capture('30-crane-end', philContact.top + Math.round(philContact.height * 0.9));

  // Capture contact area
  await capture('31-contact-start', sectionTops.contact);
  await capture('32-contact-mid', sectionTops.contact + 300);
  await capture('33-contact-late', sectionTops.contact + 700);

  await browser.close();
  server.close();
  console.log('Done. Output:', outputDir);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
